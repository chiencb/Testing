
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FillKeyTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FillKeyTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="query" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="stringDefinition" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FillKeyTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "key",
    "query",
    "stringDefinition"
})
public class FillKeyTO {

    @XmlElement(required = true, nillable = true)
    protected String key;
    protected boolean query;
    @XmlElement(required = true, nillable = true)
    protected String stringDefinition;

    /**
     * Gets the value of the key property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the value of the key property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

    /**
     * Gets the value of the query property.
     * 
     */
    public boolean isQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     */
    public void setQuery(boolean value) {
        this.query = value;
    }

    /**
     * Gets the value of the stringDefinition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStringDefinition() {
        return stringDefinition;
    }

    /**
     * Sets the value of the stringDefinition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStringDefinition(String value) {
        this.stringDefinition = value;
    }

}
