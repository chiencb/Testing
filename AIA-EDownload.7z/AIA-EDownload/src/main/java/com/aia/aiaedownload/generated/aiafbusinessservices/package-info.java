@javax.xml.bind.annotation.XmlSchema(namespace = "http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360")
package com.aia.aiaedownload.generated.aiafbusinessservices;
