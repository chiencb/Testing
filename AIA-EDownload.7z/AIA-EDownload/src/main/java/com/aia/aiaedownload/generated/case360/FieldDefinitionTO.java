
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FieldDefinitionTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FieldDefinitionTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allowNull" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="categoryName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="collection" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="dataType" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="defaultName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="defaultValue" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="enumType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="enumeration" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="fieldName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fillKey" type="{http://fields.sonora.eistream.com/}FillKeyTO"/&gt;
 *         &lt;element name="formFormatData" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="formFormatName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="length" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="listFormatData" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="listFormatName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="maxInclusive" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="minInclusive" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="parentName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="pattern" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="repositoryManage" type="{http://fields.sonora.eistream.com/}RepositoryManageTO"/&gt;
 *         &lt;element name="scale" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="validator" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="valueList" type="{http://fields.sonora.eistream.com/}FmsValueDefinitionTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="xmlRule" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FieldDefinitionTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "allowNull",
    "categoryName",
    "collection",
    "dataType",
    "defaultName",
    "defaultValue",
    "description",
    "enumType",
    "enumeration",
    "fieldName",
    "fillKey",
    "formFormatData",
    "formFormatName",
    "length",
    "listFormatData",
    "listFormatName",
    "maxInclusive",
    "minInclusive",
    "parentName",
    "pattern",
    "repositoryManage",
    "scale",
    "validator",
    "valueList",
    "xmlRule"
})
public class FieldDefinitionTO {

    protected boolean allowNull;
    @XmlElement(required = true, nillable = true)
    protected String categoryName;
    protected boolean collection;
    protected short dataType;
    @XmlElement(required = true, nillable = true)
    protected String defaultName;
    @XmlElement(required = true, nillable = true)
    protected String defaultValue;
    @XmlElement(required = true, nillable = true)
    protected String description;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer enumType;
    protected boolean enumeration;
    @XmlElement(required = true, nillable = true)
    protected String fieldName;
    @XmlElement(required = true, nillable = true)
    protected FillKeyTO fillKey;
    @XmlElement(required = true, nillable = true)
    protected String formFormatData;
    @XmlElement(required = true, nillable = true)
    protected String formFormatName;
    protected int length;
    @XmlElement(required = true, nillable = true)
    protected String listFormatData;
    @XmlElement(required = true, nillable = true)
    protected String listFormatName;
    @XmlElement(required = true, nillable = true)
    protected String maxInclusive;
    @XmlElement(required = true, nillable = true)
    protected String minInclusive;
    @XmlElement(required = true, nillable = true)
    protected String parentName;
    @XmlElement(required = true, nillable = true)
    protected String pattern;
    @XmlElement(required = true, nillable = true)
    protected RepositoryManageTO repositoryManage;
    protected int scale;
    @XmlElement(required = true, nillable = true)
    protected String validator;
    @XmlElement(nillable = true)
    protected List<FmsValueDefinitionTO> valueList;
    @XmlElement(required = true, nillable = true)
    protected String xmlRule;

    /**
     * Gets the value of the allowNull property.
     * 
     */
    public boolean isAllowNull() {
        return allowNull;
    }

    /**
     * Sets the value of the allowNull property.
     * 
     */
    public void setAllowNull(boolean value) {
        this.allowNull = value;
    }

    /**
     * Gets the value of the categoryName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * Sets the value of the categoryName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategoryName(String value) {
        this.categoryName = value;
    }

    /**
     * Gets the value of the collection property.
     * 
     */
    public boolean isCollection() {
        return collection;
    }

    /**
     * Sets the value of the collection property.
     * 
     */
    public void setCollection(boolean value) {
        this.collection = value;
    }

    /**
     * Gets the value of the dataType property.
     * 
     */
    public short getDataType() {
        return dataType;
    }

    /**
     * Sets the value of the dataType property.
     * 
     */
    public void setDataType(short value) {
        this.dataType = value;
    }

    /**
     * Gets the value of the defaultName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultName() {
        return defaultName;
    }

    /**
     * Sets the value of the defaultName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultName(String value) {
        this.defaultName = value;
    }

    /**
     * Gets the value of the defaultValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * Sets the value of the defaultValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultValue(String value) {
        this.defaultValue = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the enumType property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEnumType() {
        return enumType;
    }

    /**
     * Sets the value of the enumType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEnumType(Integer value) {
        this.enumType = value;
    }

    /**
     * Gets the value of the enumeration property.
     * 
     */
    public boolean isEnumeration() {
        return enumeration;
    }

    /**
     * Sets the value of the enumeration property.
     * 
     */
    public void setEnumeration(boolean value) {
        this.enumeration = value;
    }

    /**
     * Gets the value of the fieldName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * Sets the value of the fieldName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldName(String value) {
        this.fieldName = value;
    }

    /**
     * Gets the value of the fillKey property.
     * 
     * @return
     *     possible object is
     *     {@link FillKeyTO }
     *     
     */
    public FillKeyTO getFillKey() {
        return fillKey;
    }

    /**
     * Sets the value of the fillKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link FillKeyTO }
     *     
     */
    public void setFillKey(FillKeyTO value) {
        this.fillKey = value;
    }

    /**
     * Gets the value of the formFormatData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormFormatData() {
        return formFormatData;
    }

    /**
     * Sets the value of the formFormatData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormFormatData(String value) {
        this.formFormatData = value;
    }

    /**
     * Gets the value of the formFormatName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormFormatName() {
        return formFormatName;
    }

    /**
     * Sets the value of the formFormatName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormFormatName(String value) {
        this.formFormatName = value;
    }

    /**
     * Gets the value of the length property.
     * 
     */
    public int getLength() {
        return length;
    }

    /**
     * Sets the value of the length property.
     * 
     */
    public void setLength(int value) {
        this.length = value;
    }

    /**
     * Gets the value of the listFormatData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListFormatData() {
        return listFormatData;
    }

    /**
     * Sets the value of the listFormatData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListFormatData(String value) {
        this.listFormatData = value;
    }

    /**
     * Gets the value of the listFormatName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListFormatName() {
        return listFormatName;
    }

    /**
     * Sets the value of the listFormatName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListFormatName(String value) {
        this.listFormatName = value;
    }

    /**
     * Gets the value of the maxInclusive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaxInclusive() {
        return maxInclusive;
    }

    /**
     * Sets the value of the maxInclusive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaxInclusive(String value) {
        this.maxInclusive = value;
    }

    /**
     * Gets the value of the minInclusive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinInclusive() {
        return minInclusive;
    }

    /**
     * Sets the value of the minInclusive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinInclusive(String value) {
        this.minInclusive = value;
    }

    /**
     * Gets the value of the parentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentName() {
        return parentName;
    }

    /**
     * Sets the value of the parentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentName(String value) {
        this.parentName = value;
    }

    /**
     * Gets the value of the pattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Sets the value of the pattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPattern(String value) {
        this.pattern = value;
    }

    /**
     * Gets the value of the repositoryManage property.
     * 
     * @return
     *     possible object is
     *     {@link RepositoryManageTO }
     *     
     */
    public RepositoryManageTO getRepositoryManage() {
        return repositoryManage;
    }

    /**
     * Sets the value of the repositoryManage property.
     * 
     * @param value
     *     allowed object is
     *     {@link RepositoryManageTO }
     *     
     */
    public void setRepositoryManage(RepositoryManageTO value) {
        this.repositoryManage = value;
    }

    /**
     * Gets the value of the scale property.
     * 
     */
    public int getScale() {
        return scale;
    }

    /**
     * Sets the value of the scale property.
     * 
     */
    public void setScale(int value) {
        this.scale = value;
    }

    /**
     * Gets the value of the validator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidator() {
        return validator;
    }

    /**
     * Sets the value of the validator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidator(String value) {
        this.validator = value;
    }

    /**
     * Gets the value of the valueList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the valueList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValueList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FmsValueDefinitionTO }
     * 
     * 
     */
    public List<FmsValueDefinitionTO> getValueList() {
        if (valueList == null) {
            valueList = new ArrayList<FmsValueDefinitionTO>();
        }
        return this.valueList;
    }

    /**
     * Gets the value of the xmlRule property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXmlRule() {
        return xmlRule;
    }

    /**
     * Sets the value of the xmlRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXmlRule(String value) {
        this.xmlRule = value;
    }

}
