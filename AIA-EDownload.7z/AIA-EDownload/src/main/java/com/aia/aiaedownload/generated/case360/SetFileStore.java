
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setFileStore complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setFileStore"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileStoreTO_1" type="{http://filestore.sonora.eistream.com/}FileStoreTO"/&gt;
 *         &lt;element name="FileStoreTO_2" type="{http://filestore.sonora.eistream.com/}FileStoreTO"/&gt;
 *         &lt;element name="boolean_3" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setFileStore", propOrder = {
    "fileStoreTO1",
    "fileStoreTO2",
    "boolean3"
})
public class SetFileStore {

    @XmlElement(name = "FileStoreTO_1", required = true, nillable = true)
    protected FileStoreTO fileStoreTO1;
    @XmlElement(name = "FileStoreTO_2", required = true, nillable = true)
    protected FileStoreTO fileStoreTO2;
    @XmlElement(name = "boolean_3")
    protected boolean boolean3;

    /**
     * Gets the value of the fileStoreTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link FileStoreTO }
     *     
     */
    public FileStoreTO getFileStoreTO1() {
        return fileStoreTO1;
    }

    /**
     * Sets the value of the fileStoreTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileStoreTO }
     *     
     */
    public void setFileStoreTO1(FileStoreTO value) {
        this.fileStoreTO1 = value;
    }

    /**
     * Gets the value of the fileStoreTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link FileStoreTO }
     *     
     */
    public FileStoreTO getFileStoreTO2() {
        return fileStoreTO2;
    }

    /**
     * Sets the value of the fileStoreTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileStoreTO }
     *     
     */
    public void setFileStoreTO2(FileStoreTO value) {
        this.fileStoreTO2 = value;
    }

    /**
     * Gets the value of the boolean3 property.
     * 
     */
    public boolean isBoolean3() {
        return boolean3;
    }

    /**
     * Sets the value of the boolean3 property.
     * 
     */
    public void setBoolean3(boolean value) {
        this.boolean3 = value;
    }

}
