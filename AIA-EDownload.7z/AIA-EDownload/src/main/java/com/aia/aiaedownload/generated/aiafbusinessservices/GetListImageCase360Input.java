
package com.aia.aiaedownload.generated.aiafbusinessservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getListImageCase360Input complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getListImageCase360Input"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="overrideCredentials" type="{http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360}overrideCredentials"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="PolicyNum" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getListImageCase360Input", propOrder = {
    "overrideCredentials"
})
public class GetListImageCase360Input {

    @XmlElement(required = true, nillable = true)
    protected OverrideCredentials overrideCredentials;
    @XmlAttribute(name = "PolicyNum", required = true)
    protected String policyNum;

    /**
     * Gets the value of the overrideCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link OverrideCredentials }
     *     
     */
    public OverrideCredentials getOverrideCredentials() {
        return overrideCredentials;
    }

    /**
     * Sets the value of the overrideCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link OverrideCredentials }
     *     
     */
    public void setOverrideCredentials(OverrideCredentials value) {
        this.overrideCredentials = value;
    }

    /**
     * Gets the value of the policyNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyNum() {
        return policyNum;
    }

    /**
     * Sets the value of the policyNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyNum(String value) {
        this.policyNum = value;
    }

}
