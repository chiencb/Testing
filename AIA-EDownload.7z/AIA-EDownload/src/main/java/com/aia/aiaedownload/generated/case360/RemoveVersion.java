
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for removeVersion complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="removeVersion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileStoreTO_1" type="{http://filestore.sonora.eistream.com/}FileStoreTO"/&gt;
 *         &lt;element name="int_2" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "removeVersion", propOrder = {
    "fileStoreTO1",
    "int2"
})
public class RemoveVersion {

    @XmlElement(name = "FileStoreTO_1", required = true, nillable = true)
    protected FileStoreTO fileStoreTO1;
    @XmlElement(name = "int_2")
    protected int int2;

    /**
     * Gets the value of the fileStoreTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link FileStoreTO }
     *     
     */
    public FileStoreTO getFileStoreTO1() {
        return fileStoreTO1;
    }

    /**
     * Sets the value of the fileStoreTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileStoreTO }
     *     
     */
    public void setFileStoreTO1(FileStoreTO value) {
        this.fileStoreTO1 = value;
    }

    /**
     * Gets the value of the int2 property.
     * 
     */
    public int getInt2() {
        return int2;
    }

    /**
     * Sets the value of the int2 property.
     * 
     */
    public void setInt2(int value) {
        this.int2 = value;
    }

}
