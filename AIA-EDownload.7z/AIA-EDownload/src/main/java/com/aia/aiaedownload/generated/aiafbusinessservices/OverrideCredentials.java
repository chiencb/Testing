
package com.aia.aiaedownload.generated.aiafbusinessservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for overrideCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="overrideCredentials"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="_x0024_dbUser" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="_x0024_dbPassword" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "overrideCredentials", propOrder = {
    "x0024DbUser",
    "x0024DbPassword"
})
public class OverrideCredentials {

    @XmlElement(name = "_x0024_dbUser", required = true, nillable = true)
    protected String x0024DbUser;
    @XmlElement(name = "_x0024_dbPassword", required = true, nillable = true)
    protected String x0024DbPassword;

    /**
     * Gets the value of the x0024DbUser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX0024DbUser() {
        return x0024DbUser;
    }

    /**
     * Sets the value of the x0024DbUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX0024DbUser(String value) {
        this.x0024DbUser = value;
    }

    /**
     * Gets the value of the x0024DbPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX0024DbPassword() {
        return x0024DbPassword;
    }

    /**
     * Sets the value of the x0024DbPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX0024DbPassword(String value) {
        this.x0024DbPassword = value;
    }

}
