
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ContentConflictTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContentConflictTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="conflict" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="newContent" type="{http://contents.casefolder.sonora.eistream.com/}ContentTO"/&gt;
 *         &lt;element name="originalContent" type="{http://contents.casefolder.sonora.eistream.com/}ContentTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContentConflictTO", namespace = "http://contents.casefolder.sonora.eistream.com/", propOrder = {
    "conflict",
    "newContent",
    "originalContent"
})
public class ContentConflictTO {

    protected boolean conflict;
    @XmlElement(required = true, nillable = true)
    protected ContentTO newContent;
    @XmlElement(required = true, nillable = true)
    protected ContentTO originalContent;

    /**
     * Gets the value of the conflict property.
     * 
     */
    public boolean isConflict() {
        return conflict;
    }

    /**
     * Sets the value of the conflict property.
     * 
     */
    public void setConflict(boolean value) {
        this.conflict = value;
    }

    /**
     * Gets the value of the newContent property.
     * 
     * @return
     *     possible object is
     *     {@link ContentTO }
     *     
     */
    public ContentTO getNewContent() {
        return newContent;
    }

    /**
     * Sets the value of the newContent property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentTO }
     *     
     */
    public void setNewContent(ContentTO value) {
        this.newContent = value;
    }

    /**
     * Gets the value of the originalContent property.
     * 
     * @return
     *     possible object is
     *     {@link ContentTO }
     *     
     */
    public ContentTO getOriginalContent() {
        return originalContent;
    }

    /**
     * Sets the value of the originalContent property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentTO }
     *     
     */
    public void setOriginalContent(ContentTO value) {
        this.originalContent = value;
    }

}
