
package com.aia.aiaedownload.generated.aiafbusinessservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getListImageCase360Output complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getListImageCase360Output"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="resultOutput" type="{http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360}resultOutput" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getListImageCase360Output", propOrder = {
    "resultOutput"
})
public class GetListImageCase360Output {

    @XmlElement(required = true, nillable = true)
    protected List<ResultOutput> resultOutput;

    /**
     * Gets the value of the resultOutput property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the resultOutput property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResultOutput().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ResultOutput }
     * 
     * 
     */
    public List<ResultOutput> getResultOutput() {
        if (resultOutput == null) {
            resultOutput = new ArrayList<ResultOutput>();
        }
        return this.resultOutput;
    }

}
