
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setContent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setContent"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContentTO_1" type="{http://contents.casefolder.sonora.eistream.com/}ContentTO"/&gt;
 *         &lt;element name="ContentTO_2" type="{http://contents.casefolder.sonora.eistream.com/}ContentTO"/&gt;
 *         &lt;element name="boolean_3" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="BigDecimal_4" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setContent", propOrder = {
    "contentTO1",
    "contentTO2",
    "boolean3",
    "bigDecimal4"
})
public class SetContent {

    @XmlElement(name = "ContentTO_1", required = true, nillable = true)
    protected ContentTO contentTO1;
    @XmlElement(name = "ContentTO_2", required = true, nillable = true)
    protected ContentTO contentTO2;
    @XmlElement(name = "boolean_3")
    protected boolean boolean3;
    @XmlElement(name = "BigDecimal_4", required = true, nillable = true)
    protected BigDecimal bigDecimal4;

    /**
     * Gets the value of the contentTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link ContentTO }
     *     
     */
    public ContentTO getContentTO1() {
        return contentTO1;
    }

    /**
     * Sets the value of the contentTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentTO }
     *     
     */
    public void setContentTO1(ContentTO value) {
        this.contentTO1 = value;
    }

    /**
     * Gets the value of the contentTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link ContentTO }
     *     
     */
    public ContentTO getContentTO2() {
        return contentTO2;
    }

    /**
     * Sets the value of the contentTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContentTO }
     *     
     */
    public void setContentTO2(ContentTO value) {
        this.contentTO2 = value;
    }

    /**
     * Gets the value of the boolean3 property.
     * 
     */
    public boolean isBoolean3() {
        return boolean3;
    }

    /**
     * Sets the value of the boolean3 property.
     * 
     */
    public void setBoolean3(boolean value) {
        this.boolean3 = value;
    }

    /**
     * Gets the value of the bigDecimal4 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal4() {
        return bigDecimal4;
    }

    /**
     * Sets the value of the bigDecimal4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal4(BigDecimal value) {
        this.bigDecimal4 = value;
    }

}
