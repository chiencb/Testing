
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rpSet complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rpSet"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RepositoryItemTO_1" type="{http://repository.sonora.eistream.com/}RepositoryItemTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rpSet", propOrder = {
    "repositoryItemTO1"
})
public class RpSet {

    @XmlElement(name = "RepositoryItemTO_1", required = true, nillable = true)
    protected RepositoryItemTO repositoryItemTO1;

    /**
     * Gets the value of the repositoryItemTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link RepositoryItemTO }
     *     
     */
    public RepositoryItemTO getRepositoryItemTO1() {
        return repositoryItemTO1;
    }

    /**
     * Sets the value of the repositoryItemTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link RepositoryItemTO }
     *     
     */
    public void setRepositoryItemTO1(RepositoryItemTO value) {
        this.repositoryItemTO1 = value;
    }

}
