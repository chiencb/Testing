
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setCaseFolder complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setCaseFolder"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CaseFolderTO_1" type="{http://core.casefolder.sonora.eistream.com/}CaseFolderTO"/&gt;
 *         &lt;element name="CaseFolderTO_2" type="{http://core.casefolder.sonora.eistream.com/}CaseFolderTO"/&gt;
 *         &lt;element name="boolean_3" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setCaseFolder", propOrder = {
    "caseFolderTO1",
    "caseFolderTO2",
    "boolean3"
})
public class SetCaseFolder {

    @XmlElement(name = "CaseFolderTO_1", required = true, nillable = true)
    protected CaseFolderTO caseFolderTO1;
    @XmlElement(name = "CaseFolderTO_2", required = true, nillable = true)
    protected CaseFolderTO caseFolderTO2;
    @XmlElement(name = "boolean_3")
    protected boolean boolean3;

    /**
     * Gets the value of the caseFolderTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link CaseFolderTO }
     *     
     */
    public CaseFolderTO getCaseFolderTO1() {
        return caseFolderTO1;
    }

    /**
     * Sets the value of the caseFolderTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaseFolderTO }
     *     
     */
    public void setCaseFolderTO1(CaseFolderTO value) {
        this.caseFolderTO1 = value;
    }

    /**
     * Gets the value of the caseFolderTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link CaseFolderTO }
     *     
     */
    public CaseFolderTO getCaseFolderTO2() {
        return caseFolderTO2;
    }

    /**
     * Sets the value of the caseFolderTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaseFolderTO }
     *     
     */
    public void setCaseFolderTO2(CaseFolderTO value) {
        this.caseFolderTO2 = value;
    }

    /**
     * Gets the value of the boolean3 property.
     * 
     */
    public boolean isBoolean3() {
        return boolean3;
    }

    /**
     * Sets the value of the boolean3 property.
     * 
     */
    public void setBoolean3(boolean value) {
        this.boolean3 = value;
    }

}
