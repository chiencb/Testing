
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ColumnInfoTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ColumnInfoTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="columnData" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="columnDisplayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="columnHoverText" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="columnName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="columnOrder" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="columnStyle" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="columnUrl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="columnWidth" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="tableId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ColumnInfoTO", namespace = "http://query.sonora.eistream.com/", propOrder = {
    "columnData",
    "columnDisplayName",
    "columnHoverText",
    "columnName",
    "columnOrder",
    "columnStyle",
    "columnUrl",
    "columnWidth",
    "tableId"
})
public class ColumnInfoTO {

    protected boolean columnData;
    @XmlElement(required = true, nillable = true)
    protected String columnDisplayName;
    @XmlElement(required = true, nillable = true)
    protected String columnHoverText;
    @XmlElement(required = true, nillable = true)
    protected String columnName;
    protected int columnOrder;
    @XmlElement(required = true, nillable = true)
    protected String columnStyle;
    @XmlElement(required = true, nillable = true)
    protected String columnUrl;
    @XmlElement(required = true, nillable = true)
    protected String columnWidth;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal tableId;

    /**
     * Gets the value of the columnData property.
     * 
     */
    public boolean isColumnData() {
        return columnData;
    }

    /**
     * Sets the value of the columnData property.
     * 
     */
    public void setColumnData(boolean value) {
        this.columnData = value;
    }

    /**
     * Gets the value of the columnDisplayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnDisplayName() {
        return columnDisplayName;
    }

    /**
     * Sets the value of the columnDisplayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnDisplayName(String value) {
        this.columnDisplayName = value;
    }

    /**
     * Gets the value of the columnHoverText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnHoverText() {
        return columnHoverText;
    }

    /**
     * Sets the value of the columnHoverText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnHoverText(String value) {
        this.columnHoverText = value;
    }

    /**
     * Gets the value of the columnName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnName() {
        return columnName;
    }

    /**
     * Sets the value of the columnName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnName(String value) {
        this.columnName = value;
    }

    /**
     * Gets the value of the columnOrder property.
     * 
     */
    public int getColumnOrder() {
        return columnOrder;
    }

    /**
     * Sets the value of the columnOrder property.
     * 
     */
    public void setColumnOrder(int value) {
        this.columnOrder = value;
    }

    /**
     * Gets the value of the columnStyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnStyle() {
        return columnStyle;
    }

    /**
     * Sets the value of the columnStyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnStyle(String value) {
        this.columnStyle = value;
    }

    /**
     * Gets the value of the columnUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnUrl() {
        return columnUrl;
    }

    /**
     * Sets the value of the columnUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnUrl(String value) {
        this.columnUrl = value;
    }

    /**
     * Gets the value of the columnWidth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColumnWidth() {
        return columnWidth;
    }

    /**
     * Sets the value of the columnWidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColumnWidth(String value) {
        this.columnWidth = value;
    }

    /**
     * Gets the value of the tableId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTableId() {
        return tableId;
    }

    /**
     * Sets the value of the tableId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTableId(BigDecimal value) {
        this.tableId = value;
    }

}
