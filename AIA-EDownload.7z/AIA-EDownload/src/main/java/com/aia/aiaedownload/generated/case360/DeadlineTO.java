
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DeadlineTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeadlineTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="calendarAssignee" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="calendarName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="calendarUnit" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="date" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deadlineState" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="deadlineType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="defined" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="duration" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="satisfyCondition" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="triggerComponentType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="triggerDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="triggerElementID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="triggerElementName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="triggerEvent" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeadlineTO", namespace = "http://util.casefolder.sonora.eistream.com/", propOrder = {
    "calendarAssignee",
    "calendarName",
    "calendarUnit",
    "date",
    "deadlineState",
    "deadlineType",
    "defined",
    "duration",
    "satisfyCondition",
    "triggerComponentType",
    "triggerDate",
    "triggerElementID",
    "triggerElementName",
    "triggerEvent"
})
public class DeadlineTO {

    protected boolean calendarAssignee;
    @XmlElement(required = true, nillable = true)
    protected String calendarName;
    protected int calendarUnit;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar date;
    protected int deadlineState;
    protected int deadlineType;
    protected boolean defined;
    protected int duration;
    protected int satisfyCondition;
    protected int triggerComponentType;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar triggerDate;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal triggerElementID;
    @XmlElement(required = true, nillable = true)
    protected String triggerElementName;
    protected int triggerEvent;

    /**
     * Gets the value of the calendarAssignee property.
     * 
     */
    public boolean isCalendarAssignee() {
        return calendarAssignee;
    }

    /**
     * Sets the value of the calendarAssignee property.
     * 
     */
    public void setCalendarAssignee(boolean value) {
        this.calendarAssignee = value;
    }

    /**
     * Gets the value of the calendarName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalendarName() {
        return calendarName;
    }

    /**
     * Sets the value of the calendarName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalendarName(String value) {
        this.calendarName = value;
    }

    /**
     * Gets the value of the calendarUnit property.
     * 
     */
    public int getCalendarUnit() {
        return calendarUnit;
    }

    /**
     * Sets the value of the calendarUnit property.
     * 
     */
    public void setCalendarUnit(int value) {
        this.calendarUnit = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDate(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Gets the value of the deadlineState property.
     * 
     */
    public int getDeadlineState() {
        return deadlineState;
    }

    /**
     * Sets the value of the deadlineState property.
     * 
     */
    public void setDeadlineState(int value) {
        this.deadlineState = value;
    }

    /**
     * Gets the value of the deadlineType property.
     * 
     */
    public int getDeadlineType() {
        return deadlineType;
    }

    /**
     * Sets the value of the deadlineType property.
     * 
     */
    public void setDeadlineType(int value) {
        this.deadlineType = value;
    }

    /**
     * Gets the value of the defined property.
     * 
     */
    public boolean isDefined() {
        return defined;
    }

    /**
     * Sets the value of the defined property.
     * 
     */
    public void setDefined(boolean value) {
        this.defined = value;
    }

    /**
     * Gets the value of the duration property.
     * 
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Sets the value of the duration property.
     * 
     */
    public void setDuration(int value) {
        this.duration = value;
    }

    /**
     * Gets the value of the satisfyCondition property.
     * 
     */
    public int getSatisfyCondition() {
        return satisfyCondition;
    }

    /**
     * Sets the value of the satisfyCondition property.
     * 
     */
    public void setSatisfyCondition(int value) {
        this.satisfyCondition = value;
    }

    /**
     * Gets the value of the triggerComponentType property.
     * 
     */
    public int getTriggerComponentType() {
        return triggerComponentType;
    }

    /**
     * Sets the value of the triggerComponentType property.
     * 
     */
    public void setTriggerComponentType(int value) {
        this.triggerComponentType = value;
    }

    /**
     * Gets the value of the triggerDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTriggerDate() {
        return triggerDate;
    }

    /**
     * Sets the value of the triggerDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTriggerDate(XMLGregorianCalendar value) {
        this.triggerDate = value;
    }

    /**
     * Gets the value of the triggerElementID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTriggerElementID() {
        return triggerElementID;
    }

    /**
     * Sets the value of the triggerElementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTriggerElementID(BigDecimal value) {
        this.triggerElementID = value;
    }

    /**
     * Gets the value of the triggerElementName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTriggerElementName() {
        return triggerElementName;
    }

    /**
     * Sets the value of the triggerElementName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTriggerElementName(String value) {
        this.triggerElementName = value;
    }

    /**
     * Gets the value of the triggerEvent property.
     * 
     */
    public int getTriggerEvent() {
        return triggerEvent;
    }

    /**
     * Sets the value of the triggerEvent property.
     * 
     */
    public void setTriggerEvent(int value) {
        this.triggerEvent = value;
    }

}
