
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RepositoryItemTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RepositoryItemTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="collection" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="propertyCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="propertyDefinitions" type="{http://repository.sonora.eistream.com/}RepositoryPropertyDefinitionTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="propertyRowCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="propertyRows" type="{http://repository.sonora.eistream.com/}RepositoryPropertyRowTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="repositoryItemType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RepositoryItemTO", namespace = "http://repository.sonora.eistream.com/", propOrder = {
    "collection",
    "id",
    "propertyCount",
    "propertyDefinitions",
    "propertyRowCount",
    "propertyRows",
    "repositoryItemType"
})
public class RepositoryItemTO {

    protected boolean collection;
    @XmlElement(required = true, nillable = true)
    protected String id;
    protected int propertyCount;
    @XmlElement(nillable = true)
    protected List<RepositoryPropertyDefinitionTO> propertyDefinitions;
    protected int propertyRowCount;
    @XmlElement(nillable = true)
    protected List<RepositoryPropertyRowTO> propertyRows;
    @XmlElement(required = true, nillable = true)
    protected String repositoryItemType;

    /**
     * Gets the value of the collection property.
     * 
     */
    public boolean isCollection() {
        return collection;
    }

    /**
     * Sets the value of the collection property.
     * 
     */
    public void setCollection(boolean value) {
        this.collection = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the propertyCount property.
     * 
     */
    public int getPropertyCount() {
        return propertyCount;
    }

    /**
     * Sets the value of the propertyCount property.
     * 
     */
    public void setPropertyCount(int value) {
        this.propertyCount = value;
    }

    /**
     * Gets the value of the propertyDefinitions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the propertyDefinitions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPropertyDefinitions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RepositoryPropertyDefinitionTO }
     * 
     * 
     */
    public List<RepositoryPropertyDefinitionTO> getPropertyDefinitions() {
        if (propertyDefinitions == null) {
            propertyDefinitions = new ArrayList<RepositoryPropertyDefinitionTO>();
        }
        return this.propertyDefinitions;
    }

    /**
     * Gets the value of the propertyRowCount property.
     * 
     */
    public int getPropertyRowCount() {
        return propertyRowCount;
    }

    /**
     * Sets the value of the propertyRowCount property.
     * 
     */
    public void setPropertyRowCount(int value) {
        this.propertyRowCount = value;
    }

    /**
     * Gets the value of the propertyRows property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the propertyRows property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPropertyRows().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RepositoryPropertyRowTO }
     * 
     * 
     */
    public List<RepositoryPropertyRowTO> getPropertyRows() {
        if (propertyRows == null) {
            propertyRows = new ArrayList<RepositoryPropertyRowTO>();
        }
        return this.propertyRows;
    }

    /**
     * Gets the value of the repositoryItemType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepositoryItemType() {
        return repositoryItemType;
    }

    /**
     * Sets the value of the repositoryItemType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepositoryItemType(String value) {
        this.repositoryItemType = value;
    }

}
