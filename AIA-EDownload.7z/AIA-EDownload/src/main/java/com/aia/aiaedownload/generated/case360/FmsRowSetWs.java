
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FmsRowSetWs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FmsRowSetWs"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fieldCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="relationCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="relationList" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="repositoryId" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="resultFields" type="{http://fields.sonora.eistream.com/}FmsFieldMetaDataWs" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="resultRows" type="{http://fields.sonora.eistream.com/}FmsRowWs" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="rowCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="tableId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FmsRowSetWs", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "fieldCount",
    "relationCount",
    "relationList",
    "repositoryId",
    "resultFields",
    "resultRows",
    "rowCount",
    "tableId"
})
public class FmsRowSetWs {

    protected int fieldCount;
    protected int relationCount;
    @XmlElement(nillable = true)
    protected List<String> relationList;
    protected int repositoryId;
    @XmlElement(nillable = true)
    protected List<FmsFieldMetaDataWs> resultFields;
    @XmlElement(nillable = true)
    protected List<FmsRowWs> resultRows;
    protected int rowCount;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal tableId;

    /**
     * Gets the value of the fieldCount property.
     * 
     */
    public int getFieldCount() {
        return fieldCount;
    }

    /**
     * Sets the value of the fieldCount property.
     * 
     */
    public void setFieldCount(int value) {
        this.fieldCount = value;
    }

    /**
     * Gets the value of the relationCount property.
     * 
     */
    public int getRelationCount() {
        return relationCount;
    }

    /**
     * Sets the value of the relationCount property.
     * 
     */
    public void setRelationCount(int value) {
        this.relationCount = value;
    }

    /**
     * Gets the value of the relationList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relationList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelationList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRelationList() {
        if (relationList == null) {
            relationList = new ArrayList<String>();
        }
        return this.relationList;
    }

    /**
     * Gets the value of the repositoryId property.
     * 
     */
    public int getRepositoryId() {
        return repositoryId;
    }

    /**
     * Sets the value of the repositoryId property.
     * 
     */
    public void setRepositoryId(int value) {
        this.repositoryId = value;
    }

    /**
     * Gets the value of the resultFields property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the resultFields property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResultFields().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FmsFieldMetaDataWs }
     * 
     * 
     */
    public List<FmsFieldMetaDataWs> getResultFields() {
        if (resultFields == null) {
            resultFields = new ArrayList<FmsFieldMetaDataWs>();
        }
        return this.resultFields;
    }

    /**
     * Gets the value of the resultRows property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the resultRows property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResultRows().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FmsRowWs }
     * 
     * 
     */
    public List<FmsRowWs> getResultRows() {
        if (resultRows == null) {
            resultRows = new ArrayList<FmsRowWs>();
        }
        return this.resultRows;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     */
    public void setRowCount(int value) {
        this.rowCount = value;
    }

    /**
     * Gets the value of the tableId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTableId() {
        return tableId;
    }

    /**
     * Sets the value of the tableId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTableId(BigDecimal value) {
        this.tableId = value;
    }

}
