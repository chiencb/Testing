
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ContentTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContentTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="assignee" type="{http://util.casefolder.sonora.eistream.com/}AssigneeTO"/&gt;
 *         &lt;element name="capabilities" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="comments" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="componentElementID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="deadline" type="{http://util.casefolder.sonora.eistream.com/}DeadlineTO"/&gt;
 *         &lt;element name="deferredCreate" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="displayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="displayOrder" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="documentURL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="elementType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="eventName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="eventText" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fillKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fillOption" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="linked" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="parentCasefolderRepositoryKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="propForm" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="repositoryDocID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="rowID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="status" type="{http://util.casefolder.sonora.eistream.com/}StatusTO"/&gt;
 *         &lt;element name="tableID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="templateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="viewInFrame" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContentTO", namespace = "http://contents.casefolder.sonora.eistream.com/", propOrder = {
    "acl",
    "assignee",
    "capabilities",
    "comments",
    "componentElementID",
    "deadline",
    "deferredCreate",
    "displayName",
    "displayOrder",
    "documentId",
    "documentURL",
    "elementType",
    "eventName",
    "eventText",
    "fillKey",
    "fillOption",
    "id",
    "linked",
    "modifiedBy",
    "modifiedDateTime",
    "name",
    "parentCasefolderRepositoryKey",
    "partitionName",
    "propForm",
    "repositoryDocID",
    "rowID",
    "status",
    "tableID",
    "templateID",
    "viewInFrame"
})
public class ContentTO {

    @XmlElement(required = true, nillable = true)
    protected String acl;
    @XmlElement(required = true, nillable = true)
    protected AssigneeTO assignee;
    @XmlElement(required = true, nillable = true)
    protected String capabilities;
    @XmlElement(required = true, nillable = true)
    protected String comments;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentElementID;
    @XmlElement(required = true, nillable = true)
    protected DeadlineTO deadline;
    protected boolean deferredCreate;
    @XmlElement(required = true, nillable = true)
    protected String displayName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal displayOrder;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal documentId;
    @XmlElement(required = true, nillable = true)
    protected String documentURL;
    protected int elementType;
    @XmlElement(required = true, nillable = true)
    protected String eventName;
    @XmlElement(required = true, nillable = true)
    protected String eventText;
    @XmlElement(required = true, nillable = true)
    protected String fillKey;
    protected int fillOption;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal id;
    protected boolean linked;
    @XmlElement(required = true, nillable = true)
    protected String modifiedBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    @XmlElement(required = true, nillable = true)
    protected String name;
    @XmlElement(required = true, nillable = true)
    protected String parentCasefolderRepositoryKey;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    @XmlElement(required = true, nillable = true)
    protected String propForm;
    @XmlElement(required = true, nillable = true)
    protected String repositoryDocID;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal rowID;
    @XmlElement(required = true, nillable = true)
    protected StatusTO status;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal tableID;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal templateID;
    @XmlElement(required = true, nillable = true)
    protected String viewInFrame;

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the assignee property.
     * 
     * @return
     *     possible object is
     *     {@link AssigneeTO }
     *     
     */
    public AssigneeTO getAssignee() {
        return assignee;
    }

    /**
     * Sets the value of the assignee property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssigneeTO }
     *     
     */
    public void setAssignee(AssigneeTO value) {
        this.assignee = value;
    }

    /**
     * Gets the value of the capabilities property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapabilities() {
        return capabilities;
    }

    /**
     * Sets the value of the capabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapabilities(String value) {
        this.capabilities = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the componentElementID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentElementID() {
        return componentElementID;
    }

    /**
     * Sets the value of the componentElementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentElementID(BigDecimal value) {
        this.componentElementID = value;
    }

    /**
     * Gets the value of the deadline property.
     * 
     * @return
     *     possible object is
     *     {@link DeadlineTO }
     *     
     */
    public DeadlineTO getDeadline() {
        return deadline;
    }

    /**
     * Sets the value of the deadline property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeadlineTO }
     *     
     */
    public void setDeadline(DeadlineTO value) {
        this.deadline = value;
    }

    /**
     * Gets the value of the deferredCreate property.
     * 
     */
    public boolean isDeferredCreate() {
        return deferredCreate;
    }

    /**
     * Sets the value of the deferredCreate property.
     * 
     */
    public void setDeferredCreate(boolean value) {
        this.deferredCreate = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the displayOrder property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the value of the displayOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDisplayOrder(BigDecimal value) {
        this.displayOrder = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocumentId(BigDecimal value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the documentURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentURL() {
        return documentURL;
    }

    /**
     * Sets the value of the documentURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentURL(String value) {
        this.documentURL = value;
    }

    /**
     * Gets the value of the elementType property.
     * 
     */
    public int getElementType() {
        return elementType;
    }

    /**
     * Sets the value of the elementType property.
     * 
     */
    public void setElementType(int value) {
        this.elementType = value;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the eventText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventText() {
        return eventText;
    }

    /**
     * Sets the value of the eventText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventText(String value) {
        this.eventText = value;
    }

    /**
     * Gets the value of the fillKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFillKey() {
        return fillKey;
    }

    /**
     * Sets the value of the fillKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFillKey(String value) {
        this.fillKey = value;
    }

    /**
     * Gets the value of the fillOption property.
     * 
     */
    public int getFillOption() {
        return fillOption;
    }

    /**
     * Sets the value of the fillOption property.
     * 
     */
    public void setFillOption(int value) {
        this.fillOption = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setId(BigDecimal value) {
        this.id = value;
    }

    /**
     * Gets the value of the linked property.
     * 
     */
    public boolean isLinked() {
        return linked;
    }

    /**
     * Sets the value of the linked property.
     * 
     */
    public void setLinked(boolean value) {
        this.linked = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the parentCasefolderRepositoryKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentCasefolderRepositoryKey() {
        return parentCasefolderRepositoryKey;
    }

    /**
     * Sets the value of the parentCasefolderRepositoryKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentCasefolderRepositoryKey(String value) {
        this.parentCasefolderRepositoryKey = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the propForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropForm() {
        return propForm;
    }

    /**
     * Sets the value of the propForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropForm(String value) {
        this.propForm = value;
    }

    /**
     * Gets the value of the repositoryDocID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepositoryDocID() {
        return repositoryDocID;
    }

    /**
     * Sets the value of the repositoryDocID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepositoryDocID(String value) {
        this.repositoryDocID = value;
    }

    /**
     * Gets the value of the rowID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRowID() {
        return rowID;
    }

    /**
     * Sets the value of the rowID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRowID(BigDecimal value) {
        this.rowID = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusTO }
     *     
     */
    public StatusTO getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusTO }
     *     
     */
    public void setStatus(StatusTO value) {
        this.status = value;
    }

    /**
     * Gets the value of the tableID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTableID() {
        return tableID;
    }

    /**
     * Sets the value of the tableID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTableID(BigDecimal value) {
        this.tableID = value;
    }

    /**
     * Gets the value of the templateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTemplateID() {
        return templateID;
    }

    /**
     * Sets the value of the templateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTemplateID(BigDecimal value) {
        this.templateID = value;
    }

    /**
     * Gets the value of the viewInFrame property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getViewInFrame() {
        return viewInFrame;
    }

    /**
     * Sets the value of the viewInFrame property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setViewInFrame(String value) {
        this.viewInFrame = value;
    }

}
