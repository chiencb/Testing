
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FmsRowConflictTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FmsRowConflictTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="conflictArray" type="{http://www.w3.org/2001/XMLSchema}boolean" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="conflictCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="databaseRow" type="{http://fields.sonora.eistream.com/}FmsRowTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FmsRowConflictTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "conflictArray",
    "conflictCount",
    "databaseRow"
})
public class FmsRowConflictTO {

    @XmlElement(type = Boolean.class)
    protected List<Boolean> conflictArray;
    protected int conflictCount;
    @XmlElement(required = true, nillable = true)
    protected FmsRowTO databaseRow;

    /**
     * Gets the value of the conflictArray property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the conflictArray property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConflictArray().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Boolean }
     * 
     * 
     */
    public List<Boolean> getConflictArray() {
        if (conflictArray == null) {
            conflictArray = new ArrayList<Boolean>();
        }
        return this.conflictArray;
    }

    /**
     * Gets the value of the conflictCount property.
     * 
     */
    public int getConflictCount() {
        return conflictCount;
    }

    /**
     * Sets the value of the conflictCount property.
     * 
     */
    public void setConflictCount(int value) {
        this.conflictCount = value;
    }

    /**
     * Gets the value of the databaseRow property.
     * 
     * @return
     *     possible object is
     *     {@link FmsRowTO }
     *     
     */
    public FmsRowTO getDatabaseRow() {
        return databaseRow;
    }

    /**
     * Sets the value of the databaseRow property.
     * 
     * @param value
     *     allowed object is
     *     {@link FmsRowTO }
     *     
     */
    public void setDatabaseRow(FmsRowTO value) {
        this.databaseRow = value;
    }

}
