
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for putFileBuddyInCapture complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="putFileBuddyInCapture"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="String_1" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="arrayOfbyte_2" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *         &lt;element name="String_3" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="String_4" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "putFileBuddyInCapture", propOrder = {
    "string1",
    "arrayOfbyte2",
    "string3",
    "string4"
})
public class PutFileBuddyInCapture {

    @XmlElement(name = "String_1", required = true, nillable = true)
    protected String string1;
    @XmlElement(name = "arrayOfbyte_2", required = true, nillable = true)
    protected byte[] arrayOfbyte2;
    @XmlElement(name = "String_3", required = true, nillable = true)
    protected String string3;
    @XmlElement(name = "String_4", required = true, nillable = true)
    protected String string4;

    /**
     * Gets the value of the string1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString1() {
        return string1;
    }

    /**
     * Sets the value of the string1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString1(String value) {
        this.string1 = value;
    }

    /**
     * Gets the value of the arrayOfbyte2 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getArrayOfbyte2() {
        return arrayOfbyte2;
    }

    /**
     * Sets the value of the arrayOfbyte2 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setArrayOfbyte2(byte[] value) {
        this.arrayOfbyte2 = value;
    }

    /**
     * Gets the value of the string3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString3() {
        return string3;
    }

    /**
     * Sets the value of the string3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString3(String value) {
        this.string3 = value;
    }

    /**
     * Gets the value of the string4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString4() {
        return string4;
    }

    /**
     * Sets the value of the string4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString4(String value) {
        this.string4 = value;
    }

}
