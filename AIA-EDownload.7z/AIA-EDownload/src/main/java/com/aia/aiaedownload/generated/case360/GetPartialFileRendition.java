
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getPartialFileRendition complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getPartialFileRendition"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BigDecimal_1" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="int_2" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="long_3" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="int_4" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="String_5" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getPartialFileRendition", propOrder = {
    "bigDecimal1",
    "int2",
    "long3",
    "int4",
    "string5"
})
public class GetPartialFileRendition {

    @XmlElement(name = "BigDecimal_1", required = true, nillable = true)
    protected BigDecimal bigDecimal1;
    @XmlElement(name = "int_2")
    protected int int2;
    @XmlElement(name = "long_3")
    protected long long3;
    @XmlElement(name = "int_4")
    protected int int4;
    @XmlElement(name = "String_5", required = true, nillable = true)
    protected String string5;

    /**
     * Gets the value of the bigDecimal1 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal1() {
        return bigDecimal1;
    }

    /**
     * Sets the value of the bigDecimal1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal1(BigDecimal value) {
        this.bigDecimal1 = value;
    }

    /**
     * Gets the value of the int2 property.
     * 
     */
    public int getInt2() {
        return int2;
    }

    /**
     * Sets the value of the int2 property.
     * 
     */
    public void setInt2(int value) {
        this.int2 = value;
    }

    /**
     * Gets the value of the long3 property.
     * 
     */
    public long getLong3() {
        return long3;
    }

    /**
     * Sets the value of the long3 property.
     * 
     */
    public void setLong3(long value) {
        this.long3 = value;
    }

    /**
     * Gets the value of the int4 property.
     * 
     */
    public int getInt4() {
        return int4;
    }

    /**
     * Sets the value of the int4 property.
     * 
     */
    public void setInt4(int value) {
        this.int4 = value;
    }

    /**
     * Gets the value of the string5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString5() {
        return string5;
    }

    /**
     * Sets the value of the string5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString5(String value) {
        this.string5 = value;
    }

}
