
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CaseFolderTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaseFolderTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="alertRecycling" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="applicationName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="archiveTemplateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="calendarExpression" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="capabilities" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="caseFolderID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="caseOwner" type="{http://util.casefolder.sonora.eistream.com/}AssigneeTO"/&gt;
 *         &lt;element name="chartJspPrefix" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="componentDefId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="componentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="contentForms" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="contentsACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="copyDiscussions" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createdDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deadline" type="{http://util.casefolder.sonora.eistream.com/}DeadlineTO"/&gt;
 *         &lt;element name="discussionForms" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="discussionsACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="displayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="elementType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="enableSubscribe" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="enhancedSecurityEnabled" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="eventName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="eventText" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fieldsACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="filePlanViewId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="fmsID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="frameSet" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="hidden" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="historyACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="iconName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="instancesACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="listIDs" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="notes" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="numberOfDaystoWarn" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="prismDataFields" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="prismEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="prismEventsSent" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="propForm" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="published" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="readOnlyHistory" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="sendOnAssignment" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="sendToAssignee" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="sendToCaseOwner" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="sendToList" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="sendToManager" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="status" type="{http://util.casefolder.sonora.eistream.com/}StatusTO"/&gt;
 *         &lt;element name="subscribeContent" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="taskForms" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="tasksACL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="templateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="templateName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="whatsNew" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaseFolderTO", namespace = "http://core.casefolder.sonora.eistream.com/", propOrder = {
    "uuid",
    "acl",
    "alertRecycling",
    "applicationName",
    "archiveTemplateID",
    "calendarExpression",
    "capabilities",
    "caseFolderID",
    "caseOwner",
    "chartJspPrefix",
    "componentDefId",
    "componentId",
    "contentForms",
    "contentsACL",
    "copyDiscussions",
    "createdBy",
    "createdDateTime",
    "deadline",
    "discussionForms",
    "discussionsACL",
    "displayName",
    "elementType",
    "enableSubscribe",
    "enhancedSecurityEnabled",
    "eventName",
    "eventText",
    "fieldsACL",
    "filePlanViewId",
    "fmsID",
    "frameSet",
    "hidden",
    "historyACL",
    "iconName",
    "instancesACL",
    "listIDs",
    "modifiedBy",
    "modifiedDateTime",
    "notes",
    "numberOfDaystoWarn",
    "partitionName",
    "prismDataFields",
    "prismEnabled",
    "prismEventsSent",
    "propForm",
    "published",
    "readOnlyHistory",
    "sendOnAssignment",
    "sendToAssignee",
    "sendToCaseOwner",
    "sendToList",
    "sendToManager",
    "status",
    "subscribeContent",
    "taskForms",
    "tasksACL",
    "templateID",
    "templateName",
    "whatsNew"
})
public class CaseFolderTO {

    @XmlElement(name = "UUID", required = true, nillable = true)
    protected String uuid;
    @XmlElement(required = true, nillable = true)
    protected String acl;
    protected int alertRecycling;
    @XmlElement(required = true, nillable = true)
    protected String applicationName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal archiveTemplateID;
    @XmlElement(required = true, nillable = true)
    protected String calendarExpression;
    @XmlElement(required = true, nillable = true)
    protected String capabilities;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal caseFolderID;
    @XmlElement(required = true, nillable = true)
    protected AssigneeTO caseOwner;
    @XmlElement(required = true, nillable = true)
    protected String chartJspPrefix;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentDefId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentId;
    @XmlElement(required = true, nillable = true)
    protected String contentForms;
    @XmlElement(required = true, nillable = true)
    protected String contentsACL;
    protected boolean copyDiscussions;
    @XmlElement(required = true, nillable = true)
    protected String createdBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDateTime;
    @XmlElement(required = true, nillable = true)
    protected DeadlineTO deadline;
    @XmlElement(required = true, nillable = true)
    protected String discussionForms;
    @XmlElement(required = true, nillable = true)
    protected String discussionsACL;
    @XmlElement(required = true, nillable = true)
    protected String displayName;
    protected int elementType;
    protected boolean enableSubscribe;
    protected int enhancedSecurityEnabled;
    @XmlElement(required = true, nillable = true)
    protected String eventName;
    @XmlElement(required = true, nillable = true)
    protected String eventText;
    @XmlElement(required = true, nillable = true)
    protected String fieldsACL;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal filePlanViewId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal fmsID;
    @XmlElement(required = true, nillable = true)
    protected String frameSet;
    protected boolean hidden;
    @XmlElement(required = true, nillable = true)
    protected String historyACL;
    @XmlElement(required = true, nillable = true)
    protected String iconName;
    @XmlElement(required = true, nillable = true)
    protected String instancesACL;
    @XmlElement(required = true, nillable = true)
    protected String listIDs;
    @XmlElement(required = true, nillable = true)
    protected String modifiedBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    @XmlElement(required = true, nillable = true)
    protected String notes;
    protected int numberOfDaystoWarn;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    @XmlElement(required = true, nillable = true)
    protected String prismDataFields;
    protected boolean prismEnabled;
    protected boolean prismEventsSent;
    @XmlElement(required = true, nillable = true)
    protected String propForm;
    protected boolean published;
    protected boolean readOnlyHistory;
    protected boolean sendOnAssignment;
    protected boolean sendToAssignee;
    protected boolean sendToCaseOwner;
    protected boolean sendToList;
    protected boolean sendToManager;
    @XmlElement(required = true, nillable = true)
    protected StatusTO status;
    protected boolean subscribeContent;
    @XmlElement(required = true, nillable = true)
    protected String taskForms;
    @XmlElement(required = true, nillable = true)
    protected String tasksACL;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal templateID;
    @XmlElement(required = true, nillable = true)
    protected String templateName;
    protected boolean whatsNew;

    /**
     * Gets the value of the uuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUUID() {
        return uuid;
    }

    /**
     * Sets the value of the uuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUUID(String value) {
        this.uuid = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the alertRecycling property.
     * 
     */
    public int getAlertRecycling() {
        return alertRecycling;
    }

    /**
     * Sets the value of the alertRecycling property.
     * 
     */
    public void setAlertRecycling(int value) {
        this.alertRecycling = value;
    }

    /**
     * Gets the value of the applicationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Sets the value of the applicationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationName(String value) {
        this.applicationName = value;
    }

    /**
     * Gets the value of the archiveTemplateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getArchiveTemplateID() {
        return archiveTemplateID;
    }

    /**
     * Sets the value of the archiveTemplateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setArchiveTemplateID(BigDecimal value) {
        this.archiveTemplateID = value;
    }

    /**
     * Gets the value of the calendarExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalendarExpression() {
        return calendarExpression;
    }

    /**
     * Sets the value of the calendarExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalendarExpression(String value) {
        this.calendarExpression = value;
    }

    /**
     * Gets the value of the capabilities property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapabilities() {
        return capabilities;
    }

    /**
     * Sets the value of the capabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapabilities(String value) {
        this.capabilities = value;
    }

    /**
     * Gets the value of the caseFolderID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCaseFolderID() {
        return caseFolderID;
    }

    /**
     * Sets the value of the caseFolderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCaseFolderID(BigDecimal value) {
        this.caseFolderID = value;
    }

    /**
     * Gets the value of the caseOwner property.
     * 
     * @return
     *     possible object is
     *     {@link AssigneeTO }
     *     
     */
    public AssigneeTO getCaseOwner() {
        return caseOwner;
    }

    /**
     * Sets the value of the caseOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssigneeTO }
     *     
     */
    public void setCaseOwner(AssigneeTO value) {
        this.caseOwner = value;
    }

    /**
     * Gets the value of the chartJspPrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChartJspPrefix() {
        return chartJspPrefix;
    }

    /**
     * Sets the value of the chartJspPrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChartJspPrefix(String value) {
        this.chartJspPrefix = value;
    }

    /**
     * Gets the value of the componentDefId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentDefId() {
        return componentDefId;
    }

    /**
     * Sets the value of the componentDefId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentDefId(BigDecimal value) {
        this.componentDefId = value;
    }

    /**
     * Gets the value of the componentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentId() {
        return componentId;
    }

    /**
     * Sets the value of the componentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentId(BigDecimal value) {
        this.componentId = value;
    }

    /**
     * Gets the value of the contentForms property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentForms() {
        return contentForms;
    }

    /**
     * Sets the value of the contentForms property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentForms(String value) {
        this.contentForms = value;
    }

    /**
     * Gets the value of the contentsACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContentsACL() {
        return contentsACL;
    }

    /**
     * Sets the value of the contentsACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContentsACL(String value) {
        this.contentsACL = value;
    }

    /**
     * Gets the value of the copyDiscussions property.
     * 
     */
    public boolean isCopyDiscussions() {
        return copyDiscussions;
    }

    /**
     * Sets the value of the copyDiscussions property.
     * 
     */
    public void setCopyDiscussions(boolean value) {
        this.copyDiscussions = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * Sets the value of the createdDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDateTime(XMLGregorianCalendar value) {
        this.createdDateTime = value;
    }

    /**
     * Gets the value of the deadline property.
     * 
     * @return
     *     possible object is
     *     {@link DeadlineTO }
     *     
     */
    public DeadlineTO getDeadline() {
        return deadline;
    }

    /**
     * Sets the value of the deadline property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeadlineTO }
     *     
     */
    public void setDeadline(DeadlineTO value) {
        this.deadline = value;
    }

    /**
     * Gets the value of the discussionForms property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscussionForms() {
        return discussionForms;
    }

    /**
     * Sets the value of the discussionForms property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscussionForms(String value) {
        this.discussionForms = value;
    }

    /**
     * Gets the value of the discussionsACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscussionsACL() {
        return discussionsACL;
    }

    /**
     * Sets the value of the discussionsACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscussionsACL(String value) {
        this.discussionsACL = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the elementType property.
     * 
     */
    public int getElementType() {
        return elementType;
    }

    /**
     * Sets the value of the elementType property.
     * 
     */
    public void setElementType(int value) {
        this.elementType = value;
    }

    /**
     * Gets the value of the enableSubscribe property.
     * 
     */
    public boolean isEnableSubscribe() {
        return enableSubscribe;
    }

    /**
     * Sets the value of the enableSubscribe property.
     * 
     */
    public void setEnableSubscribe(boolean value) {
        this.enableSubscribe = value;
    }

    /**
     * Gets the value of the enhancedSecurityEnabled property.
     * 
     */
    public int getEnhancedSecurityEnabled() {
        return enhancedSecurityEnabled;
    }

    /**
     * Sets the value of the enhancedSecurityEnabled property.
     * 
     */
    public void setEnhancedSecurityEnabled(int value) {
        this.enhancedSecurityEnabled = value;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the eventText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventText() {
        return eventText;
    }

    /**
     * Sets the value of the eventText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventText(String value) {
        this.eventText = value;
    }

    /**
     * Gets the value of the fieldsACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldsACL() {
        return fieldsACL;
    }

    /**
     * Sets the value of the fieldsACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldsACL(String value) {
        this.fieldsACL = value;
    }

    /**
     * Gets the value of the filePlanViewId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFilePlanViewId() {
        return filePlanViewId;
    }

    /**
     * Sets the value of the filePlanViewId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFilePlanViewId(BigDecimal value) {
        this.filePlanViewId = value;
    }

    /**
     * Gets the value of the fmsID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFmsID() {
        return fmsID;
    }

    /**
     * Sets the value of the fmsID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFmsID(BigDecimal value) {
        this.fmsID = value;
    }

    /**
     * Gets the value of the frameSet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrameSet() {
        return frameSet;
    }

    /**
     * Sets the value of the frameSet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrameSet(String value) {
        this.frameSet = value;
    }

    /**
     * Gets the value of the hidden property.
     * 
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Sets the value of the hidden property.
     * 
     */
    public void setHidden(boolean value) {
        this.hidden = value;
    }

    /**
     * Gets the value of the historyACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHistoryACL() {
        return historyACL;
    }

    /**
     * Sets the value of the historyACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHistoryACL(String value) {
        this.historyACL = value;
    }

    /**
     * Gets the value of the iconName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIconName() {
        return iconName;
    }

    /**
     * Sets the value of the iconName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIconName(String value) {
        this.iconName = value;
    }

    /**
     * Gets the value of the instancesACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstancesACL() {
        return instancesACL;
    }

    /**
     * Sets the value of the instancesACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstancesACL(String value) {
        this.instancesACL = value;
    }

    /**
     * Gets the value of the listIDs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListIDs() {
        return listIDs;
    }

    /**
     * Sets the value of the listIDs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListIDs(String value) {
        this.listIDs = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotes(String value) {
        this.notes = value;
    }

    /**
     * Gets the value of the numberOfDaystoWarn property.
     * 
     */
    public int getNumberOfDaystoWarn() {
        return numberOfDaystoWarn;
    }

    /**
     * Sets the value of the numberOfDaystoWarn property.
     * 
     */
    public void setNumberOfDaystoWarn(int value) {
        this.numberOfDaystoWarn = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the prismDataFields property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrismDataFields() {
        return prismDataFields;
    }

    /**
     * Sets the value of the prismDataFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrismDataFields(String value) {
        this.prismDataFields = value;
    }

    /**
     * Gets the value of the prismEnabled property.
     * 
     */
    public boolean isPrismEnabled() {
        return prismEnabled;
    }

    /**
     * Sets the value of the prismEnabled property.
     * 
     */
    public void setPrismEnabled(boolean value) {
        this.prismEnabled = value;
    }

    /**
     * Gets the value of the prismEventsSent property.
     * 
     */
    public boolean isPrismEventsSent() {
        return prismEventsSent;
    }

    /**
     * Sets the value of the prismEventsSent property.
     * 
     */
    public void setPrismEventsSent(boolean value) {
        this.prismEventsSent = value;
    }

    /**
     * Gets the value of the propForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropForm() {
        return propForm;
    }

    /**
     * Sets the value of the propForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropForm(String value) {
        this.propForm = value;
    }

    /**
     * Gets the value of the published property.
     * 
     */
    public boolean isPublished() {
        return published;
    }

    /**
     * Sets the value of the published property.
     * 
     */
    public void setPublished(boolean value) {
        this.published = value;
    }

    /**
     * Gets the value of the readOnlyHistory property.
     * 
     */
    public boolean isReadOnlyHistory() {
        return readOnlyHistory;
    }

    /**
     * Sets the value of the readOnlyHistory property.
     * 
     */
    public void setReadOnlyHistory(boolean value) {
        this.readOnlyHistory = value;
    }

    /**
     * Gets the value of the sendOnAssignment property.
     * 
     */
    public boolean isSendOnAssignment() {
        return sendOnAssignment;
    }

    /**
     * Sets the value of the sendOnAssignment property.
     * 
     */
    public void setSendOnAssignment(boolean value) {
        this.sendOnAssignment = value;
    }

    /**
     * Gets the value of the sendToAssignee property.
     * 
     */
    public boolean isSendToAssignee() {
        return sendToAssignee;
    }

    /**
     * Sets the value of the sendToAssignee property.
     * 
     */
    public void setSendToAssignee(boolean value) {
        this.sendToAssignee = value;
    }

    /**
     * Gets the value of the sendToCaseOwner property.
     * 
     */
    public boolean isSendToCaseOwner() {
        return sendToCaseOwner;
    }

    /**
     * Sets the value of the sendToCaseOwner property.
     * 
     */
    public void setSendToCaseOwner(boolean value) {
        this.sendToCaseOwner = value;
    }

    /**
     * Gets the value of the sendToList property.
     * 
     */
    public boolean isSendToList() {
        return sendToList;
    }

    /**
     * Sets the value of the sendToList property.
     * 
     */
    public void setSendToList(boolean value) {
        this.sendToList = value;
    }

    /**
     * Gets the value of the sendToManager property.
     * 
     */
    public boolean isSendToManager() {
        return sendToManager;
    }

    /**
     * Sets the value of the sendToManager property.
     * 
     */
    public void setSendToManager(boolean value) {
        this.sendToManager = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusTO }
     *     
     */
    public StatusTO getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusTO }
     *     
     */
    public void setStatus(StatusTO value) {
        this.status = value;
    }

    /**
     * Gets the value of the subscribeContent property.
     * 
     */
    public boolean isSubscribeContent() {
        return subscribeContent;
    }

    /**
     * Sets the value of the subscribeContent property.
     * 
     */
    public void setSubscribeContent(boolean value) {
        this.subscribeContent = value;
    }

    /**
     * Gets the value of the taskForms property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaskForms() {
        return taskForms;
    }

    /**
     * Sets the value of the taskForms property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaskForms(String value) {
        this.taskForms = value;
    }

    /**
     * Gets the value of the tasksACL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTasksACL() {
        return tasksACL;
    }

    /**
     * Sets the value of the tasksACL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTasksACL(String value) {
        this.tasksACL = value;
    }

    /**
     * Gets the value of the templateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTemplateID() {
        return templateID;
    }

    /**
     * Sets the value of the templateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTemplateID(BigDecimal value) {
        this.templateID = value;
    }

    /**
     * Gets the value of the templateName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateName() {
        return templateName;
    }

    /**
     * Sets the value of the templateName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateName(String value) {
        this.templateName = value;
    }

    /**
     * Gets the value of the whatsNew property.
     * 
     */
    public boolean isWhatsNew() {
        return whatsNew;
    }

    /**
     * Sets the value of the whatsNew property.
     * 
     */
    public void setWhatsNew(boolean value) {
        this.whatsNew = value;
    }

}
