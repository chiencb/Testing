
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for unlockRepositoryObject complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="unlockRepositoryObject"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="String_1" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="arrayOfFieldPropertiesTO_2" type="{http://fields.sonora.eistream.com/}FieldPropertiesTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "unlockRepositoryObject", propOrder = {
    "string1",
    "arrayOfFieldPropertiesTO2"
})
public class UnlockRepositoryObject {

    @XmlElement(name = "String_1", required = true, nillable = true)
    protected String string1;
    @XmlElement(name = "arrayOfFieldPropertiesTO_2", nillable = true)
    protected List<FieldPropertiesTO> arrayOfFieldPropertiesTO2;

    /**
     * Gets the value of the string1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString1() {
        return string1;
    }

    /**
     * Sets the value of the string1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString1(String value) {
        this.string1 = value;
    }

    /**
     * Gets the value of the arrayOfFieldPropertiesTO2 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the arrayOfFieldPropertiesTO2 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getArrayOfFieldPropertiesTO2().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FieldPropertiesTO }
     * 
     * 
     */
    public List<FieldPropertiesTO> getArrayOfFieldPropertiesTO2() {
        if (arrayOfFieldPropertiesTO2 == null) {
            arrayOfFieldPropertiesTO2 = new ArrayList<FieldPropertiesTO>();
        }
        return this.arrayOfFieldPropertiesTO2;
    }

}
