package com.aia.aiaedownload.services.aiafbusinessservices;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import com.aia.aiaedownload.generated.aiafbusinessservices.GetListImageCase360;
import com.aia.aiaedownload.generated.aiafbusinessservices.GetListImageCase360Input;
import com.aia.aiaedownload.generated.aiafbusinessservices.GetListImageCase360Response;

public class AIAFBusinessServices extends WebServiceGatewaySupport {

    public GetListImageCase360Response getListImageCase360(String policyNum) {
        try {
            GetListImageCase360 request = new GetListImageCase360();
            GetListImageCase360Input input = new GetListImageCase360Input();
            input.setPolicyNum(policyNum);
            request.setGetListImageCase360Input(input);
            JAXBElement<GetListImageCase360> jaxbElement = new JAXBElement<GetListImageCase360>(
                    new QName("http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360",
                            "getListImageCase360"),
                    GetListImageCase360.class, request);

            Object response = getWebServiceTemplate().marshalSendAndReceive(
                    "http://IDDCIULEIS010:5555/ws/AIAFBusinessServices.adapters.case360:getListImageCase360_WSD/AIAFBusinessServices_adapters_case360_getListImageCase360_WSD_Port",
                    jaxbElement, null);
            return ((JAXBElement<GetListImageCase360Response>) response).getValue();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
