
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for UserTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="allowApplets" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="busyFactor" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="comments" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="defaultQueries" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="deliveryFlag" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="deliveryString" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="displayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="group" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="homePage" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="licenseGroupID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="loginID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="managerID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="persona" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="preferredLocale" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="statusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="statusUpdated" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="timeZone" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="userVariables" type="{http://users.sonora.eistream.com/}UserVarInfoTO"/&gt;
 *         &lt;element name="workCalendarName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserTO", namespace = "http://users.sonora.eistream.com/", propOrder = {
    "allowApplets",
    "busyFactor",
    "comments",
    "defaultQueries",
    "deliveryFlag",
    "deliveryString",
    "displayName",
    "firstName",
    "group",
    "homePage",
    "lastName",
    "licenseGroupID",
    "loginID",
    "managerID",
    "persona",
    "preferredLocale",
    "status",
    "statusMessage",
    "statusUpdated",
    "timeZone",
    "userVariables",
    "workCalendarName"
})
public class UserTO {

    protected int allowApplets;
    protected short busyFactor;
    @XmlElement(required = true, nillable = true)
    protected String comments;
    @XmlElement(required = true, nillable = true)
    protected String defaultQueries;
    protected int deliveryFlag;
    @XmlElement(required = true, nillable = true)
    protected String deliveryString;
    @XmlElement(required = true, nillable = true)
    protected String displayName;
    @XmlElement(required = true, nillable = true)
    protected String firstName;
    @XmlElement(required = true, nillable = true)
    protected String group;
    @XmlElement(required = true, nillable = true)
    protected String homePage;
    @XmlElement(required = true, nillable = true)
    protected String lastName;
    @XmlElement(required = true, nillable = true)
    protected String licenseGroupID;
    @XmlElement(required = true, nillable = true)
    protected String loginID;
    @XmlElement(required = true, nillable = true)
    protected String managerID;
    @XmlElement(required = true, nillable = true)
    protected String persona;
    @XmlElement(required = true, nillable = true)
    protected String preferredLocale;
    @XmlElement(required = true, nillable = true)
    protected String status;
    @XmlElement(required = true, nillable = true)
    protected String statusMessage;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar statusUpdated;
    @XmlElement(required = true, nillable = true)
    protected String timeZone;
    @XmlElement(required = true, nillable = true)
    protected UserVarInfoTO userVariables;
    @XmlElement(required = true, nillable = true)
    protected String workCalendarName;

    /**
     * Gets the value of the allowApplets property.
     * 
     */
    public int getAllowApplets() {
        return allowApplets;
    }

    /**
     * Sets the value of the allowApplets property.
     * 
     */
    public void setAllowApplets(int value) {
        this.allowApplets = value;
    }

    /**
     * Gets the value of the busyFactor property.
     * 
     */
    public short getBusyFactor() {
        return busyFactor;
    }

    /**
     * Sets the value of the busyFactor property.
     * 
     */
    public void setBusyFactor(short value) {
        this.busyFactor = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the defaultQueries property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultQueries() {
        return defaultQueries;
    }

    /**
     * Sets the value of the defaultQueries property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultQueries(String value) {
        this.defaultQueries = value;
    }

    /**
     * Gets the value of the deliveryFlag property.
     * 
     */
    public int getDeliveryFlag() {
        return deliveryFlag;
    }

    /**
     * Sets the value of the deliveryFlag property.
     * 
     */
    public void setDeliveryFlag(int value) {
        this.deliveryFlag = value;
    }

    /**
     * Gets the value of the deliveryString property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryString() {
        return deliveryString;
    }

    /**
     * Sets the value of the deliveryString property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryString(String value) {
        this.deliveryString = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the group property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroup() {
        return group;
    }

    /**
     * Sets the value of the group property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroup(String value) {
        this.group = value;
    }

    /**
     * Gets the value of the homePage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePage() {
        return homePage;
    }

    /**
     * Sets the value of the homePage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePage(String value) {
        this.homePage = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the licenseGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenseGroupID() {
        return licenseGroupID;
    }

    /**
     * Sets the value of the licenseGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenseGroupID(String value) {
        this.licenseGroupID = value;
    }

    /**
     * Gets the value of the loginID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginID() {
        return loginID;
    }

    /**
     * Sets the value of the loginID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginID(String value) {
        this.loginID = value;
    }

    /**
     * Gets the value of the managerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManagerID() {
        return managerID;
    }

    /**
     * Sets the value of the managerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManagerID(String value) {
        this.managerID = value;
    }

    /**
     * Gets the value of the persona property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersona() {
        return persona;
    }

    /**
     * Sets the value of the persona property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersona(String value) {
        this.persona = value;
    }

    /**
     * Gets the value of the preferredLocale property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferredLocale() {
        return preferredLocale;
    }

    /**
     * Sets the value of the preferredLocale property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferredLocale(String value) {
        this.preferredLocale = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the statusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusMessage() {
        return statusMessage;
    }

    /**
     * Sets the value of the statusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusMessage(String value) {
        this.statusMessage = value;
    }

    /**
     * Gets the value of the statusUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStatusUpdated() {
        return statusUpdated;
    }

    /**
     * Sets the value of the statusUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStatusUpdated(XMLGregorianCalendar value) {
        this.statusUpdated = value;
    }

    /**
     * Gets the value of the timeZone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeZone() {
        return timeZone;
    }

    /**
     * Sets the value of the timeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeZone(String value) {
        this.timeZone = value;
    }

    /**
     * Gets the value of the userVariables property.
     * 
     * @return
     *     possible object is
     *     {@link UserVarInfoTO }
     *     
     */
    public UserVarInfoTO getUserVariables() {
        return userVariables;
    }

    /**
     * Sets the value of the userVariables property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserVarInfoTO }
     *     
     */
    public void setUserVariables(UserVarInfoTO value) {
        this.userVariables = value;
    }

    /**
     * Gets the value of the workCalendarName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkCalendarName() {
        return workCalendarName;
    }

    /**
     * Sets the value of the workCalendarName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkCalendarName(String value) {
        this.workCalendarName = value;
    }

}
