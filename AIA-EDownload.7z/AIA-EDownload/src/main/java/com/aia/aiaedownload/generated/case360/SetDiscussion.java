
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setDiscussion complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setDiscussion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DiscussionTO_1" type="{http://discussions.casefolder.sonora.eistream.com/}DiscussionTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setDiscussion", propOrder = {
    "discussionTO1"
})
public class SetDiscussion {

    @XmlElement(name = "DiscussionTO_1", required = true, nillable = true)
    protected DiscussionTO discussionTO1;

    /**
     * Gets the value of the discussionTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link DiscussionTO }
     *     
     */
    public DiscussionTO getDiscussionTO1() {
        return discussionTO1;
    }

    /**
     * Sets the value of the discussionTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link DiscussionTO }
     *     
     */
    public void setDiscussionTO1(DiscussionTO value) {
        this.discussionTO1 = value;
    }

}
