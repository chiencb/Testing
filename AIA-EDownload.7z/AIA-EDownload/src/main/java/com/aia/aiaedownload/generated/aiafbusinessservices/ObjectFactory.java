
package com.aia.aiaedownload.generated.aiafbusinessservices;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.aia.aiaedownload.generated.aiafbusinessservices package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetListImageCase360_QNAME = new QName("http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360", "getListImageCase360");
    private final static QName _GetListImageCase360Response_QNAME = new QName("http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360", "getListImageCase360Response");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.aia.aiaedownload.generated.aiafbusinessservices
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetListImageCase360 }
     * 
     */
    public GetListImageCase360 createGetListImageCase360() {
        return new GetListImageCase360();
    }

    /**
     * Create an instance of {@link GetListImageCase360Response }
     * 
     */
    public GetListImageCase360Response createGetListImageCase360Response() {
        return new GetListImageCase360Response();
    }

    /**
     * Create an instance of {@link GetListImageCase360Input }
     * 
     */
    public GetListImageCase360Input createGetListImageCase360Input() {
        return new GetListImageCase360Input();
    }

    /**
     * Create an instance of {@link OverrideCredentials }
     * 
     */
    public OverrideCredentials createOverrideCredentials() {
        return new OverrideCredentials();
    }

    /**
     * Create an instance of {@link GetListImageCase360Output }
     * 
     */
    public GetListImageCase360Output createGetListImageCase360Output() {
        return new GetListImageCase360Output();
    }

    /**
     * Create an instance of {@link ResultOutput }
     * 
     */
    public ResultOutput createResultOutput() {
        return new ResultOutput();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetListImageCase360 }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetListImageCase360 }{@code >}
     */
    @XmlElementDecl(namespace = "http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360", name = "getListImageCase360")
    public JAXBElement<GetListImageCase360> createGetListImageCase360(GetListImageCase360 value) {
        return new JAXBElement<GetListImageCase360>(_GetListImageCase360_QNAME, GetListImageCase360 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetListImageCase360Response }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetListImageCase360Response }{@code >}
     */
    @XmlElementDecl(namespace = "http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360", name = "getListImageCase360Response")
    public JAXBElement<GetListImageCase360Response> createGetListImageCase360Response(GetListImageCase360Response value) {
        return new JAXBElement<GetListImageCase360Response>(_GetListImageCase360Response_QNAME, GetListImageCase360Response.class, null, value);
    }

}
