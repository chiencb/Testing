
package com.aia.aiaedownload.generated.aiafbusinessservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getListImageCase360 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getListImageCase360"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getListImageCase360Input" type="{http://IDDCIULEIS010/AIAFBusinessServices.adapters.case360}getListImageCase360Input"/&gt;
 *         &lt;element name="_x0024_connectionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getListImageCase360", propOrder = {
    "getListImageCase360Input",
    "x0024ConnectionName"
})
public class GetListImageCase360 {

    @XmlElement(required = true, nillable = true)
    protected GetListImageCase360Input getListImageCase360Input;
    @XmlElement(name = "_x0024_connectionName")
    protected String x0024ConnectionName;

    /**
     * Gets the value of the getListImageCase360Input property.
     * 
     * @return
     *     possible object is
     *     {@link GetListImageCase360Input }
     *     
     */
    public GetListImageCase360Input getGetListImageCase360Input() {
        return getListImageCase360Input;
    }

    /**
     * Sets the value of the getListImageCase360Input property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetListImageCase360Input }
     *     
     */
    public void setGetListImageCase360Input(GetListImageCase360Input value) {
        this.getListImageCase360Input = value;
    }

    /**
     * Gets the value of the x0024ConnectionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getX0024ConnectionName() {
        return x0024ConnectionName;
    }

    /**
     * Sets the value of the x0024ConnectionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setX0024ConnectionName(String value) {
        this.x0024ConnectionName = value;
    }

}
