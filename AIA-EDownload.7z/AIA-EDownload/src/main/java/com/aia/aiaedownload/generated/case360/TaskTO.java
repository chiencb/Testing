
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TaskTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaskTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="assignee" type="{http://util.casefolder.sonora.eistream.com/}AssigneeTO"/&gt;
 *         &lt;element name="capabilities" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="comments" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="completedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="componentElementID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createdDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deadline" type="{http://util.casefolder.sonora.eistream.com/}DeadlineTO"/&gt;
 *         &lt;element name="deferredCreate" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="displayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="displayOrder" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="documentURL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="elementType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="eventName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="eventText" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fillKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="instruction" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="namedScript" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="parentCasefolderRepositoryKey" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="percentCompleted" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="processCaseRepositoryField" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="processDispatch" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="processTaskScriptNameField" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="propForm" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="repositoryDocID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="scheduledStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="status" type="{http://util.casefolder.sonora.eistream.com/}StatusTO"/&gt;
 *         &lt;element name="taskURL" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="templateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="viewInFrame" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaskTO", namespace = "http://tasks.casefolder.sonora.eistream.com/", propOrder = {
    "acl",
    "assignee",
    "capabilities",
    "comments",
    "completedBy",
    "componentElementID",
    "createdBy",
    "createdDateTime",
    "deadline",
    "deferredCreate",
    "displayName",
    "displayOrder",
    "documentURL",
    "elementType",
    "endDate",
    "eventName",
    "eventText",
    "fillKey",
    "id",
    "instruction",
    "modifiedBy",
    "modifiedDateTime",
    "name",
    "namedScript",
    "parentCasefolderRepositoryKey",
    "partitionName",
    "percentCompleted",
    "processCaseRepositoryField",
    "processDispatch",
    "processTaskScriptNameField",
    "propForm",
    "repositoryDocID",
    "scheduledStartDate",
    "startDate",
    "status",
    "taskURL",
    "templateID",
    "viewInFrame"
})
public class TaskTO {

    @XmlElement(required = true, nillable = true)
    protected String acl;
    @XmlElement(required = true, nillable = true)
    protected AssigneeTO assignee;
    @XmlElement(required = true, nillable = true)
    protected String capabilities;
    @XmlElement(required = true, nillable = true)
    protected String comments;
    @XmlElement(required = true, nillable = true)
    protected String completedBy;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentElementID;
    @XmlElement(required = true, nillable = true)
    protected String createdBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDateTime;
    @XmlElement(required = true, nillable = true)
    protected DeadlineTO deadline;
    protected boolean deferredCreate;
    @XmlElement(required = true, nillable = true)
    protected String displayName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal displayOrder;
    @XmlElement(required = true, nillable = true)
    protected String documentURL;
    protected int elementType;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar endDate;
    @XmlElement(required = true, nillable = true)
    protected String eventName;
    @XmlElement(required = true, nillable = true)
    protected String eventText;
    @XmlElement(required = true, nillable = true)
    protected String fillKey;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal id;
    @XmlElement(required = true, nillable = true)
    protected String instruction;
    @XmlElement(required = true, nillable = true)
    protected String modifiedBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    @XmlElement(required = true, nillable = true)
    protected String name;
    @XmlElement(required = true, nillable = true)
    protected String namedScript;
    @XmlElement(required = true, nillable = true)
    protected String parentCasefolderRepositoryKey;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    protected int percentCompleted;
    @XmlElement(required = true, nillable = true)
    protected String processCaseRepositoryField;
    @XmlElement(required = true, nillable = true)
    protected String processDispatch;
    @XmlElement(required = true, nillable = true)
    protected String processTaskScriptNameField;
    @XmlElement(required = true, nillable = true)
    protected String propForm;
    @XmlElement(required = true, nillable = true)
    protected String repositoryDocID;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar scheduledStartDate;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar startDate;
    @XmlElement(required = true, nillable = true)
    protected StatusTO status;
    @XmlElement(required = true, nillable = true)
    protected String taskURL;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal templateID;
    @XmlElement(required = true, nillable = true)
    protected String viewInFrame;

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the assignee property.
     * 
     * @return
     *     possible object is
     *     {@link AssigneeTO }
     *     
     */
    public AssigneeTO getAssignee() {
        return assignee;
    }

    /**
     * Sets the value of the assignee property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssigneeTO }
     *     
     */
    public void setAssignee(AssigneeTO value) {
        this.assignee = value;
    }

    /**
     * Gets the value of the capabilities property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapabilities() {
        return capabilities;
    }

    /**
     * Sets the value of the capabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapabilities(String value) {
        this.capabilities = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the completedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompletedBy() {
        return completedBy;
    }

    /**
     * Sets the value of the completedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompletedBy(String value) {
        this.completedBy = value;
    }

    /**
     * Gets the value of the componentElementID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentElementID() {
        return componentElementID;
    }

    /**
     * Sets the value of the componentElementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentElementID(BigDecimal value) {
        this.componentElementID = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * Sets the value of the createdDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDateTime(XMLGregorianCalendar value) {
        this.createdDateTime = value;
    }

    /**
     * Gets the value of the deadline property.
     * 
     * @return
     *     possible object is
     *     {@link DeadlineTO }
     *     
     */
    public DeadlineTO getDeadline() {
        return deadline;
    }

    /**
     * Sets the value of the deadline property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeadlineTO }
     *     
     */
    public void setDeadline(DeadlineTO value) {
        this.deadline = value;
    }

    /**
     * Gets the value of the deferredCreate property.
     * 
     */
    public boolean isDeferredCreate() {
        return deferredCreate;
    }

    /**
     * Sets the value of the deferredCreate property.
     * 
     */
    public void setDeferredCreate(boolean value) {
        this.deferredCreate = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the displayOrder property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the value of the displayOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDisplayOrder(BigDecimal value) {
        this.displayOrder = value;
    }

    /**
     * Gets the value of the documentURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentURL() {
        return documentURL;
    }

    /**
     * Sets the value of the documentURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentURL(String value) {
        this.documentURL = value;
    }

    /**
     * Gets the value of the elementType property.
     * 
     */
    public int getElementType() {
        return elementType;
    }

    /**
     * Sets the value of the elementType property.
     * 
     */
    public void setElementType(int value) {
        this.elementType = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the eventText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventText() {
        return eventText;
    }

    /**
     * Sets the value of the eventText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventText(String value) {
        this.eventText = value;
    }

    /**
     * Gets the value of the fillKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFillKey() {
        return fillKey;
    }

    /**
     * Sets the value of the fillKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFillKey(String value) {
        this.fillKey = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setId(BigDecimal value) {
        this.id = value;
    }

    /**
     * Gets the value of the instruction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstruction() {
        return instruction;
    }

    /**
     * Sets the value of the instruction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstruction(String value) {
        this.instruction = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the namedScript property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNamedScript() {
        return namedScript;
    }

    /**
     * Sets the value of the namedScript property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNamedScript(String value) {
        this.namedScript = value;
    }

    /**
     * Gets the value of the parentCasefolderRepositoryKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentCasefolderRepositoryKey() {
        return parentCasefolderRepositoryKey;
    }

    /**
     * Sets the value of the parentCasefolderRepositoryKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentCasefolderRepositoryKey(String value) {
        this.parentCasefolderRepositoryKey = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the percentCompleted property.
     * 
     */
    public int getPercentCompleted() {
        return percentCompleted;
    }

    /**
     * Sets the value of the percentCompleted property.
     * 
     */
    public void setPercentCompleted(int value) {
        this.percentCompleted = value;
    }

    /**
     * Gets the value of the processCaseRepositoryField property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessCaseRepositoryField() {
        return processCaseRepositoryField;
    }

    /**
     * Sets the value of the processCaseRepositoryField property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessCaseRepositoryField(String value) {
        this.processCaseRepositoryField = value;
    }

    /**
     * Gets the value of the processDispatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessDispatch() {
        return processDispatch;
    }

    /**
     * Sets the value of the processDispatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessDispatch(String value) {
        this.processDispatch = value;
    }

    /**
     * Gets the value of the processTaskScriptNameField property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessTaskScriptNameField() {
        return processTaskScriptNameField;
    }

    /**
     * Sets the value of the processTaskScriptNameField property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessTaskScriptNameField(String value) {
        this.processTaskScriptNameField = value;
    }

    /**
     * Gets the value of the propForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropForm() {
        return propForm;
    }

    /**
     * Sets the value of the propForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropForm(String value) {
        this.propForm = value;
    }

    /**
     * Gets the value of the repositoryDocID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepositoryDocID() {
        return repositoryDocID;
    }

    /**
     * Sets the value of the repositoryDocID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepositoryDocID(String value) {
        this.repositoryDocID = value;
    }

    /**
     * Gets the value of the scheduledStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getScheduledStartDate() {
        return scheduledStartDate;
    }

    /**
     * Sets the value of the scheduledStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setScheduledStartDate(XMLGregorianCalendar value) {
        this.scheduledStartDate = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusTO }
     *     
     */
    public StatusTO getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusTO }
     *     
     */
    public void setStatus(StatusTO value) {
        this.status = value;
    }

    /**
     * Gets the value of the taskURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaskURL() {
        return taskURL;
    }

    /**
     * Sets the value of the taskURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaskURL(String value) {
        this.taskURL = value;
    }

    /**
     * Gets the value of the templateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTemplateID() {
        return templateID;
    }

    /**
     * Sets the value of the templateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTemplateID(BigDecimal value) {
        this.templateID = value;
    }

    /**
     * Gets the value of the viewInFrame property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getViewInFrame() {
        return viewInFrame;
    }

    /**
     * Sets the value of the viewInFrame property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setViewInFrame(String value) {
        this.viewInFrame = value;
    }

}
