
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for WorkFlowTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WorkFlowTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="applicationName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="archiveTemplateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="bosEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="bosInitialized" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="bosLogging" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="bosMinID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="calendarExpression" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createMetrics" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="defaultStepName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="fmsTableID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="globalsTableID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="hidden" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="iconName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="numberOfThreads" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="published" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="readOnlyHist" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="repositoryID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="templateIDs" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="versionNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="workFlowID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="workFlowName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="workFlowState" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="workFlowVersion" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WorkFlowTO", namespace = "http://workflows.workflow.sonora.eistream.com/", propOrder = {
    "uuid",
    "acl",
    "applicationName",
    "archiveTemplateID",
    "bosEnabled",
    "bosInitialized",
    "bosLogging",
    "bosMinID",
    "calendarExpression",
    "createMetrics",
    "defaultStepName",
    "documentId",
    "fmsTableID",
    "globalsTableID",
    "hidden",
    "iconName",
    "modifiedDateTime",
    "numberOfThreads",
    "partitionName",
    "published",
    "readOnlyHist",
    "repositoryID",
    "templateIDs",
    "versionNumber",
    "workFlowID",
    "workFlowName",
    "workFlowState",
    "workFlowVersion"
})
public class WorkFlowTO {

    @XmlElement(name = "UUID", required = true, nillable = true)
    protected String uuid;
    @XmlElement(required = true, nillable = true)
    protected String acl;
    @XmlElement(required = true, nillable = true)
    protected String applicationName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal archiveTemplateID;
    protected boolean bosEnabled;
    protected boolean bosInitialized;
    protected boolean bosLogging;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal bosMinID;
    @XmlElement(required = true, nillable = true)
    protected String calendarExpression;
    protected boolean createMetrics;
    @XmlElement(required = true, nillable = true)
    protected String defaultStepName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal documentId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal fmsTableID;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal globalsTableID;
    protected boolean hidden;
    @XmlElement(required = true, nillable = true)
    protected String iconName;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    protected int numberOfThreads;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    protected boolean published;
    protected boolean readOnlyHist;
    protected int repositoryID;
    @XmlElement(required = true, nillable = true)
    protected String templateIDs;
    protected int versionNumber;
    protected int workFlowID;
    @XmlElement(required = true, nillable = true)
    protected String workFlowName;
    protected boolean workFlowState;
    protected int workFlowVersion;

    /**
     * Gets the value of the uuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUUID() {
        return uuid;
    }

    /**
     * Sets the value of the uuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUUID(String value) {
        this.uuid = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the applicationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Sets the value of the applicationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationName(String value) {
        this.applicationName = value;
    }

    /**
     * Gets the value of the archiveTemplateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getArchiveTemplateID() {
        return archiveTemplateID;
    }

    /**
     * Sets the value of the archiveTemplateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setArchiveTemplateID(BigDecimal value) {
        this.archiveTemplateID = value;
    }

    /**
     * Gets the value of the bosEnabled property.
     * 
     */
    public boolean isBosEnabled() {
        return bosEnabled;
    }

    /**
     * Sets the value of the bosEnabled property.
     * 
     */
    public void setBosEnabled(boolean value) {
        this.bosEnabled = value;
    }

    /**
     * Gets the value of the bosInitialized property.
     * 
     */
    public boolean isBosInitialized() {
        return bosInitialized;
    }

    /**
     * Sets the value of the bosInitialized property.
     * 
     */
    public void setBosInitialized(boolean value) {
        this.bosInitialized = value;
    }

    /**
     * Gets the value of the bosLogging property.
     * 
     */
    public boolean isBosLogging() {
        return bosLogging;
    }

    /**
     * Sets the value of the bosLogging property.
     * 
     */
    public void setBosLogging(boolean value) {
        this.bosLogging = value;
    }

    /**
     * Gets the value of the bosMinID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBosMinID() {
        return bosMinID;
    }

    /**
     * Sets the value of the bosMinID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBosMinID(BigDecimal value) {
        this.bosMinID = value;
    }

    /**
     * Gets the value of the calendarExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalendarExpression() {
        return calendarExpression;
    }

    /**
     * Sets the value of the calendarExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalendarExpression(String value) {
        this.calendarExpression = value;
    }

    /**
     * Gets the value of the createMetrics property.
     * 
     */
    public boolean isCreateMetrics() {
        return createMetrics;
    }

    /**
     * Sets the value of the createMetrics property.
     * 
     */
    public void setCreateMetrics(boolean value) {
        this.createMetrics = value;
    }

    /**
     * Gets the value of the defaultStepName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultStepName() {
        return defaultStepName;
    }

    /**
     * Sets the value of the defaultStepName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultStepName(String value) {
        this.defaultStepName = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocumentId(BigDecimal value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the fmsTableID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFmsTableID() {
        return fmsTableID;
    }

    /**
     * Sets the value of the fmsTableID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFmsTableID(BigDecimal value) {
        this.fmsTableID = value;
    }

    /**
     * Gets the value of the globalsTableID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGlobalsTableID() {
        return globalsTableID;
    }

    /**
     * Sets the value of the globalsTableID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGlobalsTableID(BigDecimal value) {
        this.globalsTableID = value;
    }

    /**
     * Gets the value of the hidden property.
     * 
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Sets the value of the hidden property.
     * 
     */
    public void setHidden(boolean value) {
        this.hidden = value;
    }

    /**
     * Gets the value of the iconName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIconName() {
        return iconName;
    }

    /**
     * Sets the value of the iconName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIconName(String value) {
        this.iconName = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the numberOfThreads property.
     * 
     */
    public int getNumberOfThreads() {
        return numberOfThreads;
    }

    /**
     * Sets the value of the numberOfThreads property.
     * 
     */
    public void setNumberOfThreads(int value) {
        this.numberOfThreads = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the published property.
     * 
     */
    public boolean isPublished() {
        return published;
    }

    /**
     * Sets the value of the published property.
     * 
     */
    public void setPublished(boolean value) {
        this.published = value;
    }

    /**
     * Gets the value of the readOnlyHist property.
     * 
     */
    public boolean isReadOnlyHist() {
        return readOnlyHist;
    }

    /**
     * Sets the value of the readOnlyHist property.
     * 
     */
    public void setReadOnlyHist(boolean value) {
        this.readOnlyHist = value;
    }

    /**
     * Gets the value of the repositoryID property.
     * 
     */
    public int getRepositoryID() {
        return repositoryID;
    }

    /**
     * Sets the value of the repositoryID property.
     * 
     */
    public void setRepositoryID(int value) {
        this.repositoryID = value;
    }

    /**
     * Gets the value of the templateIDs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateIDs() {
        return templateIDs;
    }

    /**
     * Sets the value of the templateIDs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateIDs(String value) {
        this.templateIDs = value;
    }

    /**
     * Gets the value of the versionNumber property.
     * 
     */
    public int getVersionNumber() {
        return versionNumber;
    }

    /**
     * Sets the value of the versionNumber property.
     * 
     */
    public void setVersionNumber(int value) {
        this.versionNumber = value;
    }

    /**
     * Gets the value of the workFlowID property.
     * 
     */
    public int getWorkFlowID() {
        return workFlowID;
    }

    /**
     * Sets the value of the workFlowID property.
     * 
     */
    public void setWorkFlowID(int value) {
        this.workFlowID = value;
    }

    /**
     * Gets the value of the workFlowName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkFlowName() {
        return workFlowName;
    }

    /**
     * Sets the value of the workFlowName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkFlowName(String value) {
        this.workFlowName = value;
    }

    /**
     * Gets the value of the workFlowState property.
     * 
     */
    public boolean isWorkFlowState() {
        return workFlowState;
    }

    /**
     * Sets the value of the workFlowState property.
     * 
     */
    public void setWorkFlowState(boolean value) {
        this.workFlowState = value;
    }

    /**
     * Gets the value of the workFlowVersion property.
     * 
     */
    public int getWorkFlowVersion() {
        return workFlowVersion;
    }

    /**
     * Sets the value of the workFlowVersion property.
     * 
     */
    public void setWorkFlowVersion(int value) {
        this.workFlowVersion = value;
    }

}
