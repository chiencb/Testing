
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ColumnDefinitionTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ColumnDefinitionTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="conflictLevel" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="displayName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="fieldName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="formFormatData" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="formFormatName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="hidden" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="identity" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="keyReference" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="listFormatData" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="listFormatName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="primary" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="primaryKeyPart" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="readOnly" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="required" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="tableId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ColumnDefinitionTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "cId",
    "acl",
    "conflictLevel",
    "displayName",
    "fieldName",
    "formFormatData",
    "formFormatName",
    "hidden",
    "identity",
    "keyReference",
    "listFormatData",
    "listFormatName",
    "primary",
    "primaryKeyPart",
    "readOnly",
    "required",
    "tableId"
})
public class ColumnDefinitionTO {

    @XmlElement(name = "CId", required = true, nillable = true)
    protected BigDecimal cId;
    @XmlElement(required = true, nillable = true)
    protected String acl;
    protected short conflictLevel;
    @XmlElement(required = true, nillable = true)
    protected String displayName;
    @XmlElement(required = true, nillable = true)
    protected String fieldName;
    @XmlElement(required = true, nillable = true)
    protected String formFormatData;
    @XmlElement(required = true, nillable = true)
    protected String formFormatName;
    protected boolean hidden;
    protected boolean identity;
    @XmlElement(required = true, nillable = true)
    protected String keyReference;
    @XmlElement(required = true, nillable = true)
    protected String listFormatData;
    @XmlElement(required = true, nillable = true)
    protected String listFormatName;
    protected boolean primary;
    protected short primaryKeyPart;
    protected boolean readOnly;
    protected boolean required;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal tableId;

    /**
     * Gets the value of the cId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCId() {
        return cId;
    }

    /**
     * Sets the value of the cId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCId(BigDecimal value) {
        this.cId = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the conflictLevel property.
     * 
     */
    public short getConflictLevel() {
        return conflictLevel;
    }

    /**
     * Sets the value of the conflictLevel property.
     * 
     */
    public void setConflictLevel(short value) {
        this.conflictLevel = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the fieldName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * Sets the value of the fieldName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldName(String value) {
        this.fieldName = value;
    }

    /**
     * Gets the value of the formFormatData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormFormatData() {
        return formFormatData;
    }

    /**
     * Sets the value of the formFormatData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormFormatData(String value) {
        this.formFormatData = value;
    }

    /**
     * Gets the value of the formFormatName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormFormatName() {
        return formFormatName;
    }

    /**
     * Sets the value of the formFormatName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormFormatName(String value) {
        this.formFormatName = value;
    }

    /**
     * Gets the value of the hidden property.
     * 
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Sets the value of the hidden property.
     * 
     */
    public void setHidden(boolean value) {
        this.hidden = value;
    }

    /**
     * Gets the value of the identity property.
     * 
     */
    public boolean isIdentity() {
        return identity;
    }

    /**
     * Sets the value of the identity property.
     * 
     */
    public void setIdentity(boolean value) {
        this.identity = value;
    }

    /**
     * Gets the value of the keyReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyReference() {
        return keyReference;
    }

    /**
     * Sets the value of the keyReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyReference(String value) {
        this.keyReference = value;
    }

    /**
     * Gets the value of the listFormatData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListFormatData() {
        return listFormatData;
    }

    /**
     * Sets the value of the listFormatData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListFormatData(String value) {
        this.listFormatData = value;
    }

    /**
     * Gets the value of the listFormatName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListFormatName() {
        return listFormatName;
    }

    /**
     * Sets the value of the listFormatName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListFormatName(String value) {
        this.listFormatName = value;
    }

    /**
     * Gets the value of the primary property.
     * 
     */
    public boolean isPrimary() {
        return primary;
    }

    /**
     * Sets the value of the primary property.
     * 
     */
    public void setPrimary(boolean value) {
        this.primary = value;
    }

    /**
     * Gets the value of the primaryKeyPart property.
     * 
     */
    public short getPrimaryKeyPart() {
        return primaryKeyPart;
    }

    /**
     * Sets the value of the primaryKeyPart property.
     * 
     */
    public void setPrimaryKeyPart(short value) {
        this.primaryKeyPart = value;
    }

    /**
     * Gets the value of the readOnly property.
     * 
     */
    public boolean isReadOnly() {
        return readOnly;
    }

    /**
     * Sets the value of the readOnly property.
     * 
     */
    public void setReadOnly(boolean value) {
        this.readOnly = value;
    }

    /**
     * Gets the value of the required property.
     * 
     */
    public boolean isRequired() {
        return required;
    }

    /**
     * Sets the value of the required property.
     * 
     */
    public void setRequired(boolean value) {
        this.required = value;
    }

    /**
     * Gets the value of the tableId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTableId() {
        return tableId;
    }

    /**
     * Sets the value of the tableId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTableId(BigDecimal value) {
        this.tableId = value;
    }

}
