
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for StorageElementTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StorageElementTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="WIEFile" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="clientLocation" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createdDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="duplicateFile" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="fileName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="imageComponent" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="inProgress" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="itemSize" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="location" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="mapElement" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="mirrorFamilyId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="poolId" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="rendition" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="renditionLevel" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="signaturePoolId" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="storageId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="temporaryFileIndication" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="versionNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="workFileName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StorageElementTO", namespace = "http://filestore.sonora.eistream.com/", propOrder = {
    "wieFile",
    "clientLocation",
    "createdBy",
    "createdDateTime",
    "documentId",
    "duplicateFile",
    "fileName",
    "imageComponent",
    "inProgress",
    "itemSize",
    "location",
    "mapElement",
    "mirrorFamilyId",
    "partitionName",
    "poolId",
    "rendition",
    "renditionLevel",
    "signaturePoolId",
    "storageId",
    "temporaryFileIndication",
    "versionNumber",
    "workFileName"
})
public class StorageElementTO {

    @XmlElement(name = "WIEFile")
    protected boolean wieFile;
    @XmlElement(required = true, nillable = true)
    protected String clientLocation;
    @XmlElement(required = true, nillable = true)
    protected String createdBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDateTime;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal documentId;
    protected boolean duplicateFile;
    @XmlElement(required = true, nillable = true)
    protected String fileName;
    protected boolean imageComponent;
    protected boolean inProgress;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal itemSize;
    @XmlElement(required = true, nillable = true)
    protected String location;
    protected boolean mapElement;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal mirrorFamilyId;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    protected int poolId;
    protected boolean rendition;
    protected boolean renditionLevel;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer signaturePoolId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal storageId;
    protected boolean temporaryFileIndication;
    protected int versionNumber;
    @XmlElement(required = true, nillable = true)
    protected String workFileName;

    /**
     * Gets the value of the wieFile property.
     * 
     */
    public boolean isWIEFile() {
        return wieFile;
    }

    /**
     * Sets the value of the wieFile property.
     * 
     */
    public void setWIEFile(boolean value) {
        this.wieFile = value;
    }

    /**
     * Gets the value of the clientLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientLocation() {
        return clientLocation;
    }

    /**
     * Sets the value of the clientLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientLocation(String value) {
        this.clientLocation = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * Sets the value of the createdDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDateTime(XMLGregorianCalendar value) {
        this.createdDateTime = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocumentId(BigDecimal value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the duplicateFile property.
     * 
     */
    public boolean isDuplicateFile() {
        return duplicateFile;
    }

    /**
     * Sets the value of the duplicateFile property.
     * 
     */
    public void setDuplicateFile(boolean value) {
        this.duplicateFile = value;
    }

    /**
     * Gets the value of the fileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the value of the fileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileName(String value) {
        this.fileName = value;
    }

    /**
     * Gets the value of the imageComponent property.
     * 
     */
    public boolean isImageComponent() {
        return imageComponent;
    }

    /**
     * Sets the value of the imageComponent property.
     * 
     */
    public void setImageComponent(boolean value) {
        this.imageComponent = value;
    }

    /**
     * Gets the value of the inProgress property.
     * 
     */
    public boolean isInProgress() {
        return inProgress;
    }

    /**
     * Sets the value of the inProgress property.
     * 
     */
    public void setInProgress(boolean value) {
        this.inProgress = value;
    }

    /**
     * Gets the value of the itemSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getItemSize() {
        return itemSize;
    }

    /**
     * Sets the value of the itemSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setItemSize(BigDecimal value) {
        this.itemSize = value;
    }

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Gets the value of the mapElement property.
     * 
     */
    public boolean isMapElement() {
        return mapElement;
    }

    /**
     * Sets the value of the mapElement property.
     * 
     */
    public void setMapElement(boolean value) {
        this.mapElement = value;
    }

    /**
     * Gets the value of the mirrorFamilyId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMirrorFamilyId() {
        return mirrorFamilyId;
    }

    /**
     * Sets the value of the mirrorFamilyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMirrorFamilyId(BigDecimal value) {
        this.mirrorFamilyId = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the poolId property.
     * 
     */
    public int getPoolId() {
        return poolId;
    }

    /**
     * Sets the value of the poolId property.
     * 
     */
    public void setPoolId(int value) {
        this.poolId = value;
    }

    /**
     * Gets the value of the rendition property.
     * 
     */
    public boolean isRendition() {
        return rendition;
    }

    /**
     * Sets the value of the rendition property.
     * 
     */
    public void setRendition(boolean value) {
        this.rendition = value;
    }

    /**
     * Gets the value of the renditionLevel property.
     * 
     */
    public boolean isRenditionLevel() {
        return renditionLevel;
    }

    /**
     * Sets the value of the renditionLevel property.
     * 
     */
    public void setRenditionLevel(boolean value) {
        this.renditionLevel = value;
    }

    /**
     * Gets the value of the signaturePoolId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSignaturePoolId() {
        return signaturePoolId;
    }

    /**
     * Sets the value of the signaturePoolId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSignaturePoolId(Integer value) {
        this.signaturePoolId = value;
    }

    /**
     * Gets the value of the storageId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getStorageId() {
        return storageId;
    }

    /**
     * Sets the value of the storageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setStorageId(BigDecimal value) {
        this.storageId = value;
    }

    /**
     * Gets the value of the temporaryFileIndication property.
     * 
     */
    public boolean isTemporaryFileIndication() {
        return temporaryFileIndication;
    }

    /**
     * Sets the value of the temporaryFileIndication property.
     * 
     */
    public void setTemporaryFileIndication(boolean value) {
        this.temporaryFileIndication = value;
    }

    /**
     * Gets the value of the versionNumber property.
     * 
     */
    public int getVersionNumber() {
        return versionNumber;
    }

    /**
     * Sets the value of the versionNumber property.
     * 
     */
    public void setVersionNumber(int value) {
        this.versionNumber = value;
    }

    /**
     * Gets the value of the workFileName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkFileName() {
        return workFileName;
    }

    /**
     * Sets the value of the workFileName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkFileName(String value) {
        this.workFileName = value;
    }

}
