package com.aia.aiaedownload.services.case360;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

@Configuration
public class Case360Configuration {

	@Bean
	public Jaxb2Marshaller marshallerCase360() {
		Jaxb2Marshaller marshallerCase360 = new Jaxb2Marshaller();
		// this package must match the package in the <generatePackage> specified in
		// pom.xml
		marshallerCase360.setContextPath("com.aia.aiaedownload.generated.case360");
		return marshallerCase360;
	}

	@Bean
	public Case360 case360(Jaxb2Marshaller marshallerCase360) {
		Case360 client = new Case360();
		WebServiceTemplate template = client.getWebServiceTemplate();
		template.setMessageSender(new Case360MessageSenderAuth());
		client.setDefaultUri("http://CGKDCQLCASE01.aia.biz:8080/SonoraBeans");
		client.setMarshaller(marshallerCase360);
		client.setUnmarshaller(marshallerCase360);
		return client;
	}

}
