package com.aia.aiaedownload.services.aiafbusinessservices;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

@Configuration
public class AIAFBusinessServicesConfiguration {

	@Bean
	public Jaxb2Marshaller marshallerAIAFBusiness() {
		Jaxb2Marshaller marshallerAIAFBusiness = new Jaxb2Marshaller();
		// this package must match the package in the <generatePackage> specified in
		// pom.xml
		marshallerAIAFBusiness.setContextPath("com.aia.aiaedownload.generated.aiafbusinessservices");
		return marshallerAIAFBusiness;
	}

	@Bean
	public AIAFBusinessServices aiaFBusiness(Jaxb2Marshaller marshallerAIAFBusiness) {
		AIAFBusinessServices client = new AIAFBusinessServices();
		WebServiceTemplate template = client.getWebServiceTemplate();
		template.setMessageSender(new AIAFBusinessServicesMessageSenderAuth());
		client.setDefaultUri("http://IDDCIULEIS010:5555/ws/AIAFBusinessServices.adapters.case360:getListImageCase360_WSD/AIAFBusinessServices_adapters_case360_getListImageCase360_WSD_Port");
		client.setMarshaller(marshallerAIAFBusiness);
		client.setUnmarshaller(marshallerAIAFBusiness);
		return client;
	}

}
