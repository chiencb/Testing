
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CaseFolderConflictTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CaseFolderConflictTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="conflict" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="newCaseFolder" type="{http://core.casefolder.sonora.eistream.com/}CaseFolderTO"/&gt;
 *         &lt;element name="originalCaseFolder" type="{http://core.casefolder.sonora.eistream.com/}CaseFolderTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaseFolderConflictTO", namespace = "http://core.casefolder.sonora.eistream.com/", propOrder = {
    "conflict",
    "newCaseFolder",
    "originalCaseFolder"
})
public class CaseFolderConflictTO {

    protected boolean conflict;
    @XmlElement(required = true, nillable = true)
    protected CaseFolderTO newCaseFolder;
    @XmlElement(required = true, nillable = true)
    protected CaseFolderTO originalCaseFolder;

    /**
     * Gets the value of the conflict property.
     * 
     */
    public boolean isConflict() {
        return conflict;
    }

    /**
     * Sets the value of the conflict property.
     * 
     */
    public void setConflict(boolean value) {
        this.conflict = value;
    }

    /**
     * Gets the value of the newCaseFolder property.
     * 
     * @return
     *     possible object is
     *     {@link CaseFolderTO }
     *     
     */
    public CaseFolderTO getNewCaseFolder() {
        return newCaseFolder;
    }

    /**
     * Sets the value of the newCaseFolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaseFolderTO }
     *     
     */
    public void setNewCaseFolder(CaseFolderTO value) {
        this.newCaseFolder = value;
    }

    /**
     * Gets the value of the originalCaseFolder property.
     * 
     * @return
     *     possible object is
     *     {@link CaseFolderTO }
     *     
     */
    public CaseFolderTO getOriginalCaseFolder() {
        return originalCaseFolder;
    }

    /**
     * Sets the value of the originalCaseFolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaseFolderTO }
     *     
     */
    public void setOriginalCaseFolder(CaseFolderTO value) {
        this.originalCaseFolder = value;
    }

}
