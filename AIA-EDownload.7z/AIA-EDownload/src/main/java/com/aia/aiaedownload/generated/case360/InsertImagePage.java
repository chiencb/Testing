
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for insertImagePage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="insertImagePage"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BigDecimal_1" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="int_2" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="arrayOfbyte_3" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "insertImagePage", propOrder = {
    "bigDecimal1",
    "int2",
    "arrayOfbyte3"
})
public class InsertImagePage {

    @XmlElement(name = "BigDecimal_1", required = true, nillable = true)
    protected BigDecimal bigDecimal1;
    @XmlElement(name = "int_2")
    protected int int2;
    @XmlElement(name = "arrayOfbyte_3", required = true, nillable = true)
    protected byte[] arrayOfbyte3;

    /**
     * Gets the value of the bigDecimal1 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal1() {
        return bigDecimal1;
    }

    /**
     * Sets the value of the bigDecimal1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal1(BigDecimal value) {
        this.bigDecimal1 = value;
    }

    /**
     * Gets the value of the int2 property.
     * 
     */
    public int getInt2() {
        return int2;
    }

    /**
     * Sets the value of the int2 property.
     * 
     */
    public void setInt2(int value) {
        this.int2 = value;
    }

    /**
     * Gets the value of the arrayOfbyte3 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getArrayOfbyte3() {
        return arrayOfbyte3;
    }

    /**
     * Sets the value of the arrayOfbyte3 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setArrayOfbyte3(byte[] value) {
        this.arrayOfbyte3 = value;
    }

}
