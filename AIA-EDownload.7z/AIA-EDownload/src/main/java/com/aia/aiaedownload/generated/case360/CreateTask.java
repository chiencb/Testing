
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createTask complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createTask"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TaskTO_1" type="{http://tasks.casefolder.sonora.eistream.com/}TaskTO"/&gt;
 *         &lt;element name="BigDecimal_2" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createTask", propOrder = {
    "taskTO1",
    "bigDecimal2"
})
public class CreateTask {

    @XmlElement(name = "TaskTO_1", required = true, nillable = true)
    protected TaskTO taskTO1;
    @XmlElement(name = "BigDecimal_2", required = true, nillable = true)
    protected BigDecimal bigDecimal2;

    /**
     * Gets the value of the taskTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link TaskTO }
     *     
     */
    public TaskTO getTaskTO1() {
        return taskTO1;
    }

    /**
     * Sets the value of the taskTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskTO }
     *     
     */
    public void setTaskTO1(TaskTO value) {
        this.taskTO1 = value;
    }

    /**
     * Gets the value of the bigDecimal2 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal2() {
        return bigDecimal2;
    }

    /**
     * Sets the value of the bigDecimal2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal2(BigDecimal value) {
        this.bigDecimal2 = value;
    }

}
