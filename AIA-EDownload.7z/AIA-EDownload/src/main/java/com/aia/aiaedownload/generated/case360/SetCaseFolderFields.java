
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setCaseFolderFields complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setCaseFolderFields"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BigDecimal_1" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="FmsRowTO_2" type="{http://fields.sonora.eistream.com/}FmsRowTO"/&gt;
 *         &lt;element name="FmsRowTO_3" type="{http://fields.sonora.eistream.com/}FmsRowTO"/&gt;
 *         &lt;element name="boolean_4" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setCaseFolderFields", propOrder = {
    "bigDecimal1",
    "fmsRowTO2",
    "fmsRowTO3",
    "boolean4"
})
public class SetCaseFolderFields {

    @XmlElement(name = "BigDecimal_1", required = true, nillable = true)
    protected BigDecimal bigDecimal1;
    @XmlElement(name = "FmsRowTO_2", required = true, nillable = true)
    protected FmsRowTO fmsRowTO2;
    @XmlElement(name = "FmsRowTO_3", required = true, nillable = true)
    protected FmsRowTO fmsRowTO3;
    @XmlElement(name = "boolean_4")
    protected boolean boolean4;

    /**
     * Gets the value of the bigDecimal1 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal1() {
        return bigDecimal1;
    }

    /**
     * Sets the value of the bigDecimal1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal1(BigDecimal value) {
        this.bigDecimal1 = value;
    }

    /**
     * Gets the value of the fmsRowTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link FmsRowTO }
     *     
     */
    public FmsRowTO getFmsRowTO2() {
        return fmsRowTO2;
    }

    /**
     * Sets the value of the fmsRowTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FmsRowTO }
     *     
     */
    public void setFmsRowTO2(FmsRowTO value) {
        this.fmsRowTO2 = value;
    }

    /**
     * Gets the value of the fmsRowTO3 property.
     * 
     * @return
     *     possible object is
     *     {@link FmsRowTO }
     *     
     */
    public FmsRowTO getFmsRowTO3() {
        return fmsRowTO3;
    }

    /**
     * Sets the value of the fmsRowTO3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FmsRowTO }
     *     
     */
    public void setFmsRowTO3(FmsRowTO value) {
        this.fmsRowTO3 = value;
    }

    /**
     * Gets the value of the boolean4 property.
     * 
     */
    public boolean isBoolean4() {
        return boolean4;
    }

    /**
     * Sets the value of the boolean4 property.
     * 
     */
    public void setBoolean4(boolean value) {
        this.boolean4 = value;
    }

}
