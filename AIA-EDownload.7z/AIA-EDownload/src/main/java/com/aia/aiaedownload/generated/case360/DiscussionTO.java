
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DiscussionTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DiscussionTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="body" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="caseFolderID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="componentElementID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="componentType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="discussionID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="elementType" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="parentID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="replies" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="templateID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DiscussionTO", namespace = "http://discussions.casefolder.sonora.eistream.com/", propOrder = {
    "acl",
    "body",
    "caseFolderID",
    "componentElementID",
    "componentType",
    "discussionID",
    "elementType",
    "modifiedBy",
    "modifiedDateTime",
    "name",
    "parentID",
    "partitionName",
    "replies",
    "templateID"
})
public class DiscussionTO {

    @XmlElement(required = true, nillable = true)
    protected String acl;
    @XmlElement(required = true, nillable = true)
    protected String body;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal caseFolderID;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentElementID;
    protected int componentType;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal discussionID;
    protected int elementType;
    @XmlElement(required = true, nillable = true)
    protected String modifiedBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    @XmlElement(required = true, nillable = true)
    protected String name;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal parentID;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    protected int replies;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal templateID;

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBody(String value) {
        this.body = value;
    }

    /**
     * Gets the value of the caseFolderID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCaseFolderID() {
        return caseFolderID;
    }

    /**
     * Sets the value of the caseFolderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCaseFolderID(BigDecimal value) {
        this.caseFolderID = value;
    }

    /**
     * Gets the value of the componentElementID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentElementID() {
        return componentElementID;
    }

    /**
     * Sets the value of the componentElementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentElementID(BigDecimal value) {
        this.componentElementID = value;
    }

    /**
     * Gets the value of the componentType property.
     * 
     */
    public int getComponentType() {
        return componentType;
    }

    /**
     * Sets the value of the componentType property.
     * 
     */
    public void setComponentType(int value) {
        this.componentType = value;
    }

    /**
     * Gets the value of the discussionID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscussionID() {
        return discussionID;
    }

    /**
     * Sets the value of the discussionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscussionID(BigDecimal value) {
        this.discussionID = value;
    }

    /**
     * Gets the value of the elementType property.
     * 
     */
    public int getElementType() {
        return elementType;
    }

    /**
     * Sets the value of the elementType property.
     * 
     */
    public void setElementType(int value) {
        this.elementType = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the parentID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getParentID() {
        return parentID;
    }

    /**
     * Sets the value of the parentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setParentID(BigDecimal value) {
        this.parentID = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the replies property.
     * 
     */
    public int getReplies() {
        return replies;
    }

    /**
     * Sets the value of the replies property.
     * 
     */
    public void setReplies(int value) {
        this.replies = value;
    }

    /**
     * Gets the value of the templateID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTemplateID() {
        return templateID;
    }

    /**
     * Sets the value of the templateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTemplateID(BigDecimal value) {
        this.templateID = value;
    }

}
