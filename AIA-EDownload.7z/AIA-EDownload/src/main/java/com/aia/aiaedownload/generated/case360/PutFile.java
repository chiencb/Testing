
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for putFile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="putFile"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BigDecimal_1" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="arrayOfbyte_2" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *         &lt;element name="String_3" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "putFile", propOrder = {
    "bigDecimal1",
    "arrayOfbyte2",
    "string3"
})
public class PutFile {

    @XmlElement(name = "BigDecimal_1", required = true, nillable = true)
    protected BigDecimal bigDecimal1;
    @XmlElement(name = "arrayOfbyte_2", required = true, nillable = true)
    protected byte[] arrayOfbyte2;
    @XmlElement(name = "String_3", required = true, nillable = true)
    protected String string3;

    /**
     * Gets the value of the bigDecimal1 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal1() {
        return bigDecimal1;
    }

    /**
     * Sets the value of the bigDecimal1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal1(BigDecimal value) {
        this.bigDecimal1 = value;
    }

    /**
     * Gets the value of the arrayOfbyte2 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getArrayOfbyte2() {
        return arrayOfbyte2;
    }

    /**
     * Sets the value of the arrayOfbyte2 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setArrayOfbyte2(byte[] value) {
        this.arrayOfbyte2 = value;
    }

    /**
     * Gets the value of the string3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString3() {
        return string3;
    }

    /**
     * Sets the value of the string3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString3(String value) {
        this.string3 = value;
    }

}
