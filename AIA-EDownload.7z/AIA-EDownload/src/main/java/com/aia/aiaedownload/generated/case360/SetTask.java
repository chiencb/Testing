
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setTask complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setTask"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TaskTO_1" type="{http://tasks.casefolder.sonora.eistream.com/}TaskTO"/&gt;
 *         &lt;element name="TaskTO_2" type="{http://tasks.casefolder.sonora.eistream.com/}TaskTO"/&gt;
 *         &lt;element name="boolean_3" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="BigDecimal_4" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setTask", propOrder = {
    "taskTO1",
    "taskTO2",
    "boolean3",
    "bigDecimal4"
})
public class SetTask {

    @XmlElement(name = "TaskTO_1", required = true, nillable = true)
    protected TaskTO taskTO1;
    @XmlElement(name = "TaskTO_2", required = true, nillable = true)
    protected TaskTO taskTO2;
    @XmlElement(name = "boolean_3")
    protected boolean boolean3;
    @XmlElement(name = "BigDecimal_4", required = true, nillable = true)
    protected BigDecimal bigDecimal4;

    /**
     * Gets the value of the taskTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link TaskTO }
     *     
     */
    public TaskTO getTaskTO1() {
        return taskTO1;
    }

    /**
     * Sets the value of the taskTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskTO }
     *     
     */
    public void setTaskTO1(TaskTO value) {
        this.taskTO1 = value;
    }

    /**
     * Gets the value of the taskTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link TaskTO }
     *     
     */
    public TaskTO getTaskTO2() {
        return taskTO2;
    }

    /**
     * Sets the value of the taskTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskTO }
     *     
     */
    public void setTaskTO2(TaskTO value) {
        this.taskTO2 = value;
    }

    /**
     * Gets the value of the boolean3 property.
     * 
     */
    public boolean isBoolean3() {
        return boolean3;
    }

    /**
     * Sets the value of the boolean3 property.
     * 
     */
    public void setBoolean3(boolean value) {
        this.boolean3 = value;
    }

    /**
     * Gets the value of the bigDecimal4 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimal4() {
        return bigDecimal4;
    }

    /**
     * Sets the value of the bigDecimal4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimal4(BigDecimal value) {
        this.bigDecimal4 = value;
    }

}
