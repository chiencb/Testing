
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaskConflictTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaskConflictTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="conflict" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="newTask" type="{http://tasks.casefolder.sonora.eistream.com/}TaskTO"/&gt;
 *         &lt;element name="originalTask" type="{http://tasks.casefolder.sonora.eistream.com/}TaskTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaskConflictTO", namespace = "http://tasks.casefolder.sonora.eistream.com/", propOrder = {
    "conflict",
    "newTask",
    "originalTask"
})
public class TaskConflictTO {

    protected boolean conflict;
    @XmlElement(required = true, nillable = true)
    protected TaskTO newTask;
    @XmlElement(required = true, nillable = true)
    protected TaskTO originalTask;

    /**
     * Gets the value of the conflict property.
     * 
     */
    public boolean isConflict() {
        return conflict;
    }

    /**
     * Sets the value of the conflict property.
     * 
     */
    public void setConflict(boolean value) {
        this.conflict = value;
    }

    /**
     * Gets the value of the newTask property.
     * 
     * @return
     *     possible object is
     *     {@link TaskTO }
     *     
     */
    public TaskTO getNewTask() {
        return newTask;
    }

    /**
     * Sets the value of the newTask property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskTO }
     *     
     */
    public void setNewTask(TaskTO value) {
        this.newTask = value;
    }

    /**
     * Gets the value of the originalTask property.
     * 
     * @return
     *     possible object is
     *     {@link TaskTO }
     *     
     */
    public TaskTO getOriginalTask() {
        return originalTask;
    }

    /**
     * Sets the value of the originalTask property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskTO }
     *     
     */
    public void setOriginalTask(TaskTO value) {
        this.originalTask = value;
    }

}
