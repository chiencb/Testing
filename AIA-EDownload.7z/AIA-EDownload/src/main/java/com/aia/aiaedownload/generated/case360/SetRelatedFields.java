
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for setRelatedFields complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="setRelatedFields"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FmsRowTO_1" type="{http://fields.sonora.eistream.com/}FmsRowTO"/&gt;
 *         &lt;element name="FmsRowTO_2" type="{http://fields.sonora.eistream.com/}FmsRowTO"/&gt;
 *         &lt;element name="boolean_3" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setRelatedFields", propOrder = {
    "fmsRowTO1",
    "fmsRowTO2",
    "boolean3"
})
public class SetRelatedFields {

    @XmlElement(name = "FmsRowTO_1", required = true, nillable = true)
    protected FmsRowTO fmsRowTO1;
    @XmlElement(name = "FmsRowTO_2", required = true, nillable = true)
    protected FmsRowTO fmsRowTO2;
    @XmlElement(name = "boolean_3")
    protected boolean boolean3;

    /**
     * Gets the value of the fmsRowTO1 property.
     * 
     * @return
     *     possible object is
     *     {@link FmsRowTO }
     *     
     */
    public FmsRowTO getFmsRowTO1() {
        return fmsRowTO1;
    }

    /**
     * Sets the value of the fmsRowTO1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FmsRowTO }
     *     
     */
    public void setFmsRowTO1(FmsRowTO value) {
        this.fmsRowTO1 = value;
    }

    /**
     * Gets the value of the fmsRowTO2 property.
     * 
     * @return
     *     possible object is
     *     {@link FmsRowTO }
     *     
     */
    public FmsRowTO getFmsRowTO2() {
        return fmsRowTO2;
    }

    /**
     * Sets the value of the fmsRowTO2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link FmsRowTO }
     *     
     */
    public void setFmsRowTO2(FmsRowTO value) {
        this.fmsRowTO2 = value;
    }

    /**
     * Gets the value of the boolean3 property.
     * 
     */
    public boolean isBoolean3() {
        return boolean3;
    }

    /**
     * Sets the value of the boolean3 property.
     * 
     */
    public void setBoolean3(boolean value) {
        this.boolean3 = value;
    }

}
