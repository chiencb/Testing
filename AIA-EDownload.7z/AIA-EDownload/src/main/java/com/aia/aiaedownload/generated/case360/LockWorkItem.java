
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for lockWorkItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="lockWorkItem"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="int_1" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="String_2" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="String_3" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="int_4" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lockWorkItem", propOrder = {
    "int1",
    "string2",
    "string3",
    "int4"
})
public class LockWorkItem {

    @XmlElement(name = "int_1")
    protected int int1;
    @XmlElement(name = "String_2", required = true, nillable = true)
    protected String string2;
    @XmlElement(name = "String_3", required = true, nillable = true)
    protected String string3;
    @XmlElement(name = "int_4")
    protected int int4;

    /**
     * Gets the value of the int1 property.
     * 
     */
    public int getInt1() {
        return int1;
    }

    /**
     * Sets the value of the int1 property.
     * 
     */
    public void setInt1(int value) {
        this.int1 = value;
    }

    /**
     * Gets the value of the string2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString2() {
        return string2;
    }

    /**
     * Sets the value of the string2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString2(String value) {
        this.string2 = value;
    }

    /**
     * Gets the value of the string3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString3() {
        return string3;
    }

    /**
     * Sets the value of the string3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString3(String value) {
        this.string3 = value;
    }

    /**
     * Gets the value of the int4 property.
     * 
     */
    public int getInt4() {
        return int4;
    }

    /**
     * Sets the value of the int4 property.
     * 
     */
    public void setInt4(int value) {
        this.int4 = value;
    }

}
