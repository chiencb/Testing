
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for FmsFieldWs complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FmsFieldWs"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="bigDecimalValue" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="booleanValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="calendarValue" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="intValue" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="nullValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="stringValue" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FmsFieldWs", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "bigDecimalValue",
    "booleanValue",
    "calendarValue",
    "intValue",
    "nullValue",
    "stringValue"
})
public class FmsFieldWs {

    @XmlElement(required = true, nillable = true)
    protected BigDecimal bigDecimalValue;
    protected boolean booleanValue;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar calendarValue;
    protected int intValue;
    protected boolean nullValue;
    @XmlElement(required = true, nillable = true)
    protected String stringValue;

    /**
     * Gets the value of the bigDecimalValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimalValue() {
        return bigDecimalValue;
    }

    /**
     * Sets the value of the bigDecimalValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimalValue(BigDecimal value) {
        this.bigDecimalValue = value;
    }

    /**
     * Gets the value of the booleanValue property.
     * 
     */
    public boolean isBooleanValue() {
        return booleanValue;
    }

    /**
     * Sets the value of the booleanValue property.
     * 
     */
    public void setBooleanValue(boolean value) {
        this.booleanValue = value;
    }

    /**
     * Gets the value of the calendarValue property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCalendarValue() {
        return calendarValue;
    }

    /**
     * Sets the value of the calendarValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCalendarValue(XMLGregorianCalendar value) {
        this.calendarValue = value;
    }

    /**
     * Gets the value of the intValue property.
     * 
     */
    public int getIntValue() {
        return intValue;
    }

    /**
     * Sets the value of the intValue property.
     * 
     */
    public void setIntValue(int value) {
        this.intValue = value;
    }

    /**
     * Gets the value of the nullValue property.
     * 
     */
    public boolean isNullValue() {
        return nullValue;
    }

    /**
     * Sets the value of the nullValue property.
     * 
     */
    public void setNullValue(boolean value) {
        this.nullValue = value;
    }

    /**
     * Gets the value of the stringValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStringValue() {
        return stringValue;
    }

    /**
     * Sets the value of the stringValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStringValue(String value) {
        this.stringValue = value;
    }

}
