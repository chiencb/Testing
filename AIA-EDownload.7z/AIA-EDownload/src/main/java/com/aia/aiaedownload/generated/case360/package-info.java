@javax.xml.bind.annotation.XmlSchema(namespace = "http://com.eistream.sonora.webservices/types")
package com.aia.aiaedownload.generated.case360;
