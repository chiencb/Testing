
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FmsRowSetTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FmsRowSetTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="resultRows" type="{http://fields.sonora.eistream.com/}FmsRowTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="rowCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FmsRowSetTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "resultRows",
    "rowCount"
})
public class FmsRowSetTO {

    @XmlElement(nillable = true)
    protected List<FmsRowTO> resultRows;
    protected int rowCount;

    /**
     * Gets the value of the resultRows property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the resultRows property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResultRows().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FmsRowTO }
     * 
     * 
     */
    public List<FmsRowTO> getResultRows() {
        if (resultRows == null) {
            resultRows = new ArrayList<FmsRowTO>();
        }
        return this.resultRows;
    }

    /**
     * Gets the value of the rowCount property.
     * 
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * Sets the value of the rowCount property.
     * 
     */
    public void setRowCount(int value) {
        this.rowCount = value;
    }

}
