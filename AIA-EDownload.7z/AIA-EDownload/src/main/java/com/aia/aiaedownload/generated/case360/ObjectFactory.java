
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.aia.aiaedownload.generated.case360 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreateACL_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createACL");
    private final static QName _CreateACLResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createACLResponse");
    private final static QName _CreateCaseFolder_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createCaseFolder");
    private final static QName _CreateCaseFolderFromXml_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createCaseFolderFromXml");
    private final static QName _CreateCaseFolderFromXmlResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createCaseFolderFromXmlResponse");
    private final static QName _CreateCaseFolderResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createCaseFolderResponse");
    private final static QName _CreateContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createContent");
    private final static QName _CreateContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createContentResponse");
    private final static QName _CreateDiscussion_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createDiscussion");
    private final static QName _CreateDiscussionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createDiscussionResponse");
    private final static QName _CreateFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createFileStore");
    private final static QName _CreateFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createFileStoreResponse");
    private final static QName _CreateFormDataFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createFormDataFields");
    private final static QName _CreateFormDataFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createFormDataFieldsResponse");
    private final static QName _CreateRelatedFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRelatedFields");
    private final static QName _CreateRelatedFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRelatedFieldsResponse");
    private final static QName _CreateRepositoryObject_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRepositoryObject");
    private final static QName _CreateRepositoryObjectResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRepositoryObjectResponse");
    private final static QName _CreateRole_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRole");
    private final static QName _CreateRoleResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createRoleResponse");
    private final static QName _CreateTask_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createTask");
    private final static QName _CreateTaskResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createTaskResponse");
    private final static QName _CreateUser_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createUser");
    private final static QName _CreateUserResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createUserResponse");
    private final static QName _CreateWorkFlow_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createWorkFlow");
    private final static QName _CreateWorkFlowResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createWorkFlowResponse");
    private final static QName _CreateWorkItem_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createWorkItem");
    private final static QName _CreateWorkItemResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "createWorkItemResponse");
    private final static QName _DeleteImageMarks_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImageMarks");
    private final static QName _DeleteImageMarksResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImageMarksResponse");
    private final static QName _DeleteImagePage_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImagePage");
    private final static QName _DeleteImagePageResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImagePageResponse");
    private final static QName _DeleteImagePages_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImagePages");
    private final static QName _DeleteImagePagesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImagePagesResponse");
    private final static QName _DeleteImageThumbnail_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImageThumbnail");
    private final static QName _DeleteImageThumbnailResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteImageThumbnailResponse");
    private final static QName _DeleteRepositoryObject_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteRepositoryObject");
    private final static QName _DeleteRepositoryObjectResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "deleteRepositoryObjectResponse");
    private final static QName _DoQuery_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQuery");
    private final static QName _DoQueryByName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByName");
    private final static QName _DoQueryByNameEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameEx");
    private final static QName _DoQueryByNameExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameExResponse");
    private final static QName _DoQueryByNameNoFormFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameNoFormFields");
    private final static QName _DoQueryByNameNoFormFieldsEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameNoFormFieldsEx");
    private final static QName _DoQueryByNameNoFormFieldsExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameNoFormFieldsExResponse");
    private final static QName _DoQueryByNameNoFormFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameNoFormFieldsResponse");
    private final static QName _DoQueryByNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByNameResponse");
    private final static QName _DoQueryByScriptName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptName");
    private final static QName _DoQueryByScriptNameEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameEx");
    private final static QName _DoQueryByScriptNameExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameExResponse");
    private final static QName _DoQueryByScriptNameNoFormFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameNoFormFields");
    private final static QName _DoQueryByScriptNameNoFormFieldsEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameNoFormFieldsEx");
    private final static QName _DoQueryByScriptNameNoFormFieldsExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameNoFormFieldsExResponse");
    private final static QName _DoQueryByScriptNameNoFormFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameNoFormFieldsResponse");
    private final static QName _DoQueryByScriptNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryByScriptNameResponse");
    private final static QName _DoQueryEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryEx");
    private final static QName _DoQueryExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryExResponse");
    private final static QName _DoQueryNoFormFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryNoFormFields");
    private final static QName _DoQueryNoFormFieldsEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryNoFormFieldsEx");
    private final static QName _DoQueryNoFormFieldsExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryNoFormFieldsExResponse");
    private final static QName _DoQueryNoFormFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryNoFormFieldsResponse");
    private final static QName _DoQueryResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "doQueryResponse");
    private final static QName _GetAcls_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getAcls");
    private final static QName _GetAclsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getAclsResponse");
    private final static QName _GetCaseFolder_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolder");
    private final static QName _GetCaseFolderAsXml_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderAsXml");
    private final static QName _GetCaseFolderAsXmlResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderAsXmlResponse");
    private final static QName _GetCaseFolderField_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderField");
    private final static QName _GetCaseFolderFieldResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderFieldResponse");
    private final static QName _GetCaseFolderFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderFields");
    private final static QName _GetCaseFolderFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderFieldsResponse");
    private final static QName _GetCaseFolderResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderResponse");
    private final static QName _GetCaseFolderTemplates_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderTemplates");
    private final static QName _GetCaseFolderTemplatesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getCaseFolderTemplatesResponse");
    private final static QName _GetContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContent");
    private final static QName _GetContentByName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentByName");
    private final static QName _GetContentByNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentByNameResponse");
    private final static QName _GetContentElements_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentElements");
    private final static QName _GetContentElementsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentElementsResponse");
    private final static QName _GetContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentResponse");
    private final static QName _GetContents_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContents");
    private final static QName _GetContentsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getContentsResponse");
    private final static QName _GetDiscussion_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDiscussion");
    private final static QName _GetDiscussionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDiscussionResponse");
    private final static QName _GetDiscussions_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDiscussions");
    private final static QName _GetDiscussionsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDiscussionsResponse");
    private final static QName _GetDocumentElements_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDocumentElements");
    private final static QName _GetDocumentElementsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getDocumentElementsResponse");
    private final static QName _GetElementDiscussions_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getElementDiscussions");
    private final static QName _GetElementDiscussionsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getElementDiscussionsResponse");
    private final static QName _GetFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFields");
    private final static QName _GetFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFieldsResponse");
    private final static QName _GetFile_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFile");
    private final static QName _GetFileByName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileByName");
    private final static QName _GetFileByNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileByNameResponse");
    private final static QName _GetFileRendition_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileRendition");
    private final static QName _GetFileRenditionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileRenditionResponse");
    private final static QName _GetFileResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileResponse");
    private final static QName _GetFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStore");
    private final static QName _GetFileStoreFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStoreFields");
    private final static QName _GetFileStoreFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStoreFieldsResponse");
    private final static QName _GetFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStoreResponse");
    private final static QName _GetFileStoreTemplates_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStoreTemplates");
    private final static QName _GetFileStoreTemplatesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFileStoreTemplatesResponse");
    private final static QName _GetFormDataFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFormDataFields");
    private final static QName _GetFormDataFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getFormDataFieldsResponse");
    private final static QName _GetImageMarks_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImageMarks");
    private final static QName _GetImageMarksResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImageMarksResponse");
    private final static QName _GetImagePage_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImagePage");
    private final static QName _GetImagePageCount_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImagePageCount");
    private final static QName _GetImagePageCountResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImagePageCountResponse");
    private final static QName _GetImagePageResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImagePageResponse");
    private final static QName _GetImageThumbnail_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImageThumbnail");
    private final static QName _GetImageThumbnailResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getImageThumbnailResponse");
    private final static QName _GetPartialFile_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getPartialFile");
    private final static QName _GetPartialFileRendition_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getPartialFileRendition");
    private final static QName _GetPartialFileRenditionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getPartialFileRenditionResponse");
    private final static QName _GetPartialFileResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getPartialFileResponse");
    private final static QName _GetQueryCategories_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryCategories");
    private final static QName _GetQueryCategoriesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryCategoriesResponse");
    private final static QName _GetQueryColumnInfo_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryColumnInfo");
    private final static QName _GetQueryColumnInfoByScriptName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryColumnInfoByScriptName");
    private final static QName _GetQueryColumnInfoByScriptNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryColumnInfoByScriptNameResponse");
    private final static QName _GetQueryColumnInfoResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryColumnInfoResponse");
    private final static QName _GetQueryFormFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryFormFields");
    private final static QName _GetQueryFormFieldsByScriptName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryFormFieldsByScriptName");
    private final static QName _GetQueryFormFieldsByScriptNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryFormFieldsByScriptNameResponse");
    private final static QName _GetQueryFormFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryFormFieldsResponse");
    private final static QName _GetQueryList_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryList");
    private final static QName _GetQueryListResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getQueryListResponse");
    private final static QName _GetRelatedFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRelatedFields");
    private final static QName _GetRelatedFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRelatedFieldsResponse");
    private final static QName _GetRepositoryContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryContent");
    private final static QName _GetRepositoryContentPage_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryContentPage");
    private final static QName _GetRepositoryContentPageResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryContentPageResponse");
    private final static QName _GetRepositoryContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryContentResponse");
    private final static QName _GetRepositoryFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryFields");
    private final static QName _GetRepositoryFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRepositoryFieldsResponse");
    private final static QName _GetRoles_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRoles");
    private final static QName _GetRolesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getRolesResponse");
    private final static QName _GetTask_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTask");
    private final static QName _GetTaskByName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTaskByName");
    private final static QName _GetTaskByNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTaskByNameResponse");
    private final static QName _GetTaskElements_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTaskElements");
    private final static QName _GetTaskElementsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTaskElementsResponse");
    private final static QName _GetTaskResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTaskResponse");
    private final static QName _GetTasks_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTasks");
    private final static QName _GetTasksResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTasksResponse");
    private final static QName _GetTopics_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTopics");
    private final static QName _GetTopicsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getTopicsResponse");
    private final static QName _GetUser_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUser");
    private final static QName _GetUserAttributeFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUserAttributeFields");
    private final static QName _GetUserAttributeFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUserAttributeFieldsResponse");
    private final static QName _GetUserResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUserResponse");
    private final static QName _GetUsers_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUsers");
    private final static QName _GetUsersForRole_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUsersForRole");
    private final static QName _GetUsersForRoleResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUsersForRoleResponse");
    private final static QName _GetUsersResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getUsersResponse");
    private final static QName _GetValues_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getValues");
    private final static QName _GetValuesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getValuesResponse");
    private final static QName _GetVersions_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getVersions");
    private final static QName _GetVersionsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getVersionsResponse");
    private final static QName _GetWorkFlowFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkFlowFields");
    private final static QName _GetWorkFlowFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkFlowFieldsResponse");
    private final static QName _GetWorkFlowTemplates_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkFlowTemplates");
    private final static QName _GetWorkFlowTemplatesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkFlowTemplatesResponse");
    private final static QName _GetWorkItemEnvelope_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkItemEnvelope");
    private final static QName _GetWorkItemEnvelopeResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkItemEnvelopeResponse");
    private final static QName _GetWorkItemFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkItemFields");
    private final static QName _GetWorkItemFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "getWorkItemFieldsResponse");
    private final static QName _InsertImagePage_QNAME = new QName("http://com.eistream.sonora.webservices/types", "insertImagePage");
    private final static QName _InsertImagePageResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "insertImagePageResponse");
    private final static QName _LockFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockFileStore");
    private final static QName _LockFileStoreEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockFileStoreEx");
    private final static QName _LockFileStoreExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockFileStoreExResponse");
    private final static QName _LockFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockFileStoreResponse");
    private final static QName _LockRepositoryObject_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockRepositoryObject");
    private final static QName _LockRepositoryObjectResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockRepositoryObjectResponse");
    private final static QName _LockWorkItem_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockWorkItem");
    private final static QName _LockWorkItemResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "lockWorkItemResponse");
    private final static QName _MoveImagePages_QNAME = new QName("http://com.eistream.sonora.webservices/types", "moveImagePages");
    private final static QName _MoveImagePagesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "moveImagePagesResponse");
    private final static QName _PutBuddyInCapture_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putBuddyInCapture");
    private final static QName _PutBuddyInCaptureResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putBuddyInCaptureResponse");
    private final static QName _PutFile_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFile");
    private final static QName _PutFileBuddyInCapture_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileBuddyInCapture");
    private final static QName _PutFileBuddyInCaptureResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileBuddyInCaptureResponse");
    private final static QName _PutFileByName_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileByName");
    private final static QName _PutFileByNameResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileByNameResponse");
    private final static QName _PutFileEx_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileEx");
    private final static QName _PutFileExResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileExResponse");
    private final static QName _PutFileInCapture_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileInCapture");
    private final static QName _PutFileInCaptureResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileInCaptureResponse");
    private final static QName _PutFileResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putFileResponse");
    private final static QName _PutImageMarks_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putImageMarks");
    private final static QName _PutImageMarksResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putImageMarksResponse");
    private final static QName _PutImageThumbnail_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putImageThumbnail");
    private final static QName _PutImageThumbnailResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putImageThumbnailResponse");
    private final static QName _PutRepositoryContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putRepositoryContent");
    private final static QName _PutRepositoryContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "putRepositoryContentResponse");
    private final static QName _ReleaseWorkItemFromError_QNAME = new QName("http://com.eistream.sonora.webservices/types", "releaseWorkItemFromError");
    private final static QName _ReleaseWorkItemFromErrorResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "releaseWorkItemFromErrorResponse");
    private final static QName _RemoveACL_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeACL");
    private final static QName _RemoveACLByRole_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeACLByRole");
    private final static QName _RemoveACLByRoleResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeACLByRoleResponse");
    private final static QName _RemoveACLResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeACLResponse");
    private final static QName _RemoveCaseFolder_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeCaseFolder");
    private final static QName _RemoveCaseFolderResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeCaseFolderResponse");
    private final static QName _RemoveContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeContent");
    private final static QName _RemoveContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeContentResponse");
    private final static QName _RemoveDiscussion_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeDiscussion");
    private final static QName _RemoveDiscussionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeDiscussionResponse");
    private final static QName _RemoveFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeFileStore");
    private final static QName _RemoveFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeFileStoreResponse");
    private final static QName _RemoveFormDataFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeFormDataFields");
    private final static QName _RemoveFormDataFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeFormDataFieldsResponse");
    private final static QName _RemoveRelatedFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeRelatedFields");
    private final static QName _RemoveRelatedFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeRelatedFieldsResponse");
    private final static QName _RemoveRole_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeRole");
    private final static QName _RemoveRoleResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeRoleResponse");
    private final static QName _RemoveTask_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeTask");
    private final static QName _RemoveTaskResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeTaskResponse");
    private final static QName _RemoveUser_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeUser");
    private final static QName _RemoveUserResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeUserResponse");
    private final static QName _RemoveVersion_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeVersion");
    private final static QName _RemoveVersionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeVersionResponse");
    private final static QName _RemoveWorkItem_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeWorkItem");
    private final static QName _RemoveWorkItemResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "removeWorkItemResponse");
    private final static QName _ReplaceImagePage_QNAME = new QName("http://com.eistream.sonora.webservices/types", "replaceImagePage");
    private final static QName _ReplaceImagePageResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "replaceImagePageResponse");
    private final static QName _RouteRepositoryObject_QNAME = new QName("http://com.eistream.sonora.webservices/types", "routeRepositoryObject");
    private final static QName _RouteRepositoryObjectResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "routeRepositoryObjectResponse");
    private final static QName _RouteWorkItem_QNAME = new QName("http://com.eistream.sonora.webservices/types", "routeWorkItem");
    private final static QName _RouteWorkItemResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "routeWorkItemResponse");
    private final static QName _RpCreate_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpCreate");
    private final static QName _RpCreateContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpCreateContent");
    private final static QName _RpCreateContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpCreateContentResponse");
    private final static QName _RpCreateResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpCreateResponse");
    private final static QName _RpDelete_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDelete");
    private final static QName _RpDeleteResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDeleteResponse");
    private final static QName _RpDoAction_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoAction");
    private final static QName _RpDoActionGetData_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoActionGetData");
    private final static QName _RpDoActionGetDataResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoActionGetDataResponse");
    private final static QName _RpDoActionPostData_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoActionPostData");
    private final static QName _RpDoActionPostDataResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoActionPostDataResponse");
    private final static QName _RpDoActionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpDoActionResponse");
    private final static QName _RpGet_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpGet");
    private final static QName _RpGetContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpGetContent");
    private final static QName _RpGetContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpGetContentResponse");
    private final static QName _RpGetResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpGetResponse");
    private final static QName _RpSet_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpSet");
    private final static QName _RpSetContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpSetContent");
    private final static QName _RpSetContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpSetContentResponse");
    private final static QName _RpSetResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "rpSetResponse");
    private final static QName _SendWorkItemToWorkstep_QNAME = new QName("http://com.eistream.sonora.webservices/types", "sendWorkItemToWorkstep");
    private final static QName _SendWorkItemToWorkstepResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "sendWorkItemToWorkstepResponse");
    private final static QName _SetACLforRole_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setACLforRole");
    private final static QName _SetACLforRoleConditions_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setACLforRoleConditions");
    private final static QName _SetACLforRoleConditionsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setACLforRoleConditionsResponse");
    private final static QName _SetACLforRoleResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setACLforRoleResponse");
    private final static QName _SetCaseFolder_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolder");
    private final static QName _SetCaseFolderField_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderField");
    private final static QName _SetCaseFolderFieldResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderFieldResponse");
    private final static QName _SetCaseFolderFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderFields");
    private final static QName _SetCaseFolderFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderFieldsResponse");
    private final static QName _SetCaseFolderProperty_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderProperty");
    private final static QName _SetCaseFolderPropertyResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderPropertyResponse");
    private final static QName _SetCaseFolderReadHistory_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderReadHistory");
    private final static QName _SetCaseFolderReadHistoryResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderReadHistoryResponse");
    private final static QName _SetCaseFolderResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setCaseFolderResponse");
    private final static QName _SetContent_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setContent");
    private final static QName _SetContentResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setContentResponse");
    private final static QName _SetDiscussion_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setDiscussion");
    private final static QName _SetDiscussionResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setDiscussionResponse");
    private final static QName _SetFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStore");
    private final static QName _SetFileStoreFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStoreFields");
    private final static QName _SetFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStoreResponse");
    private final static QName _SetUserAttributeFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setUserAttributeFieldsResponse");
    private final static QName _UserWsEvent1_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent1");
    private final static QName _RemoveException_QNAME = new QName("http://com.eistream.sonora.webservices/types", "RemoveException");
    private final static QName _SetFileStoreFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStoreFieldsResponse");
    private final static QName _SetFileStoreReadHistory_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStoreReadHistory");
    private final static QName _SetFileStoreReadHistoryResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFileStoreReadHistoryResponse");
    private final static QName _SetFormDataFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFormDataFields");
    private final static QName _SetFormDataFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setFormDataFieldsResponse");
    private final static QName _SetImageOrientation_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setImageOrientation");
    private final static QName _SetImageOrientationResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setImageOrientationResponse");
    private final static QName _SetRelatedFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRelatedFields");
    private final static QName _SetRelatedFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRelatedFieldsResponse");
    private final static QName _SetRepositoryFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRepositoryFields");
    private final static QName _SetRepositoryFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRepositoryFieldsResponse");
    private final static QName _SetRoles_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRoles");
    private final static QName _SetRolesResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setRolesResponse");
    private final static QName _SetTask_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setTask");
    private final static QName _SetTaskResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setTaskResponse");
    private final static QName _SetUser_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setUser");
    private final static QName _SetUserAttributeFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setUserAttributeFields");
    private final static QName _SetUserResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setUserResponse");
    private final static QName _SetWorkItemFields_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setWorkItemFields");
    private final static QName _SetWorkItemFieldsResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "setWorkItemFieldsResponse");
    private final static QName _UnLockFileStore_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unLockFileStore");
    private final static QName _UnLockFileStoreResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unLockFileStoreResponse");
    private final static QName _UnLockWorkItem_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unLockWorkItem");
    private final static QName _UnLockWorkItemResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unLockWorkItemResponse");
    private final static QName _UnlockRepositoryObject_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unlockRepositoryObject");
    private final static QName _UnlockRepositoryObjectResponse_QNAME = new QName("http://com.eistream.sonora.webservices/types", "unlockRepositoryObjectResponse");
    private final static QName _UserWsEvent1Response_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent1Response");
    private final static QName _UserWsEvent2_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent2");
    private final static QName _UserWsEvent2Response_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent2Response");
    private final static QName _UserWsEvent3_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent3");
    private final static QName _UserWsEvent3Response_QNAME = new QName("http://com.eistream.sonora.webservices/types", "userWsEvent3Response");
    private final static QName _CreateException_QNAME = new QName("http://com.eistream.sonora.webservices/types", "CreateException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.aia.aiaedownload.generated.case360
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DiscussionTO }
     * 
     */
    public DiscussionTO createDiscussionTO() {
        return new DiscussionTO();
    }

    /**
     * Create an instance of {@link ContentConflictTO }
     * 
     */
    public ContentConflictTO createContentConflictTO() {
        return new ContentConflictTO();
    }

    /**
     * Create an instance of {@link ContentTO }
     * 
     */
    public ContentTO createContentTO() {
        return new ContentTO();
    }

    /**
     * Create an instance of {@link CaseFolderConflictTO }
     * 
     */
    public CaseFolderConflictTO createCaseFolderConflictTO() {
        return new CaseFolderConflictTO();
    }

    /**
     * Create an instance of {@link CaseFolderTO }
     * 
     */
    public CaseFolderTO createCaseFolderTO() {
        return new CaseFolderTO();
    }

    /**
     * Create an instance of {@link UserTO }
     * 
     */
    public UserTO createUserTO() {
        return new UserTO();
    }

    /**
     * Create an instance of {@link UserVarInfoTO }
     * 
     */
    public UserVarInfoTO createUserVarInfoTO() {
        return new UserVarInfoTO();
    }

    /**
     * Create an instance of {@link ColumnDefinitionTO }
     * 
     */
    public ColumnDefinitionTO createColumnDefinitionTO() {
        return new ColumnDefinitionTO();
    }

    /**
     * Create an instance of {@link FieldDefinitionTO }
     * 
     */
    public FieldDefinitionTO createFieldDefinitionTO() {
        return new FieldDefinitionTO();
    }

    /**
     * Create an instance of {@link FieldPropertiesTO }
     * 
     */
    public FieldPropertiesTO createFieldPropertiesTO() {
        return new FieldPropertiesTO();
    }

    /**
     * Create an instance of {@link FillKeyTO }
     * 
     */
    public FillKeyTO createFillKeyTO() {
        return new FillKeyTO();
    }

    /**
     * Create an instance of {@link FmsFieldMetaDataTO }
     * 
     */
    public FmsFieldMetaDataTO createFmsFieldMetaDataTO() {
        return new FmsFieldMetaDataTO();
    }

    /**
     * Create an instance of {@link FmsFieldMetaDataWs }
     * 
     */
    public FmsFieldMetaDataWs createFmsFieldMetaDataWs() {
        return new FmsFieldMetaDataWs();
    }

    /**
     * Create an instance of {@link FmsFieldTO }
     * 
     */
    public FmsFieldTO createFmsFieldTO() {
        return new FmsFieldTO();
    }

    /**
     * Create an instance of {@link FmsFieldWs }
     * 
     */
    public FmsFieldWs createFmsFieldWs() {
        return new FmsFieldWs();
    }

    /**
     * Create an instance of {@link FmsRowConflictTO }
     * 
     */
    public FmsRowConflictTO createFmsRowConflictTO() {
        return new FmsRowConflictTO();
    }

    /**
     * Create an instance of {@link FmsRowSetTO }
     * 
     */
    public FmsRowSetTO createFmsRowSetTO() {
        return new FmsRowSetTO();
    }

    /**
     * Create an instance of {@link FmsRowSetWs }
     * 
     */
    public FmsRowSetWs createFmsRowSetWs() {
        return new FmsRowSetWs();
    }

    /**
     * Create an instance of {@link FmsRowTO }
     * 
     */
    public FmsRowTO createFmsRowTO() {
        return new FmsRowTO();
    }

    /**
     * Create an instance of {@link FmsRowWs }
     * 
     */
    public FmsRowWs createFmsRowWs() {
        return new FmsRowWs();
    }

    /**
     * Create an instance of {@link FmsValueDefinitionTO }
     * 
     */
    public FmsValueDefinitionTO createFmsValueDefinitionTO() {
        return new FmsValueDefinitionTO();
    }

    /**
     * Create an instance of {@link RepositoryManageTO }
     * 
     */
    public RepositoryManageTO createRepositoryManageTO() {
        return new RepositoryManageTO();
    }

    /**
     * Create an instance of {@link AclTO }
     * 
     */
    public AclTO createAclTO() {
        return new AclTO();
    }

    /**
     * Create an instance of {@link RolesTO }
     * 
     */
    public RolesTO createRolesTO() {
        return new RolesTO();
    }

    /**
     * Create an instance of {@link AssigneeTO }
     * 
     */
    public AssigneeTO createAssigneeTO() {
        return new AssigneeTO();
    }

    /**
     * Create an instance of {@link DeadlineTO }
     * 
     */
    public DeadlineTO createDeadlineTO() {
        return new DeadlineTO();
    }

    /**
     * Create an instance of {@link StatusTO }
     * 
     */
    public StatusTO createStatusTO() {
        return new StatusTO();
    }

    /**
     * Create an instance of {@link ColumnInfoTO }
     * 
     */
    public ColumnInfoTO createColumnInfoTO() {
        return new ColumnInfoTO();
    }

    /**
     * Create an instance of {@link QueryFormTO }
     * 
     */
    public QueryFormTO createQueryFormTO() {
        return new QueryFormTO();
    }

    /**
     * Create an instance of {@link QueryOutputTO }
     * 
     */
    public QueryOutputTO createQueryOutputTO() {
        return new QueryOutputTO();
    }

    /**
     * Create an instance of {@link QueryTO }
     * 
     */
    public QueryTO createQueryTO() {
        return new QueryTO();
    }

    /**
     * Create an instance of {@link CreateACL }
     * 
     */
    public CreateACL createCreateACL() {
        return new CreateACL();
    }

    /**
     * Create an instance of {@link CreateACLResponse }
     * 
     */
    public CreateACLResponse createCreateACLResponse() {
        return new CreateACLResponse();
    }

    /**
     * Create an instance of {@link CreateCaseFolder }
     * 
     */
    public CreateCaseFolder createCreateCaseFolder() {
        return new CreateCaseFolder();
    }

    /**
     * Create an instance of {@link CreateCaseFolderFromXml }
     * 
     */
    public CreateCaseFolderFromXml createCreateCaseFolderFromXml() {
        return new CreateCaseFolderFromXml();
    }

    /**
     * Create an instance of {@link CreateCaseFolderFromXmlResponse }
     * 
     */
    public CreateCaseFolderFromXmlResponse createCreateCaseFolderFromXmlResponse() {
        return new CreateCaseFolderFromXmlResponse();
    }

    /**
     * Create an instance of {@link CreateCaseFolderResponse }
     * 
     */
    public CreateCaseFolderResponse createCreateCaseFolderResponse() {
        return new CreateCaseFolderResponse();
    }

    /**
     * Create an instance of {@link CreateContent }
     * 
     */
    public CreateContent createCreateContent() {
        return new CreateContent();
    }

    /**
     * Create an instance of {@link CreateContentResponse }
     * 
     */
    public CreateContentResponse createCreateContentResponse() {
        return new CreateContentResponse();
    }

    /**
     * Create an instance of {@link CreateDiscussion }
     * 
     */
    public CreateDiscussion createCreateDiscussion() {
        return new CreateDiscussion();
    }

    /**
     * Create an instance of {@link CreateDiscussionResponse }
     * 
     */
    public CreateDiscussionResponse createCreateDiscussionResponse() {
        return new CreateDiscussionResponse();
    }

    /**
     * Create an instance of {@link CreateFileStore }
     * 
     */
    public CreateFileStore createCreateFileStore() {
        return new CreateFileStore();
    }

    /**
     * Create an instance of {@link CreateFileStoreResponse }
     * 
     */
    public CreateFileStoreResponse createCreateFileStoreResponse() {
        return new CreateFileStoreResponse();
    }

    /**
     * Create an instance of {@link CreateFormDataFields }
     * 
     */
    public CreateFormDataFields createCreateFormDataFields() {
        return new CreateFormDataFields();
    }

    /**
     * Create an instance of {@link CreateFormDataFieldsResponse }
     * 
     */
    public CreateFormDataFieldsResponse createCreateFormDataFieldsResponse() {
        return new CreateFormDataFieldsResponse();
    }

    /**
     * Create an instance of {@link CreateRelatedFields }
     * 
     */
    public CreateRelatedFields createCreateRelatedFields() {
        return new CreateRelatedFields();
    }

    /**
     * Create an instance of {@link CreateRelatedFieldsResponse }
     * 
     */
    public CreateRelatedFieldsResponse createCreateRelatedFieldsResponse() {
        return new CreateRelatedFieldsResponse();
    }

    /**
     * Create an instance of {@link CreateRepositoryObject }
     * 
     */
    public CreateRepositoryObject createCreateRepositoryObject() {
        return new CreateRepositoryObject();
    }

    /**
     * Create an instance of {@link CreateRepositoryObjectResponse }
     * 
     */
    public CreateRepositoryObjectResponse createCreateRepositoryObjectResponse() {
        return new CreateRepositoryObjectResponse();
    }

    /**
     * Create an instance of {@link CreateRole }
     * 
     */
    public CreateRole createCreateRole() {
        return new CreateRole();
    }

    /**
     * Create an instance of {@link CreateRoleResponse }
     * 
     */
    public CreateRoleResponse createCreateRoleResponse() {
        return new CreateRoleResponse();
    }

    /**
     * Create an instance of {@link CreateTask }
     * 
     */
    public CreateTask createCreateTask() {
        return new CreateTask();
    }

    /**
     * Create an instance of {@link CreateTaskResponse }
     * 
     */
    public CreateTaskResponse createCreateTaskResponse() {
        return new CreateTaskResponse();
    }

    /**
     * Create an instance of {@link CreateUser }
     * 
     */
    public CreateUser createCreateUser() {
        return new CreateUser();
    }

    /**
     * Create an instance of {@link CreateUserResponse }
     * 
     */
    public CreateUserResponse createCreateUserResponse() {
        return new CreateUserResponse();
    }

    /**
     * Create an instance of {@link CreateWorkFlow }
     * 
     */
    public CreateWorkFlow createCreateWorkFlow() {
        return new CreateWorkFlow();
    }

    /**
     * Create an instance of {@link CreateWorkFlowResponse }
     * 
     */
    public CreateWorkFlowResponse createCreateWorkFlowResponse() {
        return new CreateWorkFlowResponse();
    }

    /**
     * Create an instance of {@link CreateWorkItem }
     * 
     */
    public CreateWorkItem createCreateWorkItem() {
        return new CreateWorkItem();
    }

    /**
     * Create an instance of {@link CreateWorkItemResponse }
     * 
     */
    public CreateWorkItemResponse createCreateWorkItemResponse() {
        return new CreateWorkItemResponse();
    }

    /**
     * Create an instance of {@link DeleteImageMarks }
     * 
     */
    public DeleteImageMarks createDeleteImageMarks() {
        return new DeleteImageMarks();
    }

    /**
     * Create an instance of {@link DeleteImageMarksResponse }
     * 
     */
    public DeleteImageMarksResponse createDeleteImageMarksResponse() {
        return new DeleteImageMarksResponse();
    }

    /**
     * Create an instance of {@link DeleteImagePage }
     * 
     */
    public DeleteImagePage createDeleteImagePage() {
        return new DeleteImagePage();
    }

    /**
     * Create an instance of {@link DeleteImagePageResponse }
     * 
     */
    public DeleteImagePageResponse createDeleteImagePageResponse() {
        return new DeleteImagePageResponse();
    }

    /**
     * Create an instance of {@link DeleteImagePages }
     * 
     */
    public DeleteImagePages createDeleteImagePages() {
        return new DeleteImagePages();
    }

    /**
     * Create an instance of {@link DeleteImagePagesResponse }
     * 
     */
    public DeleteImagePagesResponse createDeleteImagePagesResponse() {
        return new DeleteImagePagesResponse();
    }

    /**
     * Create an instance of {@link DeleteImageThumbnail }
     * 
     */
    public DeleteImageThumbnail createDeleteImageThumbnail() {
        return new DeleteImageThumbnail();
    }

    /**
     * Create an instance of {@link DeleteImageThumbnailResponse }
     * 
     */
    public DeleteImageThumbnailResponse createDeleteImageThumbnailResponse() {
        return new DeleteImageThumbnailResponse();
    }

    /**
     * Create an instance of {@link DeleteRepositoryObject }
     * 
     */
    public DeleteRepositoryObject createDeleteRepositoryObject() {
        return new DeleteRepositoryObject();
    }

    /**
     * Create an instance of {@link DeleteRepositoryObjectResponse }
     * 
     */
    public DeleteRepositoryObjectResponse createDeleteRepositoryObjectResponse() {
        return new DeleteRepositoryObjectResponse();
    }

    /**
     * Create an instance of {@link DoQuery }
     * 
     */
    public DoQuery createDoQuery() {
        return new DoQuery();
    }

    /**
     * Create an instance of {@link DoQueryByName }
     * 
     */
    public DoQueryByName createDoQueryByName() {
        return new DoQueryByName();
    }

    /**
     * Create an instance of {@link DoQueryByNameEx }
     * 
     */
    public DoQueryByNameEx createDoQueryByNameEx() {
        return new DoQueryByNameEx();
    }

    /**
     * Create an instance of {@link DoQueryByNameExResponse }
     * 
     */
    public DoQueryByNameExResponse createDoQueryByNameExResponse() {
        return new DoQueryByNameExResponse();
    }

    /**
     * Create an instance of {@link DoQueryByNameNoFormFields }
     * 
     */
    public DoQueryByNameNoFormFields createDoQueryByNameNoFormFields() {
        return new DoQueryByNameNoFormFields();
    }

    /**
     * Create an instance of {@link DoQueryByNameNoFormFieldsEx }
     * 
     */
    public DoQueryByNameNoFormFieldsEx createDoQueryByNameNoFormFieldsEx() {
        return new DoQueryByNameNoFormFieldsEx();
    }

    /**
     * Create an instance of {@link DoQueryByNameNoFormFieldsExResponse }
     * 
     */
    public DoQueryByNameNoFormFieldsExResponse createDoQueryByNameNoFormFieldsExResponse() {
        return new DoQueryByNameNoFormFieldsExResponse();
    }

    /**
     * Create an instance of {@link DoQueryByNameNoFormFieldsResponse }
     * 
     */
    public DoQueryByNameNoFormFieldsResponse createDoQueryByNameNoFormFieldsResponse() {
        return new DoQueryByNameNoFormFieldsResponse();
    }

    /**
     * Create an instance of {@link DoQueryByNameResponse }
     * 
     */
    public DoQueryByNameResponse createDoQueryByNameResponse() {
        return new DoQueryByNameResponse();
    }

    /**
     * Create an instance of {@link DoQueryByScriptName }
     * 
     */
    public DoQueryByScriptName createDoQueryByScriptName() {
        return new DoQueryByScriptName();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameEx }
     * 
     */
    public DoQueryByScriptNameEx createDoQueryByScriptNameEx() {
        return new DoQueryByScriptNameEx();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameExResponse }
     * 
     */
    public DoQueryByScriptNameExResponse createDoQueryByScriptNameExResponse() {
        return new DoQueryByScriptNameExResponse();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameNoFormFields }
     * 
     */
    public DoQueryByScriptNameNoFormFields createDoQueryByScriptNameNoFormFields() {
        return new DoQueryByScriptNameNoFormFields();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameNoFormFieldsEx }
     * 
     */
    public DoQueryByScriptNameNoFormFieldsEx createDoQueryByScriptNameNoFormFieldsEx() {
        return new DoQueryByScriptNameNoFormFieldsEx();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameNoFormFieldsExResponse }
     * 
     */
    public DoQueryByScriptNameNoFormFieldsExResponse createDoQueryByScriptNameNoFormFieldsExResponse() {
        return new DoQueryByScriptNameNoFormFieldsExResponse();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameNoFormFieldsResponse }
     * 
     */
    public DoQueryByScriptNameNoFormFieldsResponse createDoQueryByScriptNameNoFormFieldsResponse() {
        return new DoQueryByScriptNameNoFormFieldsResponse();
    }

    /**
     * Create an instance of {@link DoQueryByScriptNameResponse }
     * 
     */
    public DoQueryByScriptNameResponse createDoQueryByScriptNameResponse() {
        return new DoQueryByScriptNameResponse();
    }

    /**
     * Create an instance of {@link DoQueryEx }
     * 
     */
    public DoQueryEx createDoQueryEx() {
        return new DoQueryEx();
    }

    /**
     * Create an instance of {@link DoQueryExResponse }
     * 
     */
    public DoQueryExResponse createDoQueryExResponse() {
        return new DoQueryExResponse();
    }

    /**
     * Create an instance of {@link DoQueryNoFormFields }
     * 
     */
    public DoQueryNoFormFields createDoQueryNoFormFields() {
        return new DoQueryNoFormFields();
    }

    /**
     * Create an instance of {@link DoQueryNoFormFieldsEx }
     * 
     */
    public DoQueryNoFormFieldsEx createDoQueryNoFormFieldsEx() {
        return new DoQueryNoFormFieldsEx();
    }

    /**
     * Create an instance of {@link DoQueryNoFormFieldsExResponse }
     * 
     */
    public DoQueryNoFormFieldsExResponse createDoQueryNoFormFieldsExResponse() {
        return new DoQueryNoFormFieldsExResponse();
    }

    /**
     * Create an instance of {@link DoQueryNoFormFieldsResponse }
     * 
     */
    public DoQueryNoFormFieldsResponse createDoQueryNoFormFieldsResponse() {
        return new DoQueryNoFormFieldsResponse();
    }

    /**
     * Create an instance of {@link DoQueryResponse }
     * 
     */
    public DoQueryResponse createDoQueryResponse() {
        return new DoQueryResponse();
    }

    /**
     * Create an instance of {@link GetAcls }
     * 
     */
    public GetAcls createGetAcls() {
        return new GetAcls();
    }

    /**
     * Create an instance of {@link GetAclsResponse }
     * 
     */
    public GetAclsResponse createGetAclsResponse() {
        return new GetAclsResponse();
    }

    /**
     * Create an instance of {@link GetCaseFolder }
     * 
     */
    public GetCaseFolder createGetCaseFolder() {
        return new GetCaseFolder();
    }

    /**
     * Create an instance of {@link GetCaseFolderAsXml }
     * 
     */
    public GetCaseFolderAsXml createGetCaseFolderAsXml() {
        return new GetCaseFolderAsXml();
    }

    /**
     * Create an instance of {@link GetCaseFolderAsXmlResponse }
     * 
     */
    public GetCaseFolderAsXmlResponse createGetCaseFolderAsXmlResponse() {
        return new GetCaseFolderAsXmlResponse();
    }

    /**
     * Create an instance of {@link GetCaseFolderField }
     * 
     */
    public GetCaseFolderField createGetCaseFolderField() {
        return new GetCaseFolderField();
    }

    /**
     * Create an instance of {@link GetCaseFolderFieldResponse }
     * 
     */
    public GetCaseFolderFieldResponse createGetCaseFolderFieldResponse() {
        return new GetCaseFolderFieldResponse();
    }

    /**
     * Create an instance of {@link GetCaseFolderFields }
     * 
     */
    public GetCaseFolderFields createGetCaseFolderFields() {
        return new GetCaseFolderFields();
    }

    /**
     * Create an instance of {@link GetCaseFolderFieldsResponse }
     * 
     */
    public GetCaseFolderFieldsResponse createGetCaseFolderFieldsResponse() {
        return new GetCaseFolderFieldsResponse();
    }

    /**
     * Create an instance of {@link GetCaseFolderResponse }
     * 
     */
    public GetCaseFolderResponse createGetCaseFolderResponse() {
        return new GetCaseFolderResponse();
    }

    /**
     * Create an instance of {@link GetCaseFolderTemplates }
     * 
     */
    public GetCaseFolderTemplates createGetCaseFolderTemplates() {
        return new GetCaseFolderTemplates();
    }

    /**
     * Create an instance of {@link GetCaseFolderTemplatesResponse }
     * 
     */
    public GetCaseFolderTemplatesResponse createGetCaseFolderTemplatesResponse() {
        return new GetCaseFolderTemplatesResponse();
    }

    /**
     * Create an instance of {@link GetContent }
     * 
     */
    public GetContent createGetContent() {
        return new GetContent();
    }

    /**
     * Create an instance of {@link GetContentByName }
     * 
     */
    public GetContentByName createGetContentByName() {
        return new GetContentByName();
    }

    /**
     * Create an instance of {@link GetContentByNameResponse }
     * 
     */
    public GetContentByNameResponse createGetContentByNameResponse() {
        return new GetContentByNameResponse();
    }

    /**
     * Create an instance of {@link GetContentElements }
     * 
     */
    public GetContentElements createGetContentElements() {
        return new GetContentElements();
    }

    /**
     * Create an instance of {@link GetContentElementsResponse }
     * 
     */
    public GetContentElementsResponse createGetContentElementsResponse() {
        return new GetContentElementsResponse();
    }

    /**
     * Create an instance of {@link GetContentResponse }
     * 
     */
    public GetContentResponse createGetContentResponse() {
        return new GetContentResponse();
    }

    /**
     * Create an instance of {@link GetContents }
     * 
     */
    public GetContents createGetContents() {
        return new GetContents();
    }

    /**
     * Create an instance of {@link GetContentsResponse }
     * 
     */
    public GetContentsResponse createGetContentsResponse() {
        return new GetContentsResponse();
    }

    /**
     * Create an instance of {@link GetDiscussion }
     * 
     */
    public GetDiscussion createGetDiscussion() {
        return new GetDiscussion();
    }

    /**
     * Create an instance of {@link GetDiscussionResponse }
     * 
     */
    public GetDiscussionResponse createGetDiscussionResponse() {
        return new GetDiscussionResponse();
    }

    /**
     * Create an instance of {@link GetDiscussions }
     * 
     */
    public GetDiscussions createGetDiscussions() {
        return new GetDiscussions();
    }

    /**
     * Create an instance of {@link GetDiscussionsResponse }
     * 
     */
    public GetDiscussionsResponse createGetDiscussionsResponse() {
        return new GetDiscussionsResponse();
    }

    /**
     * Create an instance of {@link GetDocumentElements }
     * 
     */
    public GetDocumentElements createGetDocumentElements() {
        return new GetDocumentElements();
    }

    /**
     * Create an instance of {@link GetDocumentElementsResponse }
     * 
     */
    public GetDocumentElementsResponse createGetDocumentElementsResponse() {
        return new GetDocumentElementsResponse();
    }

    /**
     * Create an instance of {@link GetElementDiscussions }
     * 
     */
    public GetElementDiscussions createGetElementDiscussions() {
        return new GetElementDiscussions();
    }

    /**
     * Create an instance of {@link GetElementDiscussionsResponse }
     * 
     */
    public GetElementDiscussionsResponse createGetElementDiscussionsResponse() {
        return new GetElementDiscussionsResponse();
    }

    /**
     * Create an instance of {@link GetFields }
     * 
     */
    public GetFields createGetFields() {
        return new GetFields();
    }

    /**
     * Create an instance of {@link GetFieldsResponse }
     * 
     */
    public GetFieldsResponse createGetFieldsResponse() {
        return new GetFieldsResponse();
    }

    /**
     * Create an instance of {@link GetFile }
     * 
     */
    public GetFile createGetFile() {
        return new GetFile();
    }

    /**
     * Create an instance of {@link GetFileByName }
     * 
     */
    public GetFileByName createGetFileByName() {
        return new GetFileByName();
    }

    /**
     * Create an instance of {@link GetFileByNameResponse }
     * 
     */
    public GetFileByNameResponse createGetFileByNameResponse() {
        return new GetFileByNameResponse();
    }

    /**
     * Create an instance of {@link GetFileRendition }
     * 
     */
    public GetFileRendition createGetFileRendition() {
        return new GetFileRendition();
    }

    /**
     * Create an instance of {@link GetFileRenditionResponse }
     * 
     */
    public GetFileRenditionResponse createGetFileRenditionResponse() {
        return new GetFileRenditionResponse();
    }

    /**
     * Create an instance of {@link GetFileResponse }
     * 
     */
    public GetFileResponse createGetFileResponse() {
        return new GetFileResponse();
    }

    /**
     * Create an instance of {@link GetFileStore }
     * 
     */
    public GetFileStore createGetFileStore() {
        return new GetFileStore();
    }

    /**
     * Create an instance of {@link GetFileStoreFields }
     * 
     */
    public GetFileStoreFields createGetFileStoreFields() {
        return new GetFileStoreFields();
    }

    /**
     * Create an instance of {@link GetFileStoreFieldsResponse }
     * 
     */
    public GetFileStoreFieldsResponse createGetFileStoreFieldsResponse() {
        return new GetFileStoreFieldsResponse();
    }

    /**
     * Create an instance of {@link GetFileStoreResponse }
     * 
     */
    public GetFileStoreResponse createGetFileStoreResponse() {
        return new GetFileStoreResponse();
    }

    /**
     * Create an instance of {@link GetFileStoreTemplates }
     * 
     */
    public GetFileStoreTemplates createGetFileStoreTemplates() {
        return new GetFileStoreTemplates();
    }

    /**
     * Create an instance of {@link GetFileStoreTemplatesResponse }
     * 
     */
    public GetFileStoreTemplatesResponse createGetFileStoreTemplatesResponse() {
        return new GetFileStoreTemplatesResponse();
    }

    /**
     * Create an instance of {@link GetFormDataFields }
     * 
     */
    public GetFormDataFields createGetFormDataFields() {
        return new GetFormDataFields();
    }

    /**
     * Create an instance of {@link GetFormDataFieldsResponse }
     * 
     */
    public GetFormDataFieldsResponse createGetFormDataFieldsResponse() {
        return new GetFormDataFieldsResponse();
    }

    /**
     * Create an instance of {@link GetImageMarks }
     * 
     */
    public GetImageMarks createGetImageMarks() {
        return new GetImageMarks();
    }

    /**
     * Create an instance of {@link GetImageMarksResponse }
     * 
     */
    public GetImageMarksResponse createGetImageMarksResponse() {
        return new GetImageMarksResponse();
    }

    /**
     * Create an instance of {@link GetImagePage }
     * 
     */
    public GetImagePage createGetImagePage() {
        return new GetImagePage();
    }

    /**
     * Create an instance of {@link GetImagePageCount }
     * 
     */
    public GetImagePageCount createGetImagePageCount() {
        return new GetImagePageCount();
    }

    /**
     * Create an instance of {@link GetImagePageCountResponse }
     * 
     */
    public GetImagePageCountResponse createGetImagePageCountResponse() {
        return new GetImagePageCountResponse();
    }

    /**
     * Create an instance of {@link GetImagePageResponse }
     * 
     */
    public GetImagePageResponse createGetImagePageResponse() {
        return new GetImagePageResponse();
    }

    /**
     * Create an instance of {@link GetImageThumbnail }
     * 
     */
    public GetImageThumbnail createGetImageThumbnail() {
        return new GetImageThumbnail();
    }

    /**
     * Create an instance of {@link GetImageThumbnailResponse }
     * 
     */
    public GetImageThumbnailResponse createGetImageThumbnailResponse() {
        return new GetImageThumbnailResponse();
    }

    /**
     * Create an instance of {@link GetPartialFile }
     * 
     */
    public GetPartialFile createGetPartialFile() {
        return new GetPartialFile();
    }

    /**
     * Create an instance of {@link GetPartialFileRendition }
     * 
     */
    public GetPartialFileRendition createGetPartialFileRendition() {
        return new GetPartialFileRendition();
    }

    /**
     * Create an instance of {@link GetPartialFileRenditionResponse }
     * 
     */
    public GetPartialFileRenditionResponse createGetPartialFileRenditionResponse() {
        return new GetPartialFileRenditionResponse();
    }

    /**
     * Create an instance of {@link GetPartialFileResponse }
     * 
     */
    public GetPartialFileResponse createGetPartialFileResponse() {
        return new GetPartialFileResponse();
    }

    /**
     * Create an instance of {@link GetQueryCategories }
     * 
     */
    public GetQueryCategories createGetQueryCategories() {
        return new GetQueryCategories();
    }

    /**
     * Create an instance of {@link GetQueryCategoriesResponse }
     * 
     */
    public GetQueryCategoriesResponse createGetQueryCategoriesResponse() {
        return new GetQueryCategoriesResponse();
    }

    /**
     * Create an instance of {@link GetQueryColumnInfo }
     * 
     */
    public GetQueryColumnInfo createGetQueryColumnInfo() {
        return new GetQueryColumnInfo();
    }

    /**
     * Create an instance of {@link GetQueryColumnInfoByScriptName }
     * 
     */
    public GetQueryColumnInfoByScriptName createGetQueryColumnInfoByScriptName() {
        return new GetQueryColumnInfoByScriptName();
    }

    /**
     * Create an instance of {@link GetQueryColumnInfoByScriptNameResponse }
     * 
     */
    public GetQueryColumnInfoByScriptNameResponse createGetQueryColumnInfoByScriptNameResponse() {
        return new GetQueryColumnInfoByScriptNameResponse();
    }

    /**
     * Create an instance of {@link GetQueryColumnInfoResponse }
     * 
     */
    public GetQueryColumnInfoResponse createGetQueryColumnInfoResponse() {
        return new GetQueryColumnInfoResponse();
    }

    /**
     * Create an instance of {@link GetQueryFormFields }
     * 
     */
    public GetQueryFormFields createGetQueryFormFields() {
        return new GetQueryFormFields();
    }

    /**
     * Create an instance of {@link GetQueryFormFieldsByScriptName }
     * 
     */
    public GetQueryFormFieldsByScriptName createGetQueryFormFieldsByScriptName() {
        return new GetQueryFormFieldsByScriptName();
    }

    /**
     * Create an instance of {@link GetQueryFormFieldsByScriptNameResponse }
     * 
     */
    public GetQueryFormFieldsByScriptNameResponse createGetQueryFormFieldsByScriptNameResponse() {
        return new GetQueryFormFieldsByScriptNameResponse();
    }

    /**
     * Create an instance of {@link GetQueryFormFieldsResponse }
     * 
     */
    public GetQueryFormFieldsResponse createGetQueryFormFieldsResponse() {
        return new GetQueryFormFieldsResponse();
    }

    /**
     * Create an instance of {@link GetQueryList }
     * 
     */
    public GetQueryList createGetQueryList() {
        return new GetQueryList();
    }

    /**
     * Create an instance of {@link GetQueryListResponse }
     * 
     */
    public GetQueryListResponse createGetQueryListResponse() {
        return new GetQueryListResponse();
    }

    /**
     * Create an instance of {@link GetRelatedFields }
     * 
     */
    public GetRelatedFields createGetRelatedFields() {
        return new GetRelatedFields();
    }

    /**
     * Create an instance of {@link GetRelatedFieldsResponse }
     * 
     */
    public GetRelatedFieldsResponse createGetRelatedFieldsResponse() {
        return new GetRelatedFieldsResponse();
    }

    /**
     * Create an instance of {@link GetRepositoryContent }
     * 
     */
    public GetRepositoryContent createGetRepositoryContent() {
        return new GetRepositoryContent();
    }

    /**
     * Create an instance of {@link GetRepositoryContentPage }
     * 
     */
    public GetRepositoryContentPage createGetRepositoryContentPage() {
        return new GetRepositoryContentPage();
    }

    /**
     * Create an instance of {@link GetRepositoryContentPageResponse }
     * 
     */
    public GetRepositoryContentPageResponse createGetRepositoryContentPageResponse() {
        return new GetRepositoryContentPageResponse();
    }

    /**
     * Create an instance of {@link GetRepositoryContentResponse }
     * 
     */
    public GetRepositoryContentResponse createGetRepositoryContentResponse() {
        return new GetRepositoryContentResponse();
    }

    /**
     * Create an instance of {@link GetRepositoryFields }
     * 
     */
    public GetRepositoryFields createGetRepositoryFields() {
        return new GetRepositoryFields();
    }

    /**
     * Create an instance of {@link GetRepositoryFieldsResponse }
     * 
     */
    public GetRepositoryFieldsResponse createGetRepositoryFieldsResponse() {
        return new GetRepositoryFieldsResponse();
    }

    /**
     * Create an instance of {@link GetRoles }
     * 
     */
    public GetRoles createGetRoles() {
        return new GetRoles();
    }

    /**
     * Create an instance of {@link GetRolesResponse }
     * 
     */
    public GetRolesResponse createGetRolesResponse() {
        return new GetRolesResponse();
    }

    /**
     * Create an instance of {@link GetTask }
     * 
     */
    public GetTask createGetTask() {
        return new GetTask();
    }

    /**
     * Create an instance of {@link GetTaskByName }
     * 
     */
    public GetTaskByName createGetTaskByName() {
        return new GetTaskByName();
    }

    /**
     * Create an instance of {@link GetTaskByNameResponse }
     * 
     */
    public GetTaskByNameResponse createGetTaskByNameResponse() {
        return new GetTaskByNameResponse();
    }

    /**
     * Create an instance of {@link GetTaskElements }
     * 
     */
    public GetTaskElements createGetTaskElements() {
        return new GetTaskElements();
    }

    /**
     * Create an instance of {@link GetTaskElementsResponse }
     * 
     */
    public GetTaskElementsResponse createGetTaskElementsResponse() {
        return new GetTaskElementsResponse();
    }

    /**
     * Create an instance of {@link GetTaskResponse }
     * 
     */
    public GetTaskResponse createGetTaskResponse() {
        return new GetTaskResponse();
    }

    /**
     * Create an instance of {@link GetTasks }
     * 
     */
    public GetTasks createGetTasks() {
        return new GetTasks();
    }

    /**
     * Create an instance of {@link GetTasksResponse }
     * 
     */
    public GetTasksResponse createGetTasksResponse() {
        return new GetTasksResponse();
    }

    /**
     * Create an instance of {@link GetTopics }
     * 
     */
    public GetTopics createGetTopics() {
        return new GetTopics();
    }

    /**
     * Create an instance of {@link GetTopicsResponse }
     * 
     */
    public GetTopicsResponse createGetTopicsResponse() {
        return new GetTopicsResponse();
    }

    /**
     * Create an instance of {@link GetUser }
     * 
     */
    public GetUser createGetUser() {
        return new GetUser();
    }

    /**
     * Create an instance of {@link GetUserAttributeFields }
     * 
     */
    public GetUserAttributeFields createGetUserAttributeFields() {
        return new GetUserAttributeFields();
    }

    /**
     * Create an instance of {@link GetUserAttributeFieldsResponse }
     * 
     */
    public GetUserAttributeFieldsResponse createGetUserAttributeFieldsResponse() {
        return new GetUserAttributeFieldsResponse();
    }

    /**
     * Create an instance of {@link GetUserResponse }
     * 
     */
    public GetUserResponse createGetUserResponse() {
        return new GetUserResponse();
    }

    /**
     * Create an instance of {@link GetUsers }
     * 
     */
    public GetUsers createGetUsers() {
        return new GetUsers();
    }

    /**
     * Create an instance of {@link GetUsersForRole }
     * 
     */
    public GetUsersForRole createGetUsersForRole() {
        return new GetUsersForRole();
    }

    /**
     * Create an instance of {@link GetUsersForRoleResponse }
     * 
     */
    public GetUsersForRoleResponse createGetUsersForRoleResponse() {
        return new GetUsersForRoleResponse();
    }

    /**
     * Create an instance of {@link GetUsersResponse }
     * 
     */
    public GetUsersResponse createGetUsersResponse() {
        return new GetUsersResponse();
    }

    /**
     * Create an instance of {@link GetValues }
     * 
     */
    public GetValues createGetValues() {
        return new GetValues();
    }

    /**
     * Create an instance of {@link GetValuesResponse }
     * 
     */
    public GetValuesResponse createGetValuesResponse() {
        return new GetValuesResponse();
    }

    /**
     * Create an instance of {@link GetVersions }
     * 
     */
    public GetVersions createGetVersions() {
        return new GetVersions();
    }

    /**
     * Create an instance of {@link GetVersionsResponse }
     * 
     */
    public GetVersionsResponse createGetVersionsResponse() {
        return new GetVersionsResponse();
    }

    /**
     * Create an instance of {@link GetWorkFlowFields }
     * 
     */
    public GetWorkFlowFields createGetWorkFlowFields() {
        return new GetWorkFlowFields();
    }

    /**
     * Create an instance of {@link GetWorkFlowFieldsResponse }
     * 
     */
    public GetWorkFlowFieldsResponse createGetWorkFlowFieldsResponse() {
        return new GetWorkFlowFieldsResponse();
    }

    /**
     * Create an instance of {@link GetWorkFlowTemplates }
     * 
     */
    public GetWorkFlowTemplates createGetWorkFlowTemplates() {
        return new GetWorkFlowTemplates();
    }

    /**
     * Create an instance of {@link GetWorkFlowTemplatesResponse }
     * 
     */
    public GetWorkFlowTemplatesResponse createGetWorkFlowTemplatesResponse() {
        return new GetWorkFlowTemplatesResponse();
    }

    /**
     * Create an instance of {@link GetWorkItemEnvelope }
     * 
     */
    public GetWorkItemEnvelope createGetWorkItemEnvelope() {
        return new GetWorkItemEnvelope();
    }

    /**
     * Create an instance of {@link GetWorkItemEnvelopeResponse }
     * 
     */
    public GetWorkItemEnvelopeResponse createGetWorkItemEnvelopeResponse() {
        return new GetWorkItemEnvelopeResponse();
    }

    /**
     * Create an instance of {@link GetWorkItemFields }
     * 
     */
    public GetWorkItemFields createGetWorkItemFields() {
        return new GetWorkItemFields();
    }

    /**
     * Create an instance of {@link GetWorkItemFieldsResponse }
     * 
     */
    public GetWorkItemFieldsResponse createGetWorkItemFieldsResponse() {
        return new GetWorkItemFieldsResponse();
    }

    /**
     * Create an instance of {@link InsertImagePage }
     * 
     */
    public InsertImagePage createInsertImagePage() {
        return new InsertImagePage();
    }

    /**
     * Create an instance of {@link InsertImagePageResponse }
     * 
     */
    public InsertImagePageResponse createInsertImagePageResponse() {
        return new InsertImagePageResponse();
    }

    /**
     * Create an instance of {@link LockFileStore }
     * 
     */
    public LockFileStore createLockFileStore() {
        return new LockFileStore();
    }

    /**
     * Create an instance of {@link LockFileStoreEx }
     * 
     */
    public LockFileStoreEx createLockFileStoreEx() {
        return new LockFileStoreEx();
    }

    /**
     * Create an instance of {@link LockFileStoreExResponse }
     * 
     */
    public LockFileStoreExResponse createLockFileStoreExResponse() {
        return new LockFileStoreExResponse();
    }

    /**
     * Create an instance of {@link LockFileStoreResponse }
     * 
     */
    public LockFileStoreResponse createLockFileStoreResponse() {
        return new LockFileStoreResponse();
    }

    /**
     * Create an instance of {@link LockRepositoryObject }
     * 
     */
    public LockRepositoryObject createLockRepositoryObject() {
        return new LockRepositoryObject();
    }

    /**
     * Create an instance of {@link LockRepositoryObjectResponse }
     * 
     */
    public LockRepositoryObjectResponse createLockRepositoryObjectResponse() {
        return new LockRepositoryObjectResponse();
    }

    /**
     * Create an instance of {@link LockWorkItem }
     * 
     */
    public LockWorkItem createLockWorkItem() {
        return new LockWorkItem();
    }

    /**
     * Create an instance of {@link LockWorkItemResponse }
     * 
     */
    public LockWorkItemResponse createLockWorkItemResponse() {
        return new LockWorkItemResponse();
    }

    /**
     * Create an instance of {@link MoveImagePages }
     * 
     */
    public MoveImagePages createMoveImagePages() {
        return new MoveImagePages();
    }

    /**
     * Create an instance of {@link MoveImagePagesResponse }
     * 
     */
    public MoveImagePagesResponse createMoveImagePagesResponse() {
        return new MoveImagePagesResponse();
    }

    /**
     * Create an instance of {@link PutBuddyInCapture }
     * 
     */
    public PutBuddyInCapture createPutBuddyInCapture() {
        return new PutBuddyInCapture();
    }

    /**
     * Create an instance of {@link PutBuddyInCaptureResponse }
     * 
     */
    public PutBuddyInCaptureResponse createPutBuddyInCaptureResponse() {
        return new PutBuddyInCaptureResponse();
    }

    /**
     * Create an instance of {@link PutFile }
     * 
     */
    public PutFile createPutFile() {
        return new PutFile();
    }

    /**
     * Create an instance of {@link PutFileBuddyInCapture }
     * 
     */
    public PutFileBuddyInCapture createPutFileBuddyInCapture() {
        return new PutFileBuddyInCapture();
    }

    /**
     * Create an instance of {@link PutFileBuddyInCaptureResponse }
     * 
     */
    public PutFileBuddyInCaptureResponse createPutFileBuddyInCaptureResponse() {
        return new PutFileBuddyInCaptureResponse();
    }

    /**
     * Create an instance of {@link PutFileByName }
     * 
     */
    public PutFileByName createPutFileByName() {
        return new PutFileByName();
    }

    /**
     * Create an instance of {@link PutFileByNameResponse }
     * 
     */
    public PutFileByNameResponse createPutFileByNameResponse() {
        return new PutFileByNameResponse();
    }

    /**
     * Create an instance of {@link PutFileEx }
     * 
     */
    public PutFileEx createPutFileEx() {
        return new PutFileEx();
    }

    /**
     * Create an instance of {@link PutFileExResponse }
     * 
     */
    public PutFileExResponse createPutFileExResponse() {
        return new PutFileExResponse();
    }

    /**
     * Create an instance of {@link PutFileInCapture }
     * 
     */
    public PutFileInCapture createPutFileInCapture() {
        return new PutFileInCapture();
    }

    /**
     * Create an instance of {@link PutFileInCaptureResponse }
     * 
     */
    public PutFileInCaptureResponse createPutFileInCaptureResponse() {
        return new PutFileInCaptureResponse();
    }

    /**
     * Create an instance of {@link PutFileResponse }
     * 
     */
    public PutFileResponse createPutFileResponse() {
        return new PutFileResponse();
    }

    /**
     * Create an instance of {@link PutImageMarks }
     * 
     */
    public PutImageMarks createPutImageMarks() {
        return new PutImageMarks();
    }

    /**
     * Create an instance of {@link PutImageMarksResponse }
     * 
     */
    public PutImageMarksResponse createPutImageMarksResponse() {
        return new PutImageMarksResponse();
    }

    /**
     * Create an instance of {@link PutImageThumbnail }
     * 
     */
    public PutImageThumbnail createPutImageThumbnail() {
        return new PutImageThumbnail();
    }

    /**
     * Create an instance of {@link PutImageThumbnailResponse }
     * 
     */
    public PutImageThumbnailResponse createPutImageThumbnailResponse() {
        return new PutImageThumbnailResponse();
    }

    /**
     * Create an instance of {@link PutRepositoryContent }
     * 
     */
    public PutRepositoryContent createPutRepositoryContent() {
        return new PutRepositoryContent();
    }

    /**
     * Create an instance of {@link PutRepositoryContentResponse }
     * 
     */
    public PutRepositoryContentResponse createPutRepositoryContentResponse() {
        return new PutRepositoryContentResponse();
    }

    /**
     * Create an instance of {@link ReleaseWorkItemFromError }
     * 
     */
    public ReleaseWorkItemFromError createReleaseWorkItemFromError() {
        return new ReleaseWorkItemFromError();
    }

    /**
     * Create an instance of {@link ReleaseWorkItemFromErrorResponse }
     * 
     */
    public ReleaseWorkItemFromErrorResponse createReleaseWorkItemFromErrorResponse() {
        return new ReleaseWorkItemFromErrorResponse();
    }

    /**
     * Create an instance of {@link RemoveACL }
     * 
     */
    public RemoveACL createRemoveACL() {
        return new RemoveACL();
    }

    /**
     * Create an instance of {@link RemoveACLByRole }
     * 
     */
    public RemoveACLByRole createRemoveACLByRole() {
        return new RemoveACLByRole();
    }

    /**
     * Create an instance of {@link RemoveACLByRoleResponse }
     * 
     */
    public RemoveACLByRoleResponse createRemoveACLByRoleResponse() {
        return new RemoveACLByRoleResponse();
    }

    /**
     * Create an instance of {@link RemoveACLResponse }
     * 
     */
    public RemoveACLResponse createRemoveACLResponse() {
        return new RemoveACLResponse();
    }

    /**
     * Create an instance of {@link RemoveCaseFolder }
     * 
     */
    public RemoveCaseFolder createRemoveCaseFolder() {
        return new RemoveCaseFolder();
    }

    /**
     * Create an instance of {@link RemoveCaseFolderResponse }
     * 
     */
    public RemoveCaseFolderResponse createRemoveCaseFolderResponse() {
        return new RemoveCaseFolderResponse();
    }

    /**
     * Create an instance of {@link RemoveContent }
     * 
     */
    public RemoveContent createRemoveContent() {
        return new RemoveContent();
    }

    /**
     * Create an instance of {@link RemoveContentResponse }
     * 
     */
    public RemoveContentResponse createRemoveContentResponse() {
        return new RemoveContentResponse();
    }

    /**
     * Create an instance of {@link RemoveDiscussion }
     * 
     */
    public RemoveDiscussion createRemoveDiscussion() {
        return new RemoveDiscussion();
    }

    /**
     * Create an instance of {@link RemoveDiscussionResponse }
     * 
     */
    public RemoveDiscussionResponse createRemoveDiscussionResponse() {
        return new RemoveDiscussionResponse();
    }

    /**
     * Create an instance of {@link RemoveFileStore }
     * 
     */
    public RemoveFileStore createRemoveFileStore() {
        return new RemoveFileStore();
    }

    /**
     * Create an instance of {@link RemoveFileStoreResponse }
     * 
     */
    public RemoveFileStoreResponse createRemoveFileStoreResponse() {
        return new RemoveFileStoreResponse();
    }

    /**
     * Create an instance of {@link RemoveFormDataFields }
     * 
     */
    public RemoveFormDataFields createRemoveFormDataFields() {
        return new RemoveFormDataFields();
    }

    /**
     * Create an instance of {@link RemoveFormDataFieldsResponse }
     * 
     */
    public RemoveFormDataFieldsResponse createRemoveFormDataFieldsResponse() {
        return new RemoveFormDataFieldsResponse();
    }

    /**
     * Create an instance of {@link RemoveRelatedFields }
     * 
     */
    public RemoveRelatedFields createRemoveRelatedFields() {
        return new RemoveRelatedFields();
    }

    /**
     * Create an instance of {@link RemoveRelatedFieldsResponse }
     * 
     */
    public RemoveRelatedFieldsResponse createRemoveRelatedFieldsResponse() {
        return new RemoveRelatedFieldsResponse();
    }

    /**
     * Create an instance of {@link RemoveRole }
     * 
     */
    public RemoveRole createRemoveRole() {
        return new RemoveRole();
    }

    /**
     * Create an instance of {@link RemoveRoleResponse }
     * 
     */
    public RemoveRoleResponse createRemoveRoleResponse() {
        return new RemoveRoleResponse();
    }

    /**
     * Create an instance of {@link RemoveTask }
     * 
     */
    public RemoveTask createRemoveTask() {
        return new RemoveTask();
    }

    /**
     * Create an instance of {@link RemoveTaskResponse }
     * 
     */
    public RemoveTaskResponse createRemoveTaskResponse() {
        return new RemoveTaskResponse();
    }

    /**
     * Create an instance of {@link RemoveUser }
     * 
     */
    public RemoveUser createRemoveUser() {
        return new RemoveUser();
    }

    /**
     * Create an instance of {@link RemoveUserResponse }
     * 
     */
    public RemoveUserResponse createRemoveUserResponse() {
        return new RemoveUserResponse();
    }

    /**
     * Create an instance of {@link RemoveVersion }
     * 
     */
    public RemoveVersion createRemoveVersion() {
        return new RemoveVersion();
    }

    /**
     * Create an instance of {@link RemoveVersionResponse }
     * 
     */
    public RemoveVersionResponse createRemoveVersionResponse() {
        return new RemoveVersionResponse();
    }

    /**
     * Create an instance of {@link RemoveWorkItem }
     * 
     */
    public RemoveWorkItem createRemoveWorkItem() {
        return new RemoveWorkItem();
    }

    /**
     * Create an instance of {@link RemoveWorkItemResponse }
     * 
     */
    public RemoveWorkItemResponse createRemoveWorkItemResponse() {
        return new RemoveWorkItemResponse();
    }

    /**
     * Create an instance of {@link ReplaceImagePage }
     * 
     */
    public ReplaceImagePage createReplaceImagePage() {
        return new ReplaceImagePage();
    }

    /**
     * Create an instance of {@link ReplaceImagePageResponse }
     * 
     */
    public ReplaceImagePageResponse createReplaceImagePageResponse() {
        return new ReplaceImagePageResponse();
    }

    /**
     * Create an instance of {@link RouteRepositoryObject }
     * 
     */
    public RouteRepositoryObject createRouteRepositoryObject() {
        return new RouteRepositoryObject();
    }

    /**
     * Create an instance of {@link RouteRepositoryObjectResponse }
     * 
     */
    public RouteRepositoryObjectResponse createRouteRepositoryObjectResponse() {
        return new RouteRepositoryObjectResponse();
    }

    /**
     * Create an instance of {@link RouteWorkItem }
     * 
     */
    public RouteWorkItem createRouteWorkItem() {
        return new RouteWorkItem();
    }

    /**
     * Create an instance of {@link RouteWorkItemResponse }
     * 
     */
    public RouteWorkItemResponse createRouteWorkItemResponse() {
        return new RouteWorkItemResponse();
    }

    /**
     * Create an instance of {@link RpCreate }
     * 
     */
    public RpCreate createRpCreate() {
        return new RpCreate();
    }

    /**
     * Create an instance of {@link RpCreateContent }
     * 
     */
    public RpCreateContent createRpCreateContent() {
        return new RpCreateContent();
    }

    /**
     * Create an instance of {@link RpCreateContentResponse }
     * 
     */
    public RpCreateContentResponse createRpCreateContentResponse() {
        return new RpCreateContentResponse();
    }

    /**
     * Create an instance of {@link RpCreateResponse }
     * 
     */
    public RpCreateResponse createRpCreateResponse() {
        return new RpCreateResponse();
    }

    /**
     * Create an instance of {@link RpDelete }
     * 
     */
    public RpDelete createRpDelete() {
        return new RpDelete();
    }

    /**
     * Create an instance of {@link RpDeleteResponse }
     * 
     */
    public RpDeleteResponse createRpDeleteResponse() {
        return new RpDeleteResponse();
    }

    /**
     * Create an instance of {@link RpDoAction }
     * 
     */
    public RpDoAction createRpDoAction() {
        return new RpDoAction();
    }

    /**
     * Create an instance of {@link RpDoActionGetData }
     * 
     */
    public RpDoActionGetData createRpDoActionGetData() {
        return new RpDoActionGetData();
    }

    /**
     * Create an instance of {@link RpDoActionGetDataResponse }
     * 
     */
    public RpDoActionGetDataResponse createRpDoActionGetDataResponse() {
        return new RpDoActionGetDataResponse();
    }

    /**
     * Create an instance of {@link RpDoActionPostData }
     * 
     */
    public RpDoActionPostData createRpDoActionPostData() {
        return new RpDoActionPostData();
    }

    /**
     * Create an instance of {@link RpDoActionPostDataResponse }
     * 
     */
    public RpDoActionPostDataResponse createRpDoActionPostDataResponse() {
        return new RpDoActionPostDataResponse();
    }

    /**
     * Create an instance of {@link RpDoActionResponse }
     * 
     */
    public RpDoActionResponse createRpDoActionResponse() {
        return new RpDoActionResponse();
    }

    /**
     * Create an instance of {@link RpGet }
     * 
     */
    public RpGet createRpGet() {
        return new RpGet();
    }

    /**
     * Create an instance of {@link RpGetContent }
     * 
     */
    public RpGetContent createRpGetContent() {
        return new RpGetContent();
    }

    /**
     * Create an instance of {@link RpGetContentResponse }
     * 
     */
    public RpGetContentResponse createRpGetContentResponse() {
        return new RpGetContentResponse();
    }

    /**
     * Create an instance of {@link RpGetResponse }
     * 
     */
    public RpGetResponse createRpGetResponse() {
        return new RpGetResponse();
    }

    /**
     * Create an instance of {@link RpSet }
     * 
     */
    public RpSet createRpSet() {
        return new RpSet();
    }

    /**
     * Create an instance of {@link RpSetContent }
     * 
     */
    public RpSetContent createRpSetContent() {
        return new RpSetContent();
    }

    /**
     * Create an instance of {@link RpSetContentResponse }
     * 
     */
    public RpSetContentResponse createRpSetContentResponse() {
        return new RpSetContentResponse();
    }

    /**
     * Create an instance of {@link RpSetResponse }
     * 
     */
    public RpSetResponse createRpSetResponse() {
        return new RpSetResponse();
    }

    /**
     * Create an instance of {@link SendWorkItemToWorkstep }
     * 
     */
    public SendWorkItemToWorkstep createSendWorkItemToWorkstep() {
        return new SendWorkItemToWorkstep();
    }

    /**
     * Create an instance of {@link SendWorkItemToWorkstepResponse }
     * 
     */
    public SendWorkItemToWorkstepResponse createSendWorkItemToWorkstepResponse() {
        return new SendWorkItemToWorkstepResponse();
    }

    /**
     * Create an instance of {@link SetACLforRole }
     * 
     */
    public SetACLforRole createSetACLforRole() {
        return new SetACLforRole();
    }

    /**
     * Create an instance of {@link SetACLforRoleConditions }
     * 
     */
    public SetACLforRoleConditions createSetACLforRoleConditions() {
        return new SetACLforRoleConditions();
    }

    /**
     * Create an instance of {@link SetACLforRoleConditionsResponse }
     * 
     */
    public SetACLforRoleConditionsResponse createSetACLforRoleConditionsResponse() {
        return new SetACLforRoleConditionsResponse();
    }

    /**
     * Create an instance of {@link SetACLforRoleResponse }
     * 
     */
    public SetACLforRoleResponse createSetACLforRoleResponse() {
        return new SetACLforRoleResponse();
    }

    /**
     * Create an instance of {@link SetCaseFolder }
     * 
     */
    public SetCaseFolder createSetCaseFolder() {
        return new SetCaseFolder();
    }

    /**
     * Create an instance of {@link SetCaseFolderField }
     * 
     */
    public SetCaseFolderField createSetCaseFolderField() {
        return new SetCaseFolderField();
    }

    /**
     * Create an instance of {@link SetCaseFolderFieldResponse }
     * 
     */
    public SetCaseFolderFieldResponse createSetCaseFolderFieldResponse() {
        return new SetCaseFolderFieldResponse();
    }

    /**
     * Create an instance of {@link SetCaseFolderFields }
     * 
     */
    public SetCaseFolderFields createSetCaseFolderFields() {
        return new SetCaseFolderFields();
    }

    /**
     * Create an instance of {@link SetCaseFolderFieldsResponse }
     * 
     */
    public SetCaseFolderFieldsResponse createSetCaseFolderFieldsResponse() {
        return new SetCaseFolderFieldsResponse();
    }

    /**
     * Create an instance of {@link SetCaseFolderProperty }
     * 
     */
    public SetCaseFolderProperty createSetCaseFolderProperty() {
        return new SetCaseFolderProperty();
    }

    /**
     * Create an instance of {@link SetCaseFolderPropertyResponse }
     * 
     */
    public SetCaseFolderPropertyResponse createSetCaseFolderPropertyResponse() {
        return new SetCaseFolderPropertyResponse();
    }

    /**
     * Create an instance of {@link SetCaseFolderReadHistory }
     * 
     */
    public SetCaseFolderReadHistory createSetCaseFolderReadHistory() {
        return new SetCaseFolderReadHistory();
    }

    /**
     * Create an instance of {@link SetCaseFolderReadHistoryResponse }
     * 
     */
    public SetCaseFolderReadHistoryResponse createSetCaseFolderReadHistoryResponse() {
        return new SetCaseFolderReadHistoryResponse();
    }

    /**
     * Create an instance of {@link SetCaseFolderResponse }
     * 
     */
    public SetCaseFolderResponse createSetCaseFolderResponse() {
        return new SetCaseFolderResponse();
    }

    /**
     * Create an instance of {@link SetContent }
     * 
     */
    public SetContent createSetContent() {
        return new SetContent();
    }

    /**
     * Create an instance of {@link SetContentResponse }
     * 
     */
    public SetContentResponse createSetContentResponse() {
        return new SetContentResponse();
    }

    /**
     * Create an instance of {@link SetDiscussion }
     * 
     */
    public SetDiscussion createSetDiscussion() {
        return new SetDiscussion();
    }

    /**
     * Create an instance of {@link SetDiscussionResponse }
     * 
     */
    public SetDiscussionResponse createSetDiscussionResponse() {
        return new SetDiscussionResponse();
    }

    /**
     * Create an instance of {@link SetFileStore }
     * 
     */
    public SetFileStore createSetFileStore() {
        return new SetFileStore();
    }

    /**
     * Create an instance of {@link SetFileStoreFields }
     * 
     */
    public SetFileStoreFields createSetFileStoreFields() {
        return new SetFileStoreFields();
    }

    /**
     * Create an instance of {@link SetFileStoreResponse }
     * 
     */
    public SetFileStoreResponse createSetFileStoreResponse() {
        return new SetFileStoreResponse();
    }

    /**
     * Create an instance of {@link SetUserAttributeFieldsResponse }
     * 
     */
    public SetUserAttributeFieldsResponse createSetUserAttributeFieldsResponse() {
        return new SetUserAttributeFieldsResponse();
    }

    /**
     * Create an instance of {@link UserWsEvent1 }
     * 
     */
    public UserWsEvent1 createUserWsEvent1() {
        return new UserWsEvent1();
    }

    /**
     * Create an instance of {@link RemoveException }
     * 
     */
    public RemoveException createRemoveException() {
        return new RemoveException();
    }

    /**
     * Create an instance of {@link SetFileStoreFieldsResponse }
     * 
     */
    public SetFileStoreFieldsResponse createSetFileStoreFieldsResponse() {
        return new SetFileStoreFieldsResponse();
    }

    /**
     * Create an instance of {@link SetFileStoreReadHistory }
     * 
     */
    public SetFileStoreReadHistory createSetFileStoreReadHistory() {
        return new SetFileStoreReadHistory();
    }

    /**
     * Create an instance of {@link SetFileStoreReadHistoryResponse }
     * 
     */
    public SetFileStoreReadHistoryResponse createSetFileStoreReadHistoryResponse() {
        return new SetFileStoreReadHistoryResponse();
    }

    /**
     * Create an instance of {@link SetFormDataFields }
     * 
     */
    public SetFormDataFields createSetFormDataFields() {
        return new SetFormDataFields();
    }

    /**
     * Create an instance of {@link SetFormDataFieldsResponse }
     * 
     */
    public SetFormDataFieldsResponse createSetFormDataFieldsResponse() {
        return new SetFormDataFieldsResponse();
    }

    /**
     * Create an instance of {@link SetImageOrientation }
     * 
     */
    public SetImageOrientation createSetImageOrientation() {
        return new SetImageOrientation();
    }

    /**
     * Create an instance of {@link SetImageOrientationResponse }
     * 
     */
    public SetImageOrientationResponse createSetImageOrientationResponse() {
        return new SetImageOrientationResponse();
    }

    /**
     * Create an instance of {@link SetRelatedFields }
     * 
     */
    public SetRelatedFields createSetRelatedFields() {
        return new SetRelatedFields();
    }

    /**
     * Create an instance of {@link SetRelatedFieldsResponse }
     * 
     */
    public SetRelatedFieldsResponse createSetRelatedFieldsResponse() {
        return new SetRelatedFieldsResponse();
    }

    /**
     * Create an instance of {@link SetRepositoryFields }
     * 
     */
    public SetRepositoryFields createSetRepositoryFields() {
        return new SetRepositoryFields();
    }

    /**
     * Create an instance of {@link SetRepositoryFieldsResponse }
     * 
     */
    public SetRepositoryFieldsResponse createSetRepositoryFieldsResponse() {
        return new SetRepositoryFieldsResponse();
    }

    /**
     * Create an instance of {@link SetRoles }
     * 
     */
    public SetRoles createSetRoles() {
        return new SetRoles();
    }

    /**
     * Create an instance of {@link SetRolesResponse }
     * 
     */
    public SetRolesResponse createSetRolesResponse() {
        return new SetRolesResponse();
    }

    /**
     * Create an instance of {@link SetTask }
     * 
     */
    public SetTask createSetTask() {
        return new SetTask();
    }

    /**
     * Create an instance of {@link SetTaskResponse }
     * 
     */
    public SetTaskResponse createSetTaskResponse() {
        return new SetTaskResponse();
    }

    /**
     * Create an instance of {@link SetUser }
     * 
     */
    public SetUser createSetUser() {
        return new SetUser();
    }

    /**
     * Create an instance of {@link SetUserAttributeFields }
     * 
     */
    public SetUserAttributeFields createSetUserAttributeFields() {
        return new SetUserAttributeFields();
    }

    /**
     * Create an instance of {@link SetUserResponse }
     * 
     */
    public SetUserResponse createSetUserResponse() {
        return new SetUserResponse();
    }

    /**
     * Create an instance of {@link SetWorkItemFields }
     * 
     */
    public SetWorkItemFields createSetWorkItemFields() {
        return new SetWorkItemFields();
    }

    /**
     * Create an instance of {@link SetWorkItemFieldsResponse }
     * 
     */
    public SetWorkItemFieldsResponse createSetWorkItemFieldsResponse() {
        return new SetWorkItemFieldsResponse();
    }

    /**
     * Create an instance of {@link UnLockFileStore }
     * 
     */
    public UnLockFileStore createUnLockFileStore() {
        return new UnLockFileStore();
    }

    /**
     * Create an instance of {@link UnLockFileStoreResponse }
     * 
     */
    public UnLockFileStoreResponse createUnLockFileStoreResponse() {
        return new UnLockFileStoreResponse();
    }

    /**
     * Create an instance of {@link UnLockWorkItem }
     * 
     */
    public UnLockWorkItem createUnLockWorkItem() {
        return new UnLockWorkItem();
    }

    /**
     * Create an instance of {@link UnLockWorkItemResponse }
     * 
     */
    public UnLockWorkItemResponse createUnLockWorkItemResponse() {
        return new UnLockWorkItemResponse();
    }

    /**
     * Create an instance of {@link UnlockRepositoryObject }
     * 
     */
    public UnlockRepositoryObject createUnlockRepositoryObject() {
        return new UnlockRepositoryObject();
    }

    /**
     * Create an instance of {@link UnlockRepositoryObjectResponse }
     * 
     */
    public UnlockRepositoryObjectResponse createUnlockRepositoryObjectResponse() {
        return new UnlockRepositoryObjectResponse();
    }

    /**
     * Create an instance of {@link UserWsEvent1Response }
     * 
     */
    public UserWsEvent1Response createUserWsEvent1Response() {
        return new UserWsEvent1Response();
    }

    /**
     * Create an instance of {@link UserWsEvent2 }
     * 
     */
    public UserWsEvent2 createUserWsEvent2() {
        return new UserWsEvent2();
    }

    /**
     * Create an instance of {@link UserWsEvent2Response }
     * 
     */
    public UserWsEvent2Response createUserWsEvent2Response() {
        return new UserWsEvent2Response();
    }

    /**
     * Create an instance of {@link UserWsEvent3 }
     * 
     */
    public UserWsEvent3 createUserWsEvent3() {
        return new UserWsEvent3();
    }

    /**
     * Create an instance of {@link UserWsEvent3Response }
     * 
     */
    public UserWsEvent3Response createUserWsEvent3Response() {
        return new UserWsEvent3Response();
    }

    /**
     * Create an instance of {@link CreateException }
     * 
     */
    public CreateException createCreateException() {
        return new CreateException();
    }

    /**
     * Create an instance of {@link DocVersionElementTO }
     * 
     */
    public DocVersionElementTO createDocVersionElementTO() {
        return new DocVersionElementTO();
    }

    /**
     * Create an instance of {@link FSVersionElementTO }
     * 
     */
    public FSVersionElementTO createFSVersionElementTO() {
        return new FSVersionElementTO();
    }

    /**
     * Create an instance of {@link FileStoreConflictTO }
     * 
     */
    public FileStoreConflictTO createFileStoreConflictTO() {
        return new FileStoreConflictTO();
    }

    /**
     * Create an instance of {@link FileStoreTO }
     * 
     */
    public FileStoreTO createFileStoreTO() {
        return new FileStoreTO();
    }

    /**
     * Create an instance of {@link StorageElementTO }
     * 
     */
    public StorageElementTO createStorageElementTO() {
        return new StorageElementTO();
    }

    /**
     * Create an instance of {@link VersionTO }
     * 
     */
    public VersionTO createVersionTO() {
        return new VersionTO();
    }

    /**
     * Create an instance of {@link TaskConflictTO }
     * 
     */
    public TaskConflictTO createTaskConflictTO() {
        return new TaskConflictTO();
    }

    /**
     * Create an instance of {@link TaskTO }
     * 
     */
    public TaskTO createTaskTO() {
        return new TaskTO();
    }

    /**
     * Create an instance of {@link WorkFlowTO }
     * 
     */
    public WorkFlowTO createWorkFlowTO() {
        return new WorkFlowTO();
    }

    /**
     * Create an instance of {@link RepositoryContentStreamTO }
     * 
     */
    public RepositoryContentStreamTO createRepositoryContentStreamTO() {
        return new RepositoryContentStreamTO();
    }

    /**
     * Create an instance of {@link RepositoryItemTO }
     * 
     */
    public RepositoryItemTO createRepositoryItemTO() {
        return new RepositoryItemTO();
    }

    /**
     * Create an instance of {@link RepositoryPropertyDefinitionTO }
     * 
     */
    public RepositoryPropertyDefinitionTO createRepositoryPropertyDefinitionTO() {
        return new RepositoryPropertyDefinitionTO();
    }

    /**
     * Create an instance of {@link RepositoryPropertyRowTO }
     * 
     */
    public RepositoryPropertyRowTO createRepositoryPropertyRowTO() {
        return new RepositoryPropertyRowTO();
    }

    /**
     * Create an instance of {@link RepositoryPropertyTO }
     * 
     */
    public RepositoryPropertyTO createRepositoryPropertyTO() {
        return new RepositoryPropertyTO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateACL }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateACL }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createACL")
    public JAXBElement<CreateACL> createCreateACL(CreateACL value) {
        return new JAXBElement<CreateACL>(_CreateACL_QNAME, CreateACL.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateACLResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateACLResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createACLResponse")
    public JAXBElement<CreateACLResponse> createCreateACLResponse(CreateACLResponse value) {
        return new JAXBElement<CreateACLResponse>(_CreateACLResponse_QNAME, CreateACLResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateCaseFolder }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateCaseFolder }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createCaseFolder")
    public JAXBElement<CreateCaseFolder> createCreateCaseFolder(CreateCaseFolder value) {
        return new JAXBElement<CreateCaseFolder>(_CreateCaseFolder_QNAME, CreateCaseFolder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderFromXml }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderFromXml }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createCaseFolderFromXml")
    public JAXBElement<CreateCaseFolderFromXml> createCreateCaseFolderFromXml(CreateCaseFolderFromXml value) {
        return new JAXBElement<CreateCaseFolderFromXml>(_CreateCaseFolderFromXml_QNAME, CreateCaseFolderFromXml.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderFromXmlResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderFromXmlResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createCaseFolderFromXmlResponse")
    public JAXBElement<CreateCaseFolderFromXmlResponse> createCreateCaseFolderFromXmlResponse(CreateCaseFolderFromXmlResponse value) {
        return new JAXBElement<CreateCaseFolderFromXmlResponse>(_CreateCaseFolderFromXmlResponse_QNAME, CreateCaseFolderFromXmlResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateCaseFolderResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createCaseFolderResponse")
    public JAXBElement<CreateCaseFolderResponse> createCreateCaseFolderResponse(CreateCaseFolderResponse value) {
        return new JAXBElement<CreateCaseFolderResponse>(_CreateCaseFolderResponse_QNAME, CreateCaseFolderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createContent")
    public JAXBElement<CreateContent> createCreateContent(CreateContent value) {
        return new JAXBElement<CreateContent>(_CreateContent_QNAME, CreateContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createContentResponse")
    public JAXBElement<CreateContentResponse> createCreateContentResponse(CreateContentResponse value) {
        return new JAXBElement<CreateContentResponse>(_CreateContentResponse_QNAME, CreateContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateDiscussion }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateDiscussion }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createDiscussion")
    public JAXBElement<CreateDiscussion> createCreateDiscussion(CreateDiscussion value) {
        return new JAXBElement<CreateDiscussion>(_CreateDiscussion_QNAME, CreateDiscussion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateDiscussionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateDiscussionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createDiscussionResponse")
    public JAXBElement<CreateDiscussionResponse> createCreateDiscussionResponse(CreateDiscussionResponse value) {
        return new JAXBElement<CreateDiscussionResponse>(_CreateDiscussionResponse_QNAME, CreateDiscussionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createFileStore")
    public JAXBElement<CreateFileStore> createCreateFileStore(CreateFileStore value) {
        return new JAXBElement<CreateFileStore>(_CreateFileStore_QNAME, CreateFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createFileStoreResponse")
    public JAXBElement<CreateFileStoreResponse> createCreateFileStoreResponse(CreateFileStoreResponse value) {
        return new JAXBElement<CreateFileStoreResponse>(_CreateFileStoreResponse_QNAME, CreateFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFormDataFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateFormDataFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createFormDataFields")
    public JAXBElement<CreateFormDataFields> createCreateFormDataFields(CreateFormDataFields value) {
        return new JAXBElement<CreateFormDataFields>(_CreateFormDataFields_QNAME, CreateFormDataFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFormDataFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateFormDataFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createFormDataFieldsResponse")
    public JAXBElement<CreateFormDataFieldsResponse> createCreateFormDataFieldsResponse(CreateFormDataFieldsResponse value) {
        return new JAXBElement<CreateFormDataFieldsResponse>(_CreateFormDataFieldsResponse_QNAME, CreateFormDataFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRelatedFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRelatedFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRelatedFields")
    public JAXBElement<CreateRelatedFields> createCreateRelatedFields(CreateRelatedFields value) {
        return new JAXBElement<CreateRelatedFields>(_CreateRelatedFields_QNAME, CreateRelatedFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRelatedFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRelatedFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRelatedFieldsResponse")
    public JAXBElement<CreateRelatedFieldsResponse> createCreateRelatedFieldsResponse(CreateRelatedFieldsResponse value) {
        return new JAXBElement<CreateRelatedFieldsResponse>(_CreateRelatedFieldsResponse_QNAME, CreateRelatedFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRepositoryObject }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRepositoryObject }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRepositoryObject")
    public JAXBElement<CreateRepositoryObject> createCreateRepositoryObject(CreateRepositoryObject value) {
        return new JAXBElement<CreateRepositoryObject>(_CreateRepositoryObject_QNAME, CreateRepositoryObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRepositoryObjectResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRepositoryObjectResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRepositoryObjectResponse")
    public JAXBElement<CreateRepositoryObjectResponse> createCreateRepositoryObjectResponse(CreateRepositoryObjectResponse value) {
        return new JAXBElement<CreateRepositoryObjectResponse>(_CreateRepositoryObjectResponse_QNAME, CreateRepositoryObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRole }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRole")
    public JAXBElement<CreateRole> createCreateRole(CreateRole value) {
        return new JAXBElement<CreateRole>(_CreateRole_QNAME, CreateRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateRoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createRoleResponse")
    public JAXBElement<CreateRoleResponse> createCreateRoleResponse(CreateRoleResponse value) {
        return new JAXBElement<CreateRoleResponse>(_CreateRoleResponse_QNAME, CreateRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateTask }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateTask }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createTask")
    public JAXBElement<CreateTask> createCreateTask(CreateTask value) {
        return new JAXBElement<CreateTask>(_CreateTask_QNAME, CreateTask.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateTaskResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateTaskResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createTaskResponse")
    public JAXBElement<CreateTaskResponse> createCreateTaskResponse(CreateTaskResponse value) {
        return new JAXBElement<CreateTaskResponse>(_CreateTaskResponse_QNAME, CreateTaskResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateUser }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateUser }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createUser")
    public JAXBElement<CreateUser> createCreateUser(CreateUser value) {
        return new JAXBElement<CreateUser>(_CreateUser_QNAME, CreateUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateUserResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateUserResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createUserResponse")
    public JAXBElement<CreateUserResponse> createCreateUserResponse(CreateUserResponse value) {
        return new JAXBElement<CreateUserResponse>(_CreateUserResponse_QNAME, CreateUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateWorkFlow }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateWorkFlow }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createWorkFlow")
    public JAXBElement<CreateWorkFlow> createCreateWorkFlow(CreateWorkFlow value) {
        return new JAXBElement<CreateWorkFlow>(_CreateWorkFlow_QNAME, CreateWorkFlow.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateWorkFlowResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateWorkFlowResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createWorkFlowResponse")
    public JAXBElement<CreateWorkFlowResponse> createCreateWorkFlowResponse(CreateWorkFlowResponse value) {
        return new JAXBElement<CreateWorkFlowResponse>(_CreateWorkFlowResponse_QNAME, CreateWorkFlowResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateWorkItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateWorkItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createWorkItem")
    public JAXBElement<CreateWorkItem> createCreateWorkItem(CreateWorkItem value) {
        return new JAXBElement<CreateWorkItem>(_CreateWorkItem_QNAME, CreateWorkItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateWorkItemResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateWorkItemResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "createWorkItemResponse")
    public JAXBElement<CreateWorkItemResponse> createCreateWorkItemResponse(CreateWorkItemResponse value) {
        return new JAXBElement<CreateWorkItemResponse>(_CreateWorkItemResponse_QNAME, CreateWorkItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImageMarks }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImageMarks }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImageMarks")
    public JAXBElement<DeleteImageMarks> createDeleteImageMarks(DeleteImageMarks value) {
        return new JAXBElement<DeleteImageMarks>(_DeleteImageMarks_QNAME, DeleteImageMarks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImageMarksResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImageMarksResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImageMarksResponse")
    public JAXBElement<DeleteImageMarksResponse> createDeleteImageMarksResponse(DeleteImageMarksResponse value) {
        return new JAXBElement<DeleteImageMarksResponse>(_DeleteImageMarksResponse_QNAME, DeleteImageMarksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImagePage }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImagePage }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImagePage")
    public JAXBElement<DeleteImagePage> createDeleteImagePage(DeleteImagePage value) {
        return new JAXBElement<DeleteImagePage>(_DeleteImagePage_QNAME, DeleteImagePage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImagePageResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImagePageResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImagePageResponse")
    public JAXBElement<DeleteImagePageResponse> createDeleteImagePageResponse(DeleteImagePageResponse value) {
        return new JAXBElement<DeleteImagePageResponse>(_DeleteImagePageResponse_QNAME, DeleteImagePageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImagePages }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImagePages }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImagePages")
    public JAXBElement<DeleteImagePages> createDeleteImagePages(DeleteImagePages value) {
        return new JAXBElement<DeleteImagePages>(_DeleteImagePages_QNAME, DeleteImagePages.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImagePagesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImagePagesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImagePagesResponse")
    public JAXBElement<DeleteImagePagesResponse> createDeleteImagePagesResponse(DeleteImagePagesResponse value) {
        return new JAXBElement<DeleteImagePagesResponse>(_DeleteImagePagesResponse_QNAME, DeleteImagePagesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImageThumbnail }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImageThumbnail }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImageThumbnail")
    public JAXBElement<DeleteImageThumbnail> createDeleteImageThumbnail(DeleteImageThumbnail value) {
        return new JAXBElement<DeleteImageThumbnail>(_DeleteImageThumbnail_QNAME, DeleteImageThumbnail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteImageThumbnailResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteImageThumbnailResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteImageThumbnailResponse")
    public JAXBElement<DeleteImageThumbnailResponse> createDeleteImageThumbnailResponse(DeleteImageThumbnailResponse value) {
        return new JAXBElement<DeleteImageThumbnailResponse>(_DeleteImageThumbnailResponse_QNAME, DeleteImageThumbnailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRepositoryObject }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteRepositoryObject }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteRepositoryObject")
    public JAXBElement<DeleteRepositoryObject> createDeleteRepositoryObject(DeleteRepositoryObject value) {
        return new JAXBElement<DeleteRepositoryObject>(_DeleteRepositoryObject_QNAME, DeleteRepositoryObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRepositoryObjectResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DeleteRepositoryObjectResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "deleteRepositoryObjectResponse")
    public JAXBElement<DeleteRepositoryObjectResponse> createDeleteRepositoryObjectResponse(DeleteRepositoryObjectResponse value) {
        return new JAXBElement<DeleteRepositoryObjectResponse>(_DeleteRepositoryObjectResponse_QNAME, DeleteRepositoryObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQuery }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQuery }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQuery")
    public JAXBElement<DoQuery> createDoQuery(DoQuery value) {
        return new JAXBElement<DoQuery>(_DoQuery_QNAME, DoQuery.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByName")
    public JAXBElement<DoQueryByName> createDoQueryByName(DoQueryByName value) {
        return new JAXBElement<DoQueryByName>(_DoQueryByName_QNAME, DoQueryByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameEx")
    public JAXBElement<DoQueryByNameEx> createDoQueryByNameEx(DoQueryByNameEx value) {
        return new JAXBElement<DoQueryByNameEx>(_DoQueryByNameEx_QNAME, DoQueryByNameEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameExResponse")
    public JAXBElement<DoQueryByNameExResponse> createDoQueryByNameExResponse(DoQueryByNameExResponse value) {
        return new JAXBElement<DoQueryByNameExResponse>(_DoQueryByNameExResponse_QNAME, DoQueryByNameExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameNoFormFields")
    public JAXBElement<DoQueryByNameNoFormFields> createDoQueryByNameNoFormFields(DoQueryByNameNoFormFields value) {
        return new JAXBElement<DoQueryByNameNoFormFields>(_DoQueryByNameNoFormFields_QNAME, DoQueryByNameNoFormFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameNoFormFieldsEx")
    public JAXBElement<DoQueryByNameNoFormFieldsEx> createDoQueryByNameNoFormFieldsEx(DoQueryByNameNoFormFieldsEx value) {
        return new JAXBElement<DoQueryByNameNoFormFieldsEx>(_DoQueryByNameNoFormFieldsEx_QNAME, DoQueryByNameNoFormFieldsEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameNoFormFieldsExResponse")
    public JAXBElement<DoQueryByNameNoFormFieldsExResponse> createDoQueryByNameNoFormFieldsExResponse(DoQueryByNameNoFormFieldsExResponse value) {
        return new JAXBElement<DoQueryByNameNoFormFieldsExResponse>(_DoQueryByNameNoFormFieldsExResponse_QNAME, DoQueryByNameNoFormFieldsExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameNoFormFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameNoFormFieldsResponse")
    public JAXBElement<DoQueryByNameNoFormFieldsResponse> createDoQueryByNameNoFormFieldsResponse(DoQueryByNameNoFormFieldsResponse value) {
        return new JAXBElement<DoQueryByNameNoFormFieldsResponse>(_DoQueryByNameNoFormFieldsResponse_QNAME, DoQueryByNameNoFormFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByNameResponse")
    public JAXBElement<DoQueryByNameResponse> createDoQueryByNameResponse(DoQueryByNameResponse value) {
        return new JAXBElement<DoQueryByNameResponse>(_DoQueryByNameResponse_QNAME, DoQueryByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptName")
    public JAXBElement<DoQueryByScriptName> createDoQueryByScriptName(DoQueryByScriptName value) {
        return new JAXBElement<DoQueryByScriptName>(_DoQueryByScriptName_QNAME, DoQueryByScriptName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameEx")
    public JAXBElement<DoQueryByScriptNameEx> createDoQueryByScriptNameEx(DoQueryByScriptNameEx value) {
        return new JAXBElement<DoQueryByScriptNameEx>(_DoQueryByScriptNameEx_QNAME, DoQueryByScriptNameEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameExResponse")
    public JAXBElement<DoQueryByScriptNameExResponse> createDoQueryByScriptNameExResponse(DoQueryByScriptNameExResponse value) {
        return new JAXBElement<DoQueryByScriptNameExResponse>(_DoQueryByScriptNameExResponse_QNAME, DoQueryByScriptNameExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameNoFormFields")
    public JAXBElement<DoQueryByScriptNameNoFormFields> createDoQueryByScriptNameNoFormFields(DoQueryByScriptNameNoFormFields value) {
        return new JAXBElement<DoQueryByScriptNameNoFormFields>(_DoQueryByScriptNameNoFormFields_QNAME, DoQueryByScriptNameNoFormFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameNoFormFieldsEx")
    public JAXBElement<DoQueryByScriptNameNoFormFieldsEx> createDoQueryByScriptNameNoFormFieldsEx(DoQueryByScriptNameNoFormFieldsEx value) {
        return new JAXBElement<DoQueryByScriptNameNoFormFieldsEx>(_DoQueryByScriptNameNoFormFieldsEx_QNAME, DoQueryByScriptNameNoFormFieldsEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameNoFormFieldsExResponse")
    public JAXBElement<DoQueryByScriptNameNoFormFieldsExResponse> createDoQueryByScriptNameNoFormFieldsExResponse(DoQueryByScriptNameNoFormFieldsExResponse value) {
        return new JAXBElement<DoQueryByScriptNameNoFormFieldsExResponse>(_DoQueryByScriptNameNoFormFieldsExResponse_QNAME, DoQueryByScriptNameNoFormFieldsExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameNoFormFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameNoFormFieldsResponse")
    public JAXBElement<DoQueryByScriptNameNoFormFieldsResponse> createDoQueryByScriptNameNoFormFieldsResponse(DoQueryByScriptNameNoFormFieldsResponse value) {
        return new JAXBElement<DoQueryByScriptNameNoFormFieldsResponse>(_DoQueryByScriptNameNoFormFieldsResponse_QNAME, DoQueryByScriptNameNoFormFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryByScriptNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryByScriptNameResponse")
    public JAXBElement<DoQueryByScriptNameResponse> createDoQueryByScriptNameResponse(DoQueryByScriptNameResponse value) {
        return new JAXBElement<DoQueryByScriptNameResponse>(_DoQueryByScriptNameResponse_QNAME, DoQueryByScriptNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryEx")
    public JAXBElement<DoQueryEx> createDoQueryEx(DoQueryEx value) {
        return new JAXBElement<DoQueryEx>(_DoQueryEx_QNAME, DoQueryEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryExResponse")
    public JAXBElement<DoQueryExResponse> createDoQueryExResponse(DoQueryExResponse value) {
        return new JAXBElement<DoQueryExResponse>(_DoQueryExResponse_QNAME, DoQueryExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryNoFormFields")
    public JAXBElement<DoQueryNoFormFields> createDoQueryNoFormFields(DoQueryNoFormFields value) {
        return new JAXBElement<DoQueryNoFormFields>(_DoQueryNoFormFields_QNAME, DoQueryNoFormFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryNoFormFieldsEx")
    public JAXBElement<DoQueryNoFormFieldsEx> createDoQueryNoFormFieldsEx(DoQueryNoFormFieldsEx value) {
        return new JAXBElement<DoQueryNoFormFieldsEx>(_DoQueryNoFormFieldsEx_QNAME, DoQueryNoFormFieldsEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryNoFormFieldsExResponse")
    public JAXBElement<DoQueryNoFormFieldsExResponse> createDoQueryNoFormFieldsExResponse(DoQueryNoFormFieldsExResponse value) {
        return new JAXBElement<DoQueryNoFormFieldsExResponse>(_DoQueryNoFormFieldsExResponse_QNAME, DoQueryNoFormFieldsExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryNoFormFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryNoFormFieldsResponse")
    public JAXBElement<DoQueryNoFormFieldsResponse> createDoQueryNoFormFieldsResponse(DoQueryNoFormFieldsResponse value) {
        return new JAXBElement<DoQueryNoFormFieldsResponse>(_DoQueryNoFormFieldsResponse_QNAME, DoQueryNoFormFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DoQueryResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link DoQueryResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "doQueryResponse")
    public JAXBElement<DoQueryResponse> createDoQueryResponse(DoQueryResponse value) {
        return new JAXBElement<DoQueryResponse>(_DoQueryResponse_QNAME, DoQueryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAcls }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAcls }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getAcls")
    public JAXBElement<GetAcls> createGetAcls(GetAcls value) {
        return new JAXBElement<GetAcls>(_GetAcls_QNAME, GetAcls.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAclsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAclsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getAclsResponse")
    public JAXBElement<GetAclsResponse> createGetAclsResponse(GetAclsResponse value) {
        return new JAXBElement<GetAclsResponse>(_GetAclsResponse_QNAME, GetAclsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolder }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolder }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolder")
    public JAXBElement<GetCaseFolder> createGetCaseFolder(GetCaseFolder value) {
        return new JAXBElement<GetCaseFolder>(_GetCaseFolder_QNAME, GetCaseFolder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderAsXml }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderAsXml }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderAsXml")
    public JAXBElement<GetCaseFolderAsXml> createGetCaseFolderAsXml(GetCaseFolderAsXml value) {
        return new JAXBElement<GetCaseFolderAsXml>(_GetCaseFolderAsXml_QNAME, GetCaseFolderAsXml.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderAsXmlResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderAsXmlResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderAsXmlResponse")
    public JAXBElement<GetCaseFolderAsXmlResponse> createGetCaseFolderAsXmlResponse(GetCaseFolderAsXmlResponse value) {
        return new JAXBElement<GetCaseFolderAsXmlResponse>(_GetCaseFolderAsXmlResponse_QNAME, GetCaseFolderAsXmlResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderField }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderField }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderField")
    public JAXBElement<GetCaseFolderField> createGetCaseFolderField(GetCaseFolderField value) {
        return new JAXBElement<GetCaseFolderField>(_GetCaseFolderField_QNAME, GetCaseFolderField.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFieldResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFieldResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderFieldResponse")
    public JAXBElement<GetCaseFolderFieldResponse> createGetCaseFolderFieldResponse(GetCaseFolderFieldResponse value) {
        return new JAXBElement<GetCaseFolderFieldResponse>(_GetCaseFolderFieldResponse_QNAME, GetCaseFolderFieldResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderFields")
    public JAXBElement<GetCaseFolderFields> createGetCaseFolderFields(GetCaseFolderFields value) {
        return new JAXBElement<GetCaseFolderFields>(_GetCaseFolderFields_QNAME, GetCaseFolderFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderFieldsResponse")
    public JAXBElement<GetCaseFolderFieldsResponse> createGetCaseFolderFieldsResponse(GetCaseFolderFieldsResponse value) {
        return new JAXBElement<GetCaseFolderFieldsResponse>(_GetCaseFolderFieldsResponse_QNAME, GetCaseFolderFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderResponse")
    public JAXBElement<GetCaseFolderResponse> createGetCaseFolderResponse(GetCaseFolderResponse value) {
        return new JAXBElement<GetCaseFolderResponse>(_GetCaseFolderResponse_QNAME, GetCaseFolderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderTemplates }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderTemplates }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderTemplates")
    public JAXBElement<GetCaseFolderTemplates> createGetCaseFolderTemplates(GetCaseFolderTemplates value) {
        return new JAXBElement<GetCaseFolderTemplates>(_GetCaseFolderTemplates_QNAME, GetCaseFolderTemplates.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaseFolderTemplatesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetCaseFolderTemplatesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getCaseFolderTemplatesResponse")
    public JAXBElement<GetCaseFolderTemplatesResponse> createGetCaseFolderTemplatesResponse(GetCaseFolderTemplatesResponse value) {
        return new JAXBElement<GetCaseFolderTemplatesResponse>(_GetCaseFolderTemplatesResponse_QNAME, GetCaseFolderTemplatesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContent")
    public JAXBElement<GetContent> createGetContent(GetContent value) {
        return new JAXBElement<GetContent>(_GetContent_QNAME, GetContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentByName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentByName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentByName")
    public JAXBElement<GetContentByName> createGetContentByName(GetContentByName value) {
        return new JAXBElement<GetContentByName>(_GetContentByName_QNAME, GetContentByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentByNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentByNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentByNameResponse")
    public JAXBElement<GetContentByNameResponse> createGetContentByNameResponse(GetContentByNameResponse value) {
        return new JAXBElement<GetContentByNameResponse>(_GetContentByNameResponse_QNAME, GetContentByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentElements }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentElements }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentElements")
    public JAXBElement<GetContentElements> createGetContentElements(GetContentElements value) {
        return new JAXBElement<GetContentElements>(_GetContentElements_QNAME, GetContentElements.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentElementsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentElementsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentElementsResponse")
    public JAXBElement<GetContentElementsResponse> createGetContentElementsResponse(GetContentElementsResponse value) {
        return new JAXBElement<GetContentElementsResponse>(_GetContentElementsResponse_QNAME, GetContentElementsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentResponse")
    public JAXBElement<GetContentResponse> createGetContentResponse(GetContentResponse value) {
        return new JAXBElement<GetContentResponse>(_GetContentResponse_QNAME, GetContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContents }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContents }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContents")
    public JAXBElement<GetContents> createGetContents(GetContents value) {
        return new JAXBElement<GetContents>(_GetContents_QNAME, GetContents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetContentsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetContentsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getContentsResponse")
    public JAXBElement<GetContentsResponse> createGetContentsResponse(GetContentsResponse value) {
        return new JAXBElement<GetContentsResponse>(_GetContentsResponse_QNAME, GetContentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDiscussion }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDiscussion }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDiscussion")
    public JAXBElement<GetDiscussion> createGetDiscussion(GetDiscussion value) {
        return new JAXBElement<GetDiscussion>(_GetDiscussion_QNAME, GetDiscussion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDiscussionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDiscussionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDiscussionResponse")
    public JAXBElement<GetDiscussionResponse> createGetDiscussionResponse(GetDiscussionResponse value) {
        return new JAXBElement<GetDiscussionResponse>(_GetDiscussionResponse_QNAME, GetDiscussionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDiscussions }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDiscussions }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDiscussions")
    public JAXBElement<GetDiscussions> createGetDiscussions(GetDiscussions value) {
        return new JAXBElement<GetDiscussions>(_GetDiscussions_QNAME, GetDiscussions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDiscussionsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDiscussionsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDiscussionsResponse")
    public JAXBElement<GetDiscussionsResponse> createGetDiscussionsResponse(GetDiscussionsResponse value) {
        return new JAXBElement<GetDiscussionsResponse>(_GetDiscussionsResponse_QNAME, GetDiscussionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentElements }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDocumentElements }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDocumentElements")
    public JAXBElement<GetDocumentElements> createGetDocumentElements(GetDocumentElements value) {
        return new JAXBElement<GetDocumentElements>(_GetDocumentElements_QNAME, GetDocumentElements.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDocumentElementsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetDocumentElementsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getDocumentElementsResponse")
    public JAXBElement<GetDocumentElementsResponse> createGetDocumentElementsResponse(GetDocumentElementsResponse value) {
        return new JAXBElement<GetDocumentElementsResponse>(_GetDocumentElementsResponse_QNAME, GetDocumentElementsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElementDiscussions }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElementDiscussions }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getElementDiscussions")
    public JAXBElement<GetElementDiscussions> createGetElementDiscussions(GetElementDiscussions value) {
        return new JAXBElement<GetElementDiscussions>(_GetElementDiscussions_QNAME, GetElementDiscussions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetElementDiscussionsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetElementDiscussionsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getElementDiscussionsResponse")
    public JAXBElement<GetElementDiscussionsResponse> createGetElementDiscussionsResponse(GetElementDiscussionsResponse value) {
        return new JAXBElement<GetElementDiscussionsResponse>(_GetElementDiscussionsResponse_QNAME, GetElementDiscussionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFields")
    public JAXBElement<GetFields> createGetFields(GetFields value) {
        return new JAXBElement<GetFields>(_GetFields_QNAME, GetFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFieldsResponse")
    public JAXBElement<GetFieldsResponse> createGetFieldsResponse(GetFieldsResponse value) {
        return new JAXBElement<GetFieldsResponse>(_GetFieldsResponse_QNAME, GetFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFile }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFile }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFile")
    public JAXBElement<GetFile> createGetFile(GetFile value) {
        return new JAXBElement<GetFile>(_GetFile_QNAME, GetFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileByName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileByName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileByName")
    public JAXBElement<GetFileByName> createGetFileByName(GetFileByName value) {
        return new JAXBElement<GetFileByName>(_GetFileByName_QNAME, GetFileByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileByNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileByNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileByNameResponse")
    public JAXBElement<GetFileByNameResponse> createGetFileByNameResponse(GetFileByNameResponse value) {
        return new JAXBElement<GetFileByNameResponse>(_GetFileByNameResponse_QNAME, GetFileByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileRendition }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileRendition }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileRendition")
    public JAXBElement<GetFileRendition> createGetFileRendition(GetFileRendition value) {
        return new JAXBElement<GetFileRendition>(_GetFileRendition_QNAME, GetFileRendition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileRenditionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileRenditionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileRenditionResponse")
    public JAXBElement<GetFileRenditionResponse> createGetFileRenditionResponse(GetFileRenditionResponse value) {
        return new JAXBElement<GetFileRenditionResponse>(_GetFileRenditionResponse_QNAME, GetFileRenditionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileResponse")
    public JAXBElement<GetFileResponse> createGetFileResponse(GetFileResponse value) {
        return new JAXBElement<GetFileResponse>(_GetFileResponse_QNAME, GetFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStore")
    public JAXBElement<GetFileStore> createGetFileStore(GetFileStore value) {
        return new JAXBElement<GetFileStore>(_GetFileStore_QNAME, GetFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStoreFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStoreFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStoreFields")
    public JAXBElement<GetFileStoreFields> createGetFileStoreFields(GetFileStoreFields value) {
        return new JAXBElement<GetFileStoreFields>(_GetFileStoreFields_QNAME, GetFileStoreFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStoreFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStoreFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStoreFieldsResponse")
    public JAXBElement<GetFileStoreFieldsResponse> createGetFileStoreFieldsResponse(GetFileStoreFieldsResponse value) {
        return new JAXBElement<GetFileStoreFieldsResponse>(_GetFileStoreFieldsResponse_QNAME, GetFileStoreFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStoreResponse")
    public JAXBElement<GetFileStoreResponse> createGetFileStoreResponse(GetFileStoreResponse value) {
        return new JAXBElement<GetFileStoreResponse>(_GetFileStoreResponse_QNAME, GetFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStoreTemplates }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStoreTemplates }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStoreTemplates")
    public JAXBElement<GetFileStoreTemplates> createGetFileStoreTemplates(GetFileStoreTemplates value) {
        return new JAXBElement<GetFileStoreTemplates>(_GetFileStoreTemplates_QNAME, GetFileStoreTemplates.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileStoreTemplatesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFileStoreTemplatesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFileStoreTemplatesResponse")
    public JAXBElement<GetFileStoreTemplatesResponse> createGetFileStoreTemplatesResponse(GetFileStoreTemplatesResponse value) {
        return new JAXBElement<GetFileStoreTemplatesResponse>(_GetFileStoreTemplatesResponse_QNAME, GetFileStoreTemplatesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFormDataFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFormDataFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFormDataFields")
    public JAXBElement<GetFormDataFields> createGetFormDataFields(GetFormDataFields value) {
        return new JAXBElement<GetFormDataFields>(_GetFormDataFields_QNAME, GetFormDataFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFormDataFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetFormDataFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getFormDataFieldsResponse")
    public JAXBElement<GetFormDataFieldsResponse> createGetFormDataFieldsResponse(GetFormDataFieldsResponse value) {
        return new JAXBElement<GetFormDataFieldsResponse>(_GetFormDataFieldsResponse_QNAME, GetFormDataFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImageMarks }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImageMarks }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImageMarks")
    public JAXBElement<GetImageMarks> createGetImageMarks(GetImageMarks value) {
        return new JAXBElement<GetImageMarks>(_GetImageMarks_QNAME, GetImageMarks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImageMarksResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImageMarksResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImageMarksResponse")
    public JAXBElement<GetImageMarksResponse> createGetImageMarksResponse(GetImageMarksResponse value) {
        return new JAXBElement<GetImageMarksResponse>(_GetImageMarksResponse_QNAME, GetImageMarksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImagePage }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImagePage }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImagePage")
    public JAXBElement<GetImagePage> createGetImagePage(GetImagePage value) {
        return new JAXBElement<GetImagePage>(_GetImagePage_QNAME, GetImagePage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImagePageCount }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImagePageCount }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImagePageCount")
    public JAXBElement<GetImagePageCount> createGetImagePageCount(GetImagePageCount value) {
        return new JAXBElement<GetImagePageCount>(_GetImagePageCount_QNAME, GetImagePageCount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImagePageCountResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImagePageCountResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImagePageCountResponse")
    public JAXBElement<GetImagePageCountResponse> createGetImagePageCountResponse(GetImagePageCountResponse value) {
        return new JAXBElement<GetImagePageCountResponse>(_GetImagePageCountResponse_QNAME, GetImagePageCountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImagePageResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImagePageResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImagePageResponse")
    public JAXBElement<GetImagePageResponse> createGetImagePageResponse(GetImagePageResponse value) {
        return new JAXBElement<GetImagePageResponse>(_GetImagePageResponse_QNAME, GetImagePageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImageThumbnail }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImageThumbnail }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImageThumbnail")
    public JAXBElement<GetImageThumbnail> createGetImageThumbnail(GetImageThumbnail value) {
        return new JAXBElement<GetImageThumbnail>(_GetImageThumbnail_QNAME, GetImageThumbnail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetImageThumbnailResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetImageThumbnailResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getImageThumbnailResponse")
    public JAXBElement<GetImageThumbnailResponse> createGetImageThumbnailResponse(GetImageThumbnailResponse value) {
        return new JAXBElement<GetImageThumbnailResponse>(_GetImageThumbnailResponse_QNAME, GetImageThumbnailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPartialFile }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetPartialFile }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getPartialFile")
    public JAXBElement<GetPartialFile> createGetPartialFile(GetPartialFile value) {
        return new JAXBElement<GetPartialFile>(_GetPartialFile_QNAME, GetPartialFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPartialFileRendition }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetPartialFileRendition }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getPartialFileRendition")
    public JAXBElement<GetPartialFileRendition> createGetPartialFileRendition(GetPartialFileRendition value) {
        return new JAXBElement<GetPartialFileRendition>(_GetPartialFileRendition_QNAME, GetPartialFileRendition.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPartialFileRenditionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetPartialFileRenditionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getPartialFileRenditionResponse")
    public JAXBElement<GetPartialFileRenditionResponse> createGetPartialFileRenditionResponse(GetPartialFileRenditionResponse value) {
        return new JAXBElement<GetPartialFileRenditionResponse>(_GetPartialFileRenditionResponse_QNAME, GetPartialFileRenditionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPartialFileResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetPartialFileResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getPartialFileResponse")
    public JAXBElement<GetPartialFileResponse> createGetPartialFileResponse(GetPartialFileResponse value) {
        return new JAXBElement<GetPartialFileResponse>(_GetPartialFileResponse_QNAME, GetPartialFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryCategories }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryCategories }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryCategories")
    public JAXBElement<GetQueryCategories> createGetQueryCategories(GetQueryCategories value) {
        return new JAXBElement<GetQueryCategories>(_GetQueryCategories_QNAME, GetQueryCategories.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryCategoriesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryCategoriesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryCategoriesResponse")
    public JAXBElement<GetQueryCategoriesResponse> createGetQueryCategoriesResponse(GetQueryCategoriesResponse value) {
        return new JAXBElement<GetQueryCategoriesResponse>(_GetQueryCategoriesResponse_QNAME, GetQueryCategoriesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfo }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfo }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryColumnInfo")
    public JAXBElement<GetQueryColumnInfo> createGetQueryColumnInfo(GetQueryColumnInfo value) {
        return new JAXBElement<GetQueryColumnInfo>(_GetQueryColumnInfo_QNAME, GetQueryColumnInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoByScriptName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoByScriptName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryColumnInfoByScriptName")
    public JAXBElement<GetQueryColumnInfoByScriptName> createGetQueryColumnInfoByScriptName(GetQueryColumnInfoByScriptName value) {
        return new JAXBElement<GetQueryColumnInfoByScriptName>(_GetQueryColumnInfoByScriptName_QNAME, GetQueryColumnInfoByScriptName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoByScriptNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoByScriptNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryColumnInfoByScriptNameResponse")
    public JAXBElement<GetQueryColumnInfoByScriptNameResponse> createGetQueryColumnInfoByScriptNameResponse(GetQueryColumnInfoByScriptNameResponse value) {
        return new JAXBElement<GetQueryColumnInfoByScriptNameResponse>(_GetQueryColumnInfoByScriptNameResponse_QNAME, GetQueryColumnInfoByScriptNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryColumnInfoResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryColumnInfoResponse")
    public JAXBElement<GetQueryColumnInfoResponse> createGetQueryColumnInfoResponse(GetQueryColumnInfoResponse value) {
        return new JAXBElement<GetQueryColumnInfoResponse>(_GetQueryColumnInfoResponse_QNAME, GetQueryColumnInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryFormFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryFormFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryFormFields")
    public JAXBElement<GetQueryFormFields> createGetQueryFormFields(GetQueryFormFields value) {
        return new JAXBElement<GetQueryFormFields>(_GetQueryFormFields_QNAME, GetQueryFormFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsByScriptName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsByScriptName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryFormFieldsByScriptName")
    public JAXBElement<GetQueryFormFieldsByScriptName> createGetQueryFormFieldsByScriptName(GetQueryFormFieldsByScriptName value) {
        return new JAXBElement<GetQueryFormFieldsByScriptName>(_GetQueryFormFieldsByScriptName_QNAME, GetQueryFormFieldsByScriptName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsByScriptNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsByScriptNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryFormFieldsByScriptNameResponse")
    public JAXBElement<GetQueryFormFieldsByScriptNameResponse> createGetQueryFormFieldsByScriptNameResponse(GetQueryFormFieldsByScriptNameResponse value) {
        return new JAXBElement<GetQueryFormFieldsByScriptNameResponse>(_GetQueryFormFieldsByScriptNameResponse_QNAME, GetQueryFormFieldsByScriptNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryFormFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryFormFieldsResponse")
    public JAXBElement<GetQueryFormFieldsResponse> createGetQueryFormFieldsResponse(GetQueryFormFieldsResponse value) {
        return new JAXBElement<GetQueryFormFieldsResponse>(_GetQueryFormFieldsResponse_QNAME, GetQueryFormFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryList }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryList }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryList")
    public JAXBElement<GetQueryList> createGetQueryList(GetQueryList value) {
        return new JAXBElement<GetQueryList>(_GetQueryList_QNAME, GetQueryList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetQueryListResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetQueryListResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getQueryListResponse")
    public JAXBElement<GetQueryListResponse> createGetQueryListResponse(GetQueryListResponse value) {
        return new JAXBElement<GetQueryListResponse>(_GetQueryListResponse_QNAME, GetQueryListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRelatedFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRelatedFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRelatedFields")
    public JAXBElement<GetRelatedFields> createGetRelatedFields(GetRelatedFields value) {
        return new JAXBElement<GetRelatedFields>(_GetRelatedFields_QNAME, GetRelatedFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRelatedFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRelatedFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRelatedFieldsResponse")
    public JAXBElement<GetRelatedFieldsResponse> createGetRelatedFieldsResponse(GetRelatedFieldsResponse value) {
        return new JAXBElement<GetRelatedFieldsResponse>(_GetRelatedFieldsResponse_QNAME, GetRelatedFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryContent")
    public JAXBElement<GetRepositoryContent> createGetRepositoryContent(GetRepositoryContent value) {
        return new JAXBElement<GetRepositoryContent>(_GetRepositoryContent_QNAME, GetRepositoryContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentPage }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentPage }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryContentPage")
    public JAXBElement<GetRepositoryContentPage> createGetRepositoryContentPage(GetRepositoryContentPage value) {
        return new JAXBElement<GetRepositoryContentPage>(_GetRepositoryContentPage_QNAME, GetRepositoryContentPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentPageResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentPageResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryContentPageResponse")
    public JAXBElement<GetRepositoryContentPageResponse> createGetRepositoryContentPageResponse(GetRepositoryContentPageResponse value) {
        return new JAXBElement<GetRepositoryContentPageResponse>(_GetRepositoryContentPageResponse_QNAME, GetRepositoryContentPageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryContentResponse")
    public JAXBElement<GetRepositoryContentResponse> createGetRepositoryContentResponse(GetRepositoryContentResponse value) {
        return new JAXBElement<GetRepositoryContentResponse>(_GetRepositoryContentResponse_QNAME, GetRepositoryContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryFields")
    public JAXBElement<GetRepositoryFields> createGetRepositoryFields(GetRepositoryFields value) {
        return new JAXBElement<GetRepositoryFields>(_GetRepositoryFields_QNAME, GetRepositoryFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRepositoryFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRepositoryFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRepositoryFieldsResponse")
    public JAXBElement<GetRepositoryFieldsResponse> createGetRepositoryFieldsResponse(GetRepositoryFieldsResponse value) {
        return new JAXBElement<GetRepositoryFieldsResponse>(_GetRepositoryFieldsResponse_QNAME, GetRepositoryFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRoles }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRoles }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRoles")
    public JAXBElement<GetRoles> createGetRoles(GetRoles value) {
        return new JAXBElement<GetRoles>(_GetRoles_QNAME, GetRoles.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRolesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetRolesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getRolesResponse")
    public JAXBElement<GetRolesResponse> createGetRolesResponse(GetRolesResponse value) {
        return new JAXBElement<GetRolesResponse>(_GetRolesResponse_QNAME, GetRolesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTask }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTask }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTask")
    public JAXBElement<GetTask> createGetTask(GetTask value) {
        return new JAXBElement<GetTask>(_GetTask_QNAME, GetTask.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaskByName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTaskByName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTaskByName")
    public JAXBElement<GetTaskByName> createGetTaskByName(GetTaskByName value) {
        return new JAXBElement<GetTaskByName>(_GetTaskByName_QNAME, GetTaskByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaskByNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTaskByNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTaskByNameResponse")
    public JAXBElement<GetTaskByNameResponse> createGetTaskByNameResponse(GetTaskByNameResponse value) {
        return new JAXBElement<GetTaskByNameResponse>(_GetTaskByNameResponse_QNAME, GetTaskByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaskElements }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTaskElements }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTaskElements")
    public JAXBElement<GetTaskElements> createGetTaskElements(GetTaskElements value) {
        return new JAXBElement<GetTaskElements>(_GetTaskElements_QNAME, GetTaskElements.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaskElementsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTaskElementsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTaskElementsResponse")
    public JAXBElement<GetTaskElementsResponse> createGetTaskElementsResponse(GetTaskElementsResponse value) {
        return new JAXBElement<GetTaskElementsResponse>(_GetTaskElementsResponse_QNAME, GetTaskElementsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaskResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTaskResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTaskResponse")
    public JAXBElement<GetTaskResponse> createGetTaskResponse(GetTaskResponse value) {
        return new JAXBElement<GetTaskResponse>(_GetTaskResponse_QNAME, GetTaskResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTasks }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTasks }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTasks")
    public JAXBElement<GetTasks> createGetTasks(GetTasks value) {
        return new JAXBElement<GetTasks>(_GetTasks_QNAME, GetTasks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTasksResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTasksResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTasksResponse")
    public JAXBElement<GetTasksResponse> createGetTasksResponse(GetTasksResponse value) {
        return new JAXBElement<GetTasksResponse>(_GetTasksResponse_QNAME, GetTasksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTopics }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTopics }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTopics")
    public JAXBElement<GetTopics> createGetTopics(GetTopics value) {
        return new JAXBElement<GetTopics>(_GetTopics_QNAME, GetTopics.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTopicsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetTopicsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getTopicsResponse")
    public JAXBElement<GetTopicsResponse> createGetTopicsResponse(GetTopicsResponse value) {
        return new JAXBElement<GetTopicsResponse>(_GetTopicsResponse_QNAME, GetTopicsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUser }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUser }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUser")
    public JAXBElement<GetUser> createGetUser(GetUser value) {
        return new JAXBElement<GetUser>(_GetUser_QNAME, GetUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserAttributeFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUserAttributeFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUserAttributeFields")
    public JAXBElement<GetUserAttributeFields> createGetUserAttributeFields(GetUserAttributeFields value) {
        return new JAXBElement<GetUserAttributeFields>(_GetUserAttributeFields_QNAME, GetUserAttributeFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserAttributeFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUserAttributeFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUserAttributeFieldsResponse")
    public JAXBElement<GetUserAttributeFieldsResponse> createGetUserAttributeFieldsResponse(GetUserAttributeFieldsResponse value) {
        return new JAXBElement<GetUserAttributeFieldsResponse>(_GetUserAttributeFieldsResponse_QNAME, GetUserAttributeFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUserResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUserResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUserResponse")
    public JAXBElement<GetUserResponse> createGetUserResponse(GetUserResponse value) {
        return new JAXBElement<GetUserResponse>(_GetUserResponse_QNAME, GetUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUsers }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUsers }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUsers")
    public JAXBElement<GetUsers> createGetUsers(GetUsers value) {
        return new JAXBElement<GetUsers>(_GetUsers_QNAME, GetUsers.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUsersForRole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUsersForRole }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUsersForRole")
    public JAXBElement<GetUsersForRole> createGetUsersForRole(GetUsersForRole value) {
        return new JAXBElement<GetUsersForRole>(_GetUsersForRole_QNAME, GetUsersForRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUsersForRoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUsersForRoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUsersForRoleResponse")
    public JAXBElement<GetUsersForRoleResponse> createGetUsersForRoleResponse(GetUsersForRoleResponse value) {
        return new JAXBElement<GetUsersForRoleResponse>(_GetUsersForRoleResponse_QNAME, GetUsersForRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetUsersResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetUsersResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getUsersResponse")
    public JAXBElement<GetUsersResponse> createGetUsersResponse(GetUsersResponse value) {
        return new JAXBElement<GetUsersResponse>(_GetUsersResponse_QNAME, GetUsersResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetValues }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetValues }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getValues")
    public JAXBElement<GetValues> createGetValues(GetValues value) {
        return new JAXBElement<GetValues>(_GetValues_QNAME, GetValues.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetValuesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetValuesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getValuesResponse")
    public JAXBElement<GetValuesResponse> createGetValuesResponse(GetValuesResponse value) {
        return new JAXBElement<GetValuesResponse>(_GetValuesResponse_QNAME, GetValuesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVersions }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetVersions }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getVersions")
    public JAXBElement<GetVersions> createGetVersions(GetVersions value) {
        return new JAXBElement<GetVersions>(_GetVersions_QNAME, GetVersions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetVersionsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetVersionsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getVersionsResponse")
    public JAXBElement<GetVersionsResponse> createGetVersionsResponse(GetVersionsResponse value) {
        return new JAXBElement<GetVersionsResponse>(_GetVersionsResponse_QNAME, GetVersionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkFlowFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkFlowFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkFlowFields")
    public JAXBElement<GetWorkFlowFields> createGetWorkFlowFields(GetWorkFlowFields value) {
        return new JAXBElement<GetWorkFlowFields>(_GetWorkFlowFields_QNAME, GetWorkFlowFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkFlowFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkFlowFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkFlowFieldsResponse")
    public JAXBElement<GetWorkFlowFieldsResponse> createGetWorkFlowFieldsResponse(GetWorkFlowFieldsResponse value) {
        return new JAXBElement<GetWorkFlowFieldsResponse>(_GetWorkFlowFieldsResponse_QNAME, GetWorkFlowFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkFlowTemplates }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkFlowTemplates }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkFlowTemplates")
    public JAXBElement<GetWorkFlowTemplates> createGetWorkFlowTemplates(GetWorkFlowTemplates value) {
        return new JAXBElement<GetWorkFlowTemplates>(_GetWorkFlowTemplates_QNAME, GetWorkFlowTemplates.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkFlowTemplatesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkFlowTemplatesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkFlowTemplatesResponse")
    public JAXBElement<GetWorkFlowTemplatesResponse> createGetWorkFlowTemplatesResponse(GetWorkFlowTemplatesResponse value) {
        return new JAXBElement<GetWorkFlowTemplatesResponse>(_GetWorkFlowTemplatesResponse_QNAME, GetWorkFlowTemplatesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkItemEnvelope }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkItemEnvelope }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkItemEnvelope")
    public JAXBElement<GetWorkItemEnvelope> createGetWorkItemEnvelope(GetWorkItemEnvelope value) {
        return new JAXBElement<GetWorkItemEnvelope>(_GetWorkItemEnvelope_QNAME, GetWorkItemEnvelope.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkItemEnvelopeResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkItemEnvelopeResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkItemEnvelopeResponse")
    public JAXBElement<GetWorkItemEnvelopeResponse> createGetWorkItemEnvelopeResponse(GetWorkItemEnvelopeResponse value) {
        return new JAXBElement<GetWorkItemEnvelopeResponse>(_GetWorkItemEnvelopeResponse_QNAME, GetWorkItemEnvelopeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkItemFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkItemFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkItemFields")
    public JAXBElement<GetWorkItemFields> createGetWorkItemFields(GetWorkItemFields value) {
        return new JAXBElement<GetWorkItemFields>(_GetWorkItemFields_QNAME, GetWorkItemFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetWorkItemFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetWorkItemFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "getWorkItemFieldsResponse")
    public JAXBElement<GetWorkItemFieldsResponse> createGetWorkItemFieldsResponse(GetWorkItemFieldsResponse value) {
        return new JAXBElement<GetWorkItemFieldsResponse>(_GetWorkItemFieldsResponse_QNAME, GetWorkItemFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertImagePage }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link InsertImagePage }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "insertImagePage")
    public JAXBElement<InsertImagePage> createInsertImagePage(InsertImagePage value) {
        return new JAXBElement<InsertImagePage>(_InsertImagePage_QNAME, InsertImagePage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertImagePageResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link InsertImagePageResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "insertImagePageResponse")
    public JAXBElement<InsertImagePageResponse> createInsertImagePageResponse(InsertImagePageResponse value) {
        return new JAXBElement<InsertImagePageResponse>(_InsertImagePageResponse_QNAME, InsertImagePageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockFileStore")
    public JAXBElement<LockFileStore> createLockFileStore(LockFileStore value) {
        return new JAXBElement<LockFileStore>(_LockFileStore_QNAME, LockFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockFileStoreEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockFileStoreEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockFileStoreEx")
    public JAXBElement<LockFileStoreEx> createLockFileStoreEx(LockFileStoreEx value) {
        return new JAXBElement<LockFileStoreEx>(_LockFileStoreEx_QNAME, LockFileStoreEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockFileStoreExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockFileStoreExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockFileStoreExResponse")
    public JAXBElement<LockFileStoreExResponse> createLockFileStoreExResponse(LockFileStoreExResponse value) {
        return new JAXBElement<LockFileStoreExResponse>(_LockFileStoreExResponse_QNAME, LockFileStoreExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockFileStoreResponse")
    public JAXBElement<LockFileStoreResponse> createLockFileStoreResponse(LockFileStoreResponse value) {
        return new JAXBElement<LockFileStoreResponse>(_LockFileStoreResponse_QNAME, LockFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockRepositoryObject }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockRepositoryObject }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockRepositoryObject")
    public JAXBElement<LockRepositoryObject> createLockRepositoryObject(LockRepositoryObject value) {
        return new JAXBElement<LockRepositoryObject>(_LockRepositoryObject_QNAME, LockRepositoryObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockRepositoryObjectResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockRepositoryObjectResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockRepositoryObjectResponse")
    public JAXBElement<LockRepositoryObjectResponse> createLockRepositoryObjectResponse(LockRepositoryObjectResponse value) {
        return new JAXBElement<LockRepositoryObjectResponse>(_LockRepositoryObjectResponse_QNAME, LockRepositoryObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockWorkItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockWorkItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockWorkItem")
    public JAXBElement<LockWorkItem> createLockWorkItem(LockWorkItem value) {
        return new JAXBElement<LockWorkItem>(_LockWorkItem_QNAME, LockWorkItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LockWorkItemResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link LockWorkItemResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "lockWorkItemResponse")
    public JAXBElement<LockWorkItemResponse> createLockWorkItemResponse(LockWorkItemResponse value) {
        return new JAXBElement<LockWorkItemResponse>(_LockWorkItemResponse_QNAME, LockWorkItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoveImagePages }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link MoveImagePages }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "moveImagePages")
    public JAXBElement<MoveImagePages> createMoveImagePages(MoveImagePages value) {
        return new JAXBElement<MoveImagePages>(_MoveImagePages_QNAME, MoveImagePages.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MoveImagePagesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link MoveImagePagesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "moveImagePagesResponse")
    public JAXBElement<MoveImagePagesResponse> createMoveImagePagesResponse(MoveImagePagesResponse value) {
        return new JAXBElement<MoveImagePagesResponse>(_MoveImagePagesResponse_QNAME, MoveImagePagesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutBuddyInCapture }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutBuddyInCapture }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putBuddyInCapture")
    public JAXBElement<PutBuddyInCapture> createPutBuddyInCapture(PutBuddyInCapture value) {
        return new JAXBElement<PutBuddyInCapture>(_PutBuddyInCapture_QNAME, PutBuddyInCapture.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutBuddyInCaptureResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutBuddyInCaptureResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putBuddyInCaptureResponse")
    public JAXBElement<PutBuddyInCaptureResponse> createPutBuddyInCaptureResponse(PutBuddyInCaptureResponse value) {
        return new JAXBElement<PutBuddyInCaptureResponse>(_PutBuddyInCaptureResponse_QNAME, PutBuddyInCaptureResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFile }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFile }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFile")
    public JAXBElement<PutFile> createPutFile(PutFile value) {
        return new JAXBElement<PutFile>(_PutFile_QNAME, PutFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileBuddyInCapture }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileBuddyInCapture }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileBuddyInCapture")
    public JAXBElement<PutFileBuddyInCapture> createPutFileBuddyInCapture(PutFileBuddyInCapture value) {
        return new JAXBElement<PutFileBuddyInCapture>(_PutFileBuddyInCapture_QNAME, PutFileBuddyInCapture.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileBuddyInCaptureResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileBuddyInCaptureResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileBuddyInCaptureResponse")
    public JAXBElement<PutFileBuddyInCaptureResponse> createPutFileBuddyInCaptureResponse(PutFileBuddyInCaptureResponse value) {
        return new JAXBElement<PutFileBuddyInCaptureResponse>(_PutFileBuddyInCaptureResponse_QNAME, PutFileBuddyInCaptureResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileByName }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileByName }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileByName")
    public JAXBElement<PutFileByName> createPutFileByName(PutFileByName value) {
        return new JAXBElement<PutFileByName>(_PutFileByName_QNAME, PutFileByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileByNameResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileByNameResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileByNameResponse")
    public JAXBElement<PutFileByNameResponse> createPutFileByNameResponse(PutFileByNameResponse value) {
        return new JAXBElement<PutFileByNameResponse>(_PutFileByNameResponse_QNAME, PutFileByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileEx }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileEx }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileEx")
    public JAXBElement<PutFileEx> createPutFileEx(PutFileEx value) {
        return new JAXBElement<PutFileEx>(_PutFileEx_QNAME, PutFileEx.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileExResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileExResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileExResponse")
    public JAXBElement<PutFileExResponse> createPutFileExResponse(PutFileExResponse value) {
        return new JAXBElement<PutFileExResponse>(_PutFileExResponse_QNAME, PutFileExResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileInCapture }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileInCapture }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileInCapture")
    public JAXBElement<PutFileInCapture> createPutFileInCapture(PutFileInCapture value) {
        return new JAXBElement<PutFileInCapture>(_PutFileInCapture_QNAME, PutFileInCapture.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileInCaptureResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileInCaptureResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileInCaptureResponse")
    public JAXBElement<PutFileInCaptureResponse> createPutFileInCaptureResponse(PutFileInCaptureResponse value) {
        return new JAXBElement<PutFileInCaptureResponse>(_PutFileInCaptureResponse_QNAME, PutFileInCaptureResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutFileResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutFileResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putFileResponse")
    public JAXBElement<PutFileResponse> createPutFileResponse(PutFileResponse value) {
        return new JAXBElement<PutFileResponse>(_PutFileResponse_QNAME, PutFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutImageMarks }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutImageMarks }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putImageMarks")
    public JAXBElement<PutImageMarks> createPutImageMarks(PutImageMarks value) {
        return new JAXBElement<PutImageMarks>(_PutImageMarks_QNAME, PutImageMarks.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutImageMarksResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutImageMarksResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putImageMarksResponse")
    public JAXBElement<PutImageMarksResponse> createPutImageMarksResponse(PutImageMarksResponse value) {
        return new JAXBElement<PutImageMarksResponse>(_PutImageMarksResponse_QNAME, PutImageMarksResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutImageThumbnail }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutImageThumbnail }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putImageThumbnail")
    public JAXBElement<PutImageThumbnail> createPutImageThumbnail(PutImageThumbnail value) {
        return new JAXBElement<PutImageThumbnail>(_PutImageThumbnail_QNAME, PutImageThumbnail.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutImageThumbnailResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutImageThumbnailResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putImageThumbnailResponse")
    public JAXBElement<PutImageThumbnailResponse> createPutImageThumbnailResponse(PutImageThumbnailResponse value) {
        return new JAXBElement<PutImageThumbnailResponse>(_PutImageThumbnailResponse_QNAME, PutImageThumbnailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutRepositoryContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutRepositoryContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putRepositoryContent")
    public JAXBElement<PutRepositoryContent> createPutRepositoryContent(PutRepositoryContent value) {
        return new JAXBElement<PutRepositoryContent>(_PutRepositoryContent_QNAME, PutRepositoryContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PutRepositoryContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link PutRepositoryContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "putRepositoryContentResponse")
    public JAXBElement<PutRepositoryContentResponse> createPutRepositoryContentResponse(PutRepositoryContentResponse value) {
        return new JAXBElement<PutRepositoryContentResponse>(_PutRepositoryContentResponse_QNAME, PutRepositoryContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReleaseWorkItemFromError }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReleaseWorkItemFromError }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "releaseWorkItemFromError")
    public JAXBElement<ReleaseWorkItemFromError> createReleaseWorkItemFromError(ReleaseWorkItemFromError value) {
        return new JAXBElement<ReleaseWorkItemFromError>(_ReleaseWorkItemFromError_QNAME, ReleaseWorkItemFromError.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReleaseWorkItemFromErrorResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReleaseWorkItemFromErrorResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "releaseWorkItemFromErrorResponse")
    public JAXBElement<ReleaseWorkItemFromErrorResponse> createReleaseWorkItemFromErrorResponse(ReleaseWorkItemFromErrorResponse value) {
        return new JAXBElement<ReleaseWorkItemFromErrorResponse>(_ReleaseWorkItemFromErrorResponse_QNAME, ReleaseWorkItemFromErrorResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveACL }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveACL }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeACL")
    public JAXBElement<RemoveACL> createRemoveACL(RemoveACL value) {
        return new JAXBElement<RemoveACL>(_RemoveACL_QNAME, RemoveACL.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveACLByRole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveACLByRole }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeACLByRole")
    public JAXBElement<RemoveACLByRole> createRemoveACLByRole(RemoveACLByRole value) {
        return new JAXBElement<RemoveACLByRole>(_RemoveACLByRole_QNAME, RemoveACLByRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveACLByRoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveACLByRoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeACLByRoleResponse")
    public JAXBElement<RemoveACLByRoleResponse> createRemoveACLByRoleResponse(RemoveACLByRoleResponse value) {
        return new JAXBElement<RemoveACLByRoleResponse>(_RemoveACLByRoleResponse_QNAME, RemoveACLByRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveACLResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveACLResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeACLResponse")
    public JAXBElement<RemoveACLResponse> createRemoveACLResponse(RemoveACLResponse value) {
        return new JAXBElement<RemoveACLResponse>(_RemoveACLResponse_QNAME, RemoveACLResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveCaseFolder }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveCaseFolder }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeCaseFolder")
    public JAXBElement<RemoveCaseFolder> createRemoveCaseFolder(RemoveCaseFolder value) {
        return new JAXBElement<RemoveCaseFolder>(_RemoveCaseFolder_QNAME, RemoveCaseFolder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveCaseFolderResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveCaseFolderResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeCaseFolderResponse")
    public JAXBElement<RemoveCaseFolderResponse> createRemoveCaseFolderResponse(RemoveCaseFolderResponse value) {
        return new JAXBElement<RemoveCaseFolderResponse>(_RemoveCaseFolderResponse_QNAME, RemoveCaseFolderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeContent")
    public JAXBElement<RemoveContent> createRemoveContent(RemoveContent value) {
        return new JAXBElement<RemoveContent>(_RemoveContent_QNAME, RemoveContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeContentResponse")
    public JAXBElement<RemoveContentResponse> createRemoveContentResponse(RemoveContentResponse value) {
        return new JAXBElement<RemoveContentResponse>(_RemoveContentResponse_QNAME, RemoveContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveDiscussion }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveDiscussion }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeDiscussion")
    public JAXBElement<RemoveDiscussion> createRemoveDiscussion(RemoveDiscussion value) {
        return new JAXBElement<RemoveDiscussion>(_RemoveDiscussion_QNAME, RemoveDiscussion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveDiscussionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveDiscussionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeDiscussionResponse")
    public JAXBElement<RemoveDiscussionResponse> createRemoveDiscussionResponse(RemoveDiscussionResponse value) {
        return new JAXBElement<RemoveDiscussionResponse>(_RemoveDiscussionResponse_QNAME, RemoveDiscussionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeFileStore")
    public JAXBElement<RemoveFileStore> createRemoveFileStore(RemoveFileStore value) {
        return new JAXBElement<RemoveFileStore>(_RemoveFileStore_QNAME, RemoveFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeFileStoreResponse")
    public JAXBElement<RemoveFileStoreResponse> createRemoveFileStoreResponse(RemoveFileStoreResponse value) {
        return new JAXBElement<RemoveFileStoreResponse>(_RemoveFileStoreResponse_QNAME, RemoveFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFormDataFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveFormDataFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeFormDataFields")
    public JAXBElement<RemoveFormDataFields> createRemoveFormDataFields(RemoveFormDataFields value) {
        return new JAXBElement<RemoveFormDataFields>(_RemoveFormDataFields_QNAME, RemoveFormDataFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFormDataFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveFormDataFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeFormDataFieldsResponse")
    public JAXBElement<RemoveFormDataFieldsResponse> createRemoveFormDataFieldsResponse(RemoveFormDataFieldsResponse value) {
        return new JAXBElement<RemoveFormDataFieldsResponse>(_RemoveFormDataFieldsResponse_QNAME, RemoveFormDataFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveRelatedFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveRelatedFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeRelatedFields")
    public JAXBElement<RemoveRelatedFields> createRemoveRelatedFields(RemoveRelatedFields value) {
        return new JAXBElement<RemoveRelatedFields>(_RemoveRelatedFields_QNAME, RemoveRelatedFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveRelatedFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveRelatedFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeRelatedFieldsResponse")
    public JAXBElement<RemoveRelatedFieldsResponse> createRemoveRelatedFieldsResponse(RemoveRelatedFieldsResponse value) {
        return new JAXBElement<RemoveRelatedFieldsResponse>(_RemoveRelatedFieldsResponse_QNAME, RemoveRelatedFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveRole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveRole }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeRole")
    public JAXBElement<RemoveRole> createRemoveRole(RemoveRole value) {
        return new JAXBElement<RemoveRole>(_RemoveRole_QNAME, RemoveRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveRoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveRoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeRoleResponse")
    public JAXBElement<RemoveRoleResponse> createRemoveRoleResponse(RemoveRoleResponse value) {
        return new JAXBElement<RemoveRoleResponse>(_RemoveRoleResponse_QNAME, RemoveRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveTask }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveTask }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeTask")
    public JAXBElement<RemoveTask> createRemoveTask(RemoveTask value) {
        return new JAXBElement<RemoveTask>(_RemoveTask_QNAME, RemoveTask.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveTaskResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveTaskResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeTaskResponse")
    public JAXBElement<RemoveTaskResponse> createRemoveTaskResponse(RemoveTaskResponse value) {
        return new JAXBElement<RemoveTaskResponse>(_RemoveTaskResponse_QNAME, RemoveTaskResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveUser }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveUser }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeUser")
    public JAXBElement<RemoveUser> createRemoveUser(RemoveUser value) {
        return new JAXBElement<RemoveUser>(_RemoveUser_QNAME, RemoveUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveUserResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveUserResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeUserResponse")
    public JAXBElement<RemoveUserResponse> createRemoveUserResponse(RemoveUserResponse value) {
        return new JAXBElement<RemoveUserResponse>(_RemoveUserResponse_QNAME, RemoveUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveVersion }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveVersion }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeVersion")
    public JAXBElement<RemoveVersion> createRemoveVersion(RemoveVersion value) {
        return new JAXBElement<RemoveVersion>(_RemoveVersion_QNAME, RemoveVersion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveVersionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveVersionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeVersionResponse")
    public JAXBElement<RemoveVersionResponse> createRemoveVersionResponse(RemoveVersionResponse value) {
        return new JAXBElement<RemoveVersionResponse>(_RemoveVersionResponse_QNAME, RemoveVersionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveWorkItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveWorkItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeWorkItem")
    public JAXBElement<RemoveWorkItem> createRemoveWorkItem(RemoveWorkItem value) {
        return new JAXBElement<RemoveWorkItem>(_RemoveWorkItem_QNAME, RemoveWorkItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveWorkItemResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveWorkItemResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "removeWorkItemResponse")
    public JAXBElement<RemoveWorkItemResponse> createRemoveWorkItemResponse(RemoveWorkItemResponse value) {
        return new JAXBElement<RemoveWorkItemResponse>(_RemoveWorkItemResponse_QNAME, RemoveWorkItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReplaceImagePage }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReplaceImagePage }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "replaceImagePage")
    public JAXBElement<ReplaceImagePage> createReplaceImagePage(ReplaceImagePage value) {
        return new JAXBElement<ReplaceImagePage>(_ReplaceImagePage_QNAME, ReplaceImagePage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReplaceImagePageResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReplaceImagePageResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "replaceImagePageResponse")
    public JAXBElement<ReplaceImagePageResponse> createReplaceImagePageResponse(ReplaceImagePageResponse value) {
        return new JAXBElement<ReplaceImagePageResponse>(_ReplaceImagePageResponse_QNAME, ReplaceImagePageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteRepositoryObject }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteRepositoryObject }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "routeRepositoryObject")
    public JAXBElement<RouteRepositoryObject> createRouteRepositoryObject(RouteRepositoryObject value) {
        return new JAXBElement<RouteRepositoryObject>(_RouteRepositoryObject_QNAME, RouteRepositoryObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteRepositoryObjectResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteRepositoryObjectResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "routeRepositoryObjectResponse")
    public JAXBElement<RouteRepositoryObjectResponse> createRouteRepositoryObjectResponse(RouteRepositoryObjectResponse value) {
        return new JAXBElement<RouteRepositoryObjectResponse>(_RouteRepositoryObjectResponse_QNAME, RouteRepositoryObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteWorkItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteWorkItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "routeWorkItem")
    public JAXBElement<RouteWorkItem> createRouteWorkItem(RouteWorkItem value) {
        return new JAXBElement<RouteWorkItem>(_RouteWorkItem_QNAME, RouteWorkItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RouteWorkItemResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RouteWorkItemResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "routeWorkItemResponse")
    public JAXBElement<RouteWorkItemResponse> createRouteWorkItemResponse(RouteWorkItemResponse value) {
        return new JAXBElement<RouteWorkItemResponse>(_RouteWorkItemResponse_QNAME, RouteWorkItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpCreate }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpCreate }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpCreate")
    public JAXBElement<RpCreate> createRpCreate(RpCreate value) {
        return new JAXBElement<RpCreate>(_RpCreate_QNAME, RpCreate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpCreateContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpCreateContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpCreateContent")
    public JAXBElement<RpCreateContent> createRpCreateContent(RpCreateContent value) {
        return new JAXBElement<RpCreateContent>(_RpCreateContent_QNAME, RpCreateContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpCreateContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpCreateContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpCreateContentResponse")
    public JAXBElement<RpCreateContentResponse> createRpCreateContentResponse(RpCreateContentResponse value) {
        return new JAXBElement<RpCreateContentResponse>(_RpCreateContentResponse_QNAME, RpCreateContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpCreateResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpCreateResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpCreateResponse")
    public JAXBElement<RpCreateResponse> createRpCreateResponse(RpCreateResponse value) {
        return new JAXBElement<RpCreateResponse>(_RpCreateResponse_QNAME, RpCreateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDelete }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDelete }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDelete")
    public JAXBElement<RpDelete> createRpDelete(RpDelete value) {
        return new JAXBElement<RpDelete>(_RpDelete_QNAME, RpDelete.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDeleteResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDeleteResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDeleteResponse")
    public JAXBElement<RpDeleteResponse> createRpDeleteResponse(RpDeleteResponse value) {
        return new JAXBElement<RpDeleteResponse>(_RpDeleteResponse_QNAME, RpDeleteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoAction }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoAction }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoAction")
    public JAXBElement<RpDoAction> createRpDoAction(RpDoAction value) {
        return new JAXBElement<RpDoAction>(_RpDoAction_QNAME, RpDoAction.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoActionGetData }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoActionGetData }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoActionGetData")
    public JAXBElement<RpDoActionGetData> createRpDoActionGetData(RpDoActionGetData value) {
        return new JAXBElement<RpDoActionGetData>(_RpDoActionGetData_QNAME, RpDoActionGetData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoActionGetDataResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoActionGetDataResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoActionGetDataResponse")
    public JAXBElement<RpDoActionGetDataResponse> createRpDoActionGetDataResponse(RpDoActionGetDataResponse value) {
        return new JAXBElement<RpDoActionGetDataResponse>(_RpDoActionGetDataResponse_QNAME, RpDoActionGetDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoActionPostData }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoActionPostData }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoActionPostData")
    public JAXBElement<RpDoActionPostData> createRpDoActionPostData(RpDoActionPostData value) {
        return new JAXBElement<RpDoActionPostData>(_RpDoActionPostData_QNAME, RpDoActionPostData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoActionPostDataResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoActionPostDataResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoActionPostDataResponse")
    public JAXBElement<RpDoActionPostDataResponse> createRpDoActionPostDataResponse(RpDoActionPostDataResponse value) {
        return new JAXBElement<RpDoActionPostDataResponse>(_RpDoActionPostDataResponse_QNAME, RpDoActionPostDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpDoActionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpDoActionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpDoActionResponse")
    public JAXBElement<RpDoActionResponse> createRpDoActionResponse(RpDoActionResponse value) {
        return new JAXBElement<RpDoActionResponse>(_RpDoActionResponse_QNAME, RpDoActionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpGet }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpGet }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpGet")
    public JAXBElement<RpGet> createRpGet(RpGet value) {
        return new JAXBElement<RpGet>(_RpGet_QNAME, RpGet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpGetContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpGetContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpGetContent")
    public JAXBElement<RpGetContent> createRpGetContent(RpGetContent value) {
        return new JAXBElement<RpGetContent>(_RpGetContent_QNAME, RpGetContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpGetContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpGetContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpGetContentResponse")
    public JAXBElement<RpGetContentResponse> createRpGetContentResponse(RpGetContentResponse value) {
        return new JAXBElement<RpGetContentResponse>(_RpGetContentResponse_QNAME, RpGetContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpGetResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpGetResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpGetResponse")
    public JAXBElement<RpGetResponse> createRpGetResponse(RpGetResponse value) {
        return new JAXBElement<RpGetResponse>(_RpGetResponse_QNAME, RpGetResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpSet }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpSet }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpSet")
    public JAXBElement<RpSet> createRpSet(RpSet value) {
        return new JAXBElement<RpSet>(_RpSet_QNAME, RpSet.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpSetContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpSetContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpSetContent")
    public JAXBElement<RpSetContent> createRpSetContent(RpSetContent value) {
        return new JAXBElement<RpSetContent>(_RpSetContent_QNAME, RpSetContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpSetContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpSetContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpSetContentResponse")
    public JAXBElement<RpSetContentResponse> createRpSetContentResponse(RpSetContentResponse value) {
        return new JAXBElement<RpSetContentResponse>(_RpSetContentResponse_QNAME, RpSetContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RpSetResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RpSetResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "rpSetResponse")
    public JAXBElement<RpSetResponse> createRpSetResponse(RpSetResponse value) {
        return new JAXBElement<RpSetResponse>(_RpSetResponse_QNAME, RpSetResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendWorkItemToWorkstep }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendWorkItemToWorkstep }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "sendWorkItemToWorkstep")
    public JAXBElement<SendWorkItemToWorkstep> createSendWorkItemToWorkstep(SendWorkItemToWorkstep value) {
        return new JAXBElement<SendWorkItemToWorkstep>(_SendWorkItemToWorkstep_QNAME, SendWorkItemToWorkstep.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendWorkItemToWorkstepResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SendWorkItemToWorkstepResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "sendWorkItemToWorkstepResponse")
    public JAXBElement<SendWorkItemToWorkstepResponse> createSendWorkItemToWorkstepResponse(SendWorkItemToWorkstepResponse value) {
        return new JAXBElement<SendWorkItemToWorkstepResponse>(_SendWorkItemToWorkstepResponse_QNAME, SendWorkItemToWorkstepResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetACLforRole }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetACLforRole }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setACLforRole")
    public JAXBElement<SetACLforRole> createSetACLforRole(SetACLforRole value) {
        return new JAXBElement<SetACLforRole>(_SetACLforRole_QNAME, SetACLforRole.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetACLforRoleConditions }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetACLforRoleConditions }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setACLforRoleConditions")
    public JAXBElement<SetACLforRoleConditions> createSetACLforRoleConditions(SetACLforRoleConditions value) {
        return new JAXBElement<SetACLforRoleConditions>(_SetACLforRoleConditions_QNAME, SetACLforRoleConditions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetACLforRoleConditionsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetACLforRoleConditionsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setACLforRoleConditionsResponse")
    public JAXBElement<SetACLforRoleConditionsResponse> createSetACLforRoleConditionsResponse(SetACLforRoleConditionsResponse value) {
        return new JAXBElement<SetACLforRoleConditionsResponse>(_SetACLforRoleConditionsResponse_QNAME, SetACLforRoleConditionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetACLforRoleResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetACLforRoleResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setACLforRoleResponse")
    public JAXBElement<SetACLforRoleResponse> createSetACLforRoleResponse(SetACLforRoleResponse value) {
        return new JAXBElement<SetACLforRoleResponse>(_SetACLforRoleResponse_QNAME, SetACLforRoleResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolder }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolder }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolder")
    public JAXBElement<SetCaseFolder> createSetCaseFolder(SetCaseFolder value) {
        return new JAXBElement<SetCaseFolder>(_SetCaseFolder_QNAME, SetCaseFolder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderField }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderField }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderField")
    public JAXBElement<SetCaseFolderField> createSetCaseFolderField(SetCaseFolderField value) {
        return new JAXBElement<SetCaseFolderField>(_SetCaseFolderField_QNAME, SetCaseFolderField.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFieldResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFieldResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderFieldResponse")
    public JAXBElement<SetCaseFolderFieldResponse> createSetCaseFolderFieldResponse(SetCaseFolderFieldResponse value) {
        return new JAXBElement<SetCaseFolderFieldResponse>(_SetCaseFolderFieldResponse_QNAME, SetCaseFolderFieldResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderFields")
    public JAXBElement<SetCaseFolderFields> createSetCaseFolderFields(SetCaseFolderFields value) {
        return new JAXBElement<SetCaseFolderFields>(_SetCaseFolderFields_QNAME, SetCaseFolderFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderFieldsResponse")
    public JAXBElement<SetCaseFolderFieldsResponse> createSetCaseFolderFieldsResponse(SetCaseFolderFieldsResponse value) {
        return new JAXBElement<SetCaseFolderFieldsResponse>(_SetCaseFolderFieldsResponse_QNAME, SetCaseFolderFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderProperty }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderProperty }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderProperty")
    public JAXBElement<SetCaseFolderProperty> createSetCaseFolderProperty(SetCaseFolderProperty value) {
        return new JAXBElement<SetCaseFolderProperty>(_SetCaseFolderProperty_QNAME, SetCaseFolderProperty.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderPropertyResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderPropertyResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderPropertyResponse")
    public JAXBElement<SetCaseFolderPropertyResponse> createSetCaseFolderPropertyResponse(SetCaseFolderPropertyResponse value) {
        return new JAXBElement<SetCaseFolderPropertyResponse>(_SetCaseFolderPropertyResponse_QNAME, SetCaseFolderPropertyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderReadHistory }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderReadHistory }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderReadHistory")
    public JAXBElement<SetCaseFolderReadHistory> createSetCaseFolderReadHistory(SetCaseFolderReadHistory value) {
        return new JAXBElement<SetCaseFolderReadHistory>(_SetCaseFolderReadHistory_QNAME, SetCaseFolderReadHistory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderReadHistoryResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderReadHistoryResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderReadHistoryResponse")
    public JAXBElement<SetCaseFolderReadHistoryResponse> createSetCaseFolderReadHistoryResponse(SetCaseFolderReadHistoryResponse value) {
        return new JAXBElement<SetCaseFolderReadHistoryResponse>(_SetCaseFolderReadHistoryResponse_QNAME, SetCaseFolderReadHistoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetCaseFolderResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetCaseFolderResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setCaseFolderResponse")
    public JAXBElement<SetCaseFolderResponse> createSetCaseFolderResponse(SetCaseFolderResponse value) {
        return new JAXBElement<SetCaseFolderResponse>(_SetCaseFolderResponse_QNAME, SetCaseFolderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetContent }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetContent }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setContent")
    public JAXBElement<SetContent> createSetContent(SetContent value) {
        return new JAXBElement<SetContent>(_SetContent_QNAME, SetContent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetContentResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetContentResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setContentResponse")
    public JAXBElement<SetContentResponse> createSetContentResponse(SetContentResponse value) {
        return new JAXBElement<SetContentResponse>(_SetContentResponse_QNAME, SetContentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDiscussion }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetDiscussion }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setDiscussion")
    public JAXBElement<SetDiscussion> createSetDiscussion(SetDiscussion value) {
        return new JAXBElement<SetDiscussion>(_SetDiscussion_QNAME, SetDiscussion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDiscussionResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetDiscussionResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setDiscussionResponse")
    public JAXBElement<SetDiscussionResponse> createSetDiscussionResponse(SetDiscussionResponse value) {
        return new JAXBElement<SetDiscussionResponse>(_SetDiscussionResponse_QNAME, SetDiscussionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStore")
    public JAXBElement<SetFileStore> createSetFileStore(SetFileStore value) {
        return new JAXBElement<SetFileStore>(_SetFileStore_QNAME, SetFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStoreFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStoreFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStoreFields")
    public JAXBElement<SetFileStoreFields> createSetFileStoreFields(SetFileStoreFields value) {
        return new JAXBElement<SetFileStoreFields>(_SetFileStoreFields_QNAME, SetFileStoreFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStoreResponse")
    public JAXBElement<SetFileStoreResponse> createSetFileStoreResponse(SetFileStoreResponse value) {
        return new JAXBElement<SetFileStoreResponse>(_SetFileStoreResponse_QNAME, SetFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetUserAttributeFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetUserAttributeFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setUserAttributeFieldsResponse")
    public JAXBElement<SetUserAttributeFieldsResponse> createSetUserAttributeFieldsResponse(SetUserAttributeFieldsResponse value) {
        return new JAXBElement<SetUserAttributeFieldsResponse>(_SetUserAttributeFieldsResponse_QNAME, SetUserAttributeFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent1 }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent1 }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent1")
    public JAXBElement<UserWsEvent1> createUserWsEvent1(UserWsEvent1 value) {
        return new JAXBElement<UserWsEvent1>(_UserWsEvent1_QNAME, UserWsEvent1 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveException }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RemoveException }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "RemoveException")
    public JAXBElement<RemoveException> createRemoveException(RemoveException value) {
        return new JAXBElement<RemoveException>(_RemoveException_QNAME, RemoveException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStoreFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStoreFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStoreFieldsResponse")
    public JAXBElement<SetFileStoreFieldsResponse> createSetFileStoreFieldsResponse(SetFileStoreFieldsResponse value) {
        return new JAXBElement<SetFileStoreFieldsResponse>(_SetFileStoreFieldsResponse_QNAME, SetFileStoreFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStoreReadHistory }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStoreReadHistory }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStoreReadHistory")
    public JAXBElement<SetFileStoreReadHistory> createSetFileStoreReadHistory(SetFileStoreReadHistory value) {
        return new JAXBElement<SetFileStoreReadHistory>(_SetFileStoreReadHistory_QNAME, SetFileStoreReadHistory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileStoreReadHistoryResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFileStoreReadHistoryResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFileStoreReadHistoryResponse")
    public JAXBElement<SetFileStoreReadHistoryResponse> createSetFileStoreReadHistoryResponse(SetFileStoreReadHistoryResponse value) {
        return new JAXBElement<SetFileStoreReadHistoryResponse>(_SetFileStoreReadHistoryResponse_QNAME, SetFileStoreReadHistoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFormDataFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFormDataFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFormDataFields")
    public JAXBElement<SetFormDataFields> createSetFormDataFields(SetFormDataFields value) {
        return new JAXBElement<SetFormDataFields>(_SetFormDataFields_QNAME, SetFormDataFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFormDataFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetFormDataFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setFormDataFieldsResponse")
    public JAXBElement<SetFormDataFieldsResponse> createSetFormDataFieldsResponse(SetFormDataFieldsResponse value) {
        return new JAXBElement<SetFormDataFieldsResponse>(_SetFormDataFieldsResponse_QNAME, SetFormDataFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetImageOrientation }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetImageOrientation }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setImageOrientation")
    public JAXBElement<SetImageOrientation> createSetImageOrientation(SetImageOrientation value) {
        return new JAXBElement<SetImageOrientation>(_SetImageOrientation_QNAME, SetImageOrientation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetImageOrientationResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetImageOrientationResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setImageOrientationResponse")
    public JAXBElement<SetImageOrientationResponse> createSetImageOrientationResponse(SetImageOrientationResponse value) {
        return new JAXBElement<SetImageOrientationResponse>(_SetImageOrientationResponse_QNAME, SetImageOrientationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRelatedFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRelatedFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRelatedFields")
    public JAXBElement<SetRelatedFields> createSetRelatedFields(SetRelatedFields value) {
        return new JAXBElement<SetRelatedFields>(_SetRelatedFields_QNAME, SetRelatedFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRelatedFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRelatedFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRelatedFieldsResponse")
    public JAXBElement<SetRelatedFieldsResponse> createSetRelatedFieldsResponse(SetRelatedFieldsResponse value) {
        return new JAXBElement<SetRelatedFieldsResponse>(_SetRelatedFieldsResponse_QNAME, SetRelatedFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRepositoryFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRepositoryFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRepositoryFields")
    public JAXBElement<SetRepositoryFields> createSetRepositoryFields(SetRepositoryFields value) {
        return new JAXBElement<SetRepositoryFields>(_SetRepositoryFields_QNAME, SetRepositoryFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRepositoryFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRepositoryFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRepositoryFieldsResponse")
    public JAXBElement<SetRepositoryFieldsResponse> createSetRepositoryFieldsResponse(SetRepositoryFieldsResponse value) {
        return new JAXBElement<SetRepositoryFieldsResponse>(_SetRepositoryFieldsResponse_QNAME, SetRepositoryFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRoles }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRoles }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRoles")
    public JAXBElement<SetRoles> createSetRoles(SetRoles value) {
        return new JAXBElement<SetRoles>(_SetRoles_QNAME, SetRoles.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetRolesResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetRolesResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setRolesResponse")
    public JAXBElement<SetRolesResponse> createSetRolesResponse(SetRolesResponse value) {
        return new JAXBElement<SetRolesResponse>(_SetRolesResponse_QNAME, SetRolesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetTask }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetTask }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setTask")
    public JAXBElement<SetTask> createSetTask(SetTask value) {
        return new JAXBElement<SetTask>(_SetTask_QNAME, SetTask.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetTaskResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetTaskResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setTaskResponse")
    public JAXBElement<SetTaskResponse> createSetTaskResponse(SetTaskResponse value) {
        return new JAXBElement<SetTaskResponse>(_SetTaskResponse_QNAME, SetTaskResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetUser }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetUser }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setUser")
    public JAXBElement<SetUser> createSetUser(SetUser value) {
        return new JAXBElement<SetUser>(_SetUser_QNAME, SetUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetUserAttributeFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetUserAttributeFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setUserAttributeFields")
    public JAXBElement<SetUserAttributeFields> createSetUserAttributeFields(SetUserAttributeFields value) {
        return new JAXBElement<SetUserAttributeFields>(_SetUserAttributeFields_QNAME, SetUserAttributeFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetUserResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetUserResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setUserResponse")
    public JAXBElement<SetUserResponse> createSetUserResponse(SetUserResponse value) {
        return new JAXBElement<SetUserResponse>(_SetUserResponse_QNAME, SetUserResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetWorkItemFields }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetWorkItemFields }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setWorkItemFields")
    public JAXBElement<SetWorkItemFields> createSetWorkItemFields(SetWorkItemFields value) {
        return new JAXBElement<SetWorkItemFields>(_SetWorkItemFields_QNAME, SetWorkItemFields.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetWorkItemFieldsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link SetWorkItemFieldsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "setWorkItemFieldsResponse")
    public JAXBElement<SetWorkItemFieldsResponse> createSetWorkItemFieldsResponse(SetWorkItemFieldsResponse value) {
        return new JAXBElement<SetWorkItemFieldsResponse>(_SetWorkItemFieldsResponse_QNAME, SetWorkItemFieldsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnLockFileStore }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnLockFileStore }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unLockFileStore")
    public JAXBElement<UnLockFileStore> createUnLockFileStore(UnLockFileStore value) {
        return new JAXBElement<UnLockFileStore>(_UnLockFileStore_QNAME, UnLockFileStore.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnLockFileStoreResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnLockFileStoreResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unLockFileStoreResponse")
    public JAXBElement<UnLockFileStoreResponse> createUnLockFileStoreResponse(UnLockFileStoreResponse value) {
        return new JAXBElement<UnLockFileStoreResponse>(_UnLockFileStoreResponse_QNAME, UnLockFileStoreResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnLockWorkItem }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnLockWorkItem }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unLockWorkItem")
    public JAXBElement<UnLockWorkItem> createUnLockWorkItem(UnLockWorkItem value) {
        return new JAXBElement<UnLockWorkItem>(_UnLockWorkItem_QNAME, UnLockWorkItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnLockWorkItemResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnLockWorkItemResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unLockWorkItemResponse")
    public JAXBElement<UnLockWorkItemResponse> createUnLockWorkItemResponse(UnLockWorkItemResponse value) {
        return new JAXBElement<UnLockWorkItemResponse>(_UnLockWorkItemResponse_QNAME, UnLockWorkItemResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlockRepositoryObject }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnlockRepositoryObject }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unlockRepositoryObject")
    public JAXBElement<UnlockRepositoryObject> createUnlockRepositoryObject(UnlockRepositoryObject value) {
        return new JAXBElement<UnlockRepositoryObject>(_UnlockRepositoryObject_QNAME, UnlockRepositoryObject.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UnlockRepositoryObjectResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UnlockRepositoryObjectResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "unlockRepositoryObjectResponse")
    public JAXBElement<UnlockRepositoryObjectResponse> createUnlockRepositoryObjectResponse(UnlockRepositoryObjectResponse value) {
        return new JAXBElement<UnlockRepositoryObjectResponse>(_UnlockRepositoryObjectResponse_QNAME, UnlockRepositoryObjectResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent1Response }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent1Response }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent1Response")
    public JAXBElement<UserWsEvent1Response> createUserWsEvent1Response(UserWsEvent1Response value) {
        return new JAXBElement<UserWsEvent1Response>(_UserWsEvent1Response_QNAME, UserWsEvent1Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent2 }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent2 }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent2")
    public JAXBElement<UserWsEvent2> createUserWsEvent2(UserWsEvent2 value) {
        return new JAXBElement<UserWsEvent2>(_UserWsEvent2_QNAME, UserWsEvent2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent2Response }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent2Response }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent2Response")
    public JAXBElement<UserWsEvent2Response> createUserWsEvent2Response(UserWsEvent2Response value) {
        return new JAXBElement<UserWsEvent2Response>(_UserWsEvent2Response_QNAME, UserWsEvent2Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent3 }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent3 }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent3")
    public JAXBElement<UserWsEvent3> createUserWsEvent3(UserWsEvent3 value) {
        return new JAXBElement<UserWsEvent3>(_UserWsEvent3_QNAME, UserWsEvent3 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserWsEvent3Response }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UserWsEvent3Response }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "userWsEvent3Response")
    public JAXBElement<UserWsEvent3Response> createUserWsEvent3Response(UserWsEvent3Response value) {
        return new JAXBElement<UserWsEvent3Response>(_UserWsEvent3Response_QNAME, UserWsEvent3Response.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateException }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CreateException }{@code >}
     */
    @XmlElementDecl(namespace = "http://com.eistream.sonora.webservices/types", name = "CreateException")
    public JAXBElement<CreateException> createCreateException(CreateException value) {
        return new JAXBElement<CreateException>(_CreateException_QNAME, CreateException.class, null, value);
    }

}
