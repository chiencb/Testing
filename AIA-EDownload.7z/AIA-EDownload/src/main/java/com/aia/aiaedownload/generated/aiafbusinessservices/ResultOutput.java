
package com.aia.aiaedownload.generated.aiafbusinessservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for resultOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="resultOutput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="policy_num" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DOCUMENTID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DG_DOC_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DOC_TYPE_CODE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DOC_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DATE_RECEIVED" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resultOutput", propOrder = {
    "policyNum",
    "documentid",
    "dgdocname",
    "doctypecode",
    "doctype",
    "datereceived"
})
public class ResultOutput {

    @XmlElement(name = "policy_num", required = true, nillable = true)
    protected String policyNum;
    @XmlElement(name = "DOCUMENTID", required = true, nillable = true)
    protected String documentid;
    @XmlElement(name = "DG_DOC_NAME", required = true, nillable = true)
    protected String dgdocname;
    @XmlElement(name = "DOC_TYPE_CODE", required = true, nillable = true)
    protected String doctypecode;
    @XmlElement(name = "DOC_TYPE", required = true, nillable = true)
    protected String doctype;
    @XmlElement(name = "DATE_RECEIVED", required = true, nillable = true)
    protected String datereceived;

    /**
     * Gets the value of the policyNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyNum() {
        return policyNum;
    }

    /**
     * Sets the value of the policyNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyNum(String value) {
        this.policyNum = value;
    }

    /**
     * Gets the value of the documentid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOCUMENTID() {
        return documentid;
    }

    /**
     * Sets the value of the documentid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOCUMENTID(String value) {
        this.documentid = value;
    }

    /**
     * Gets the value of the dgdocname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDGDOCNAME() {
        return dgdocname;
    }

    /**
     * Sets the value of the dgdocname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDGDOCNAME(String value) {
        this.dgdocname = value;
    }

    /**
     * Gets the value of the doctypecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOCTYPECODE() {
        return doctypecode;
    }

    /**
     * Sets the value of the doctypecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOCTYPECODE(String value) {
        this.doctypecode = value;
    }

    /**
     * Gets the value of the doctype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOCTYPE() {
        return doctype;
    }

    /**
     * Sets the value of the doctype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOCTYPE(String value) {
        this.doctype = value;
    }

    /**
     * Gets the value of the datereceived property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATERECEIVED() {
        return datereceived;
    }

    /**
     * Sets the value of the datereceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATERECEIVED(String value) {
        this.datereceived = value;
    }

}
