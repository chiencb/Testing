
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for RepositoryPropertyTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RepositoryPropertyTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="bigDecimalValue" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="booleanValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="dateValue" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="intValue" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="modified" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="nullValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="readOnly" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="repositoryItemId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="stringValue" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RepositoryPropertyTO", namespace = "http://repository.sonora.eistream.com/", propOrder = {
    "bigDecimalValue",
    "booleanValue",
    "dateValue",
    "intValue",
    "modified",
    "nullValue",
    "readOnly",
    "repositoryItemId",
    "stringValue"
})
public class RepositoryPropertyTO {

    @XmlElement(required = true, nillable = true)
    protected BigDecimal bigDecimalValue;
    protected boolean booleanValue;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateValue;
    protected int intValue;
    protected boolean modified;
    protected boolean nullValue;
    protected boolean readOnly;
    @XmlElement(required = true, nillable = true)
    protected String repositoryItemId;
    @XmlElement(required = true, nillable = true)
    protected String stringValue;

    /**
     * Gets the value of the bigDecimalValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBigDecimalValue() {
        return bigDecimalValue;
    }

    /**
     * Sets the value of the bigDecimalValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBigDecimalValue(BigDecimal value) {
        this.bigDecimalValue = value;
    }

    /**
     * Gets the value of the booleanValue property.
     * 
     */
    public boolean isBooleanValue() {
        return booleanValue;
    }

    /**
     * Sets the value of the booleanValue property.
     * 
     */
    public void setBooleanValue(boolean value) {
        this.booleanValue = value;
    }

    /**
     * Gets the value of the dateValue property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateValue() {
        return dateValue;
    }

    /**
     * Sets the value of the dateValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateValue(XMLGregorianCalendar value) {
        this.dateValue = value;
    }

    /**
     * Gets the value of the intValue property.
     * 
     */
    public int getIntValue() {
        return intValue;
    }

    /**
     * Sets the value of the intValue property.
     * 
     */
    public void setIntValue(int value) {
        this.intValue = value;
    }

    /**
     * Gets the value of the modified property.
     * 
     */
    public boolean isModified() {
        return modified;
    }

    /**
     * Sets the value of the modified property.
     * 
     */
    public void setModified(boolean value) {
        this.modified = value;
    }

    /**
     * Gets the value of the nullValue property.
     * 
     */
    public boolean isNullValue() {
        return nullValue;
    }

    /**
     * Sets the value of the nullValue property.
     * 
     */
    public void setNullValue(boolean value) {
        this.nullValue = value;
    }

    /**
     * Gets the value of the readOnly property.
     * 
     */
    public boolean isReadOnly() {
        return readOnly;
    }

    /**
     * Sets the value of the readOnly property.
     * 
     */
    public void setReadOnly(boolean value) {
        this.readOnly = value;
    }

    /**
     * Gets the value of the repositoryItemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepositoryItemId() {
        return repositoryItemId;
    }

    /**
     * Sets the value of the repositoryItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepositoryItemId(String value) {
        this.repositoryItemId = value;
    }

    /**
     * Gets the value of the stringValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStringValue() {
        return stringValue;
    }

    /**
     * Sets the value of the stringValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStringValue(String value) {
        this.stringValue = value;
    }

}
