
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QueryOutputTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QueryOutputTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="combineWithParams" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="displayImage" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="personaBasedToolBarUUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="refreshSeconds" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="showIconPerRow" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="type" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryOutputTO", namespace = "http://query.sonora.eistream.com/", propOrder = {
    "combineWithParams",
    "displayImage",
    "personaBasedToolBarUUID",
    "refreshSeconds",
    "showIconPerRow",
    "type"
})
public class QueryOutputTO {

    protected boolean combineWithParams;
    protected boolean displayImage;
    @XmlElement(required = true, nillable = true)
    protected String personaBasedToolBarUUID;
    protected int refreshSeconds;
    protected int showIconPerRow;
    @XmlElement(required = true, nillable = true)
    protected String type;

    /**
     * Gets the value of the combineWithParams property.
     * 
     */
    public boolean isCombineWithParams() {
        return combineWithParams;
    }

    /**
     * Sets the value of the combineWithParams property.
     * 
     */
    public void setCombineWithParams(boolean value) {
        this.combineWithParams = value;
    }

    /**
     * Gets the value of the displayImage property.
     * 
     */
    public boolean isDisplayImage() {
        return displayImage;
    }

    /**
     * Sets the value of the displayImage property.
     * 
     */
    public void setDisplayImage(boolean value) {
        this.displayImage = value;
    }

    /**
     * Gets the value of the personaBasedToolBarUUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPersonaBasedToolBarUUID() {
        return personaBasedToolBarUUID;
    }

    /**
     * Sets the value of the personaBasedToolBarUUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPersonaBasedToolBarUUID(String value) {
        this.personaBasedToolBarUUID = value;
    }

    /**
     * Gets the value of the refreshSeconds property.
     * 
     */
    public int getRefreshSeconds() {
        return refreshSeconds;
    }

    /**
     * Sets the value of the refreshSeconds property.
     * 
     */
    public void setRefreshSeconds(int value) {
        this.refreshSeconds = value;
    }

    /**
     * Gets the value of the showIconPerRow property.
     * 
     */
    public int getShowIconPerRow() {
        return showIconPerRow;
    }

    /**
     * Sets the value of the showIconPerRow property.
     * 
     */
    public void setShowIconPerRow(int value) {
        this.showIconPerRow = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
