
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FmsFieldMetaDataTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FmsFieldMetaDataTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="columnDefinition" type="{http://fields.sonora.eistream.com/}ColumnDefinitionTO"/&gt;
 *         &lt;element name="fieldDefinition" type="{http://fields.sonora.eistream.com/}FieldDefinitionTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FmsFieldMetaDataTO", namespace = "http://fields.sonora.eistream.com/", propOrder = {
    "columnDefinition",
    "fieldDefinition"
})
public class FmsFieldMetaDataTO {

    @XmlElement(required = true, nillable = true)
    protected ColumnDefinitionTO columnDefinition;
    @XmlElement(required = true, nillable = true)
    protected FieldDefinitionTO fieldDefinition;

    /**
     * Gets the value of the columnDefinition property.
     * 
     * @return
     *     possible object is
     *     {@link ColumnDefinitionTO }
     *     
     */
    public ColumnDefinitionTO getColumnDefinition() {
        return columnDefinition;
    }

    /**
     * Sets the value of the columnDefinition property.
     * 
     * @param value
     *     allowed object is
     *     {@link ColumnDefinitionTO }
     *     
     */
    public void setColumnDefinition(ColumnDefinitionTO value) {
        this.columnDefinition = value;
    }

    /**
     * Gets the value of the fieldDefinition property.
     * 
     * @return
     *     possible object is
     *     {@link FieldDefinitionTO }
     *     
     */
    public FieldDefinitionTO getFieldDefinition() {
        return fieldDefinition;
    }

    /**
     * Sets the value of the fieldDefinition property.
     * 
     * @param value
     *     allowed object is
     *     {@link FieldDefinitionTO }
     *     
     */
    public void setFieldDefinition(FieldDefinitionTO value) {
        this.fieldDefinition = value;
    }

}
