
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RepositoryContentStreamTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RepositoryContentStreamTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="data" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *         &lt;element name="properties" type="{http://fields.sonora.eistream.com/}FieldPropertiesTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="propertyCount" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RepositoryContentStreamTO", namespace = "http://repository.sonora.eistream.com/", propOrder = {
    "data",
    "properties",
    "propertyCount"
})
public class RepositoryContentStreamTO {

    @XmlElement(required = true, nillable = true)
    protected byte[] data;
    @XmlElement(nillable = true)
    protected List<FieldPropertiesTO> properties;
    protected int propertyCount;

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setData(byte[] value) {
        this.data = value;
    }

    /**
     * Gets the value of the properties property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the properties property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProperties().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FieldPropertiesTO }
     * 
     * 
     */
    public List<FieldPropertiesTO> getProperties() {
        if (properties == null) {
            properties = new ArrayList<FieldPropertiesTO>();
        }
        return this.properties;
    }

    /**
     * Gets the value of the propertyCount property.
     * 
     */
    public int getPropertyCount() {
        return propertyCount;
    }

    /**
     * Sets the value of the propertyCount property.
     * 
     */
    public void setPropertyCount(int value) {
        this.propertyCount = value;
    }

}
