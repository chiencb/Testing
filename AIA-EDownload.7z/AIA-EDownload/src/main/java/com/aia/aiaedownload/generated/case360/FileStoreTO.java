
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for FileStoreTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FileStoreTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UUID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="acl" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="applicationName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="calendarExpression" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="capabilities" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="componentDefId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="componentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="createdDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="currentVersion" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="documentID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="eventName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="filePlanViewId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="fmsID" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="hidden" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="iconName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="imagingOptions" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="isTemplate" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="locked" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="lockedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="maxVersions" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="modifiedBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="modifiedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="newStyleDocument" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="nextVersion" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="oldStyleDocument" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="options" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="pathPrefix" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="poolId" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="repositoryDocId" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="retention" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="retentionExpression" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="templateId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="templateName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FileStoreTO", namespace = "http://filestore.sonora.eistream.com/", propOrder = {
    "uuid",
    "acl",
    "applicationName",
    "calendarExpression",
    "capabilities",
    "componentDefId",
    "componentId",
    "createdBy",
    "createdDateTime",
    "currentVersion",
    "documentID",
    "eventName",
    "filePlanViewId",
    "fmsID",
    "hidden",
    "iconName",
    "imagingOptions",
    "isTemplate",
    "locked",
    "lockedBy",
    "maxVersions",
    "modifiedBy",
    "modifiedDateTime",
    "newStyleDocument",
    "nextVersion",
    "oldStyleDocument",
    "options",
    "partitionName",
    "pathPrefix",
    "poolId",
    "repositoryDocId",
    "retention",
    "retentionExpression",
    "templateId",
    "templateName",
    "title"
})
public class FileStoreTO {

    @XmlElement(name = "UUID", required = true, nillable = true)
    protected String uuid;
    @XmlElement(required = true, nillable = true)
    protected String acl;
    @XmlElement(required = true, nillable = true)
    protected String applicationName;
    @XmlElement(required = true, nillable = true)
    protected String calendarExpression;
    @XmlElement(required = true, nillable = true)
    protected String capabilities;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentDefId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal componentId;
    @XmlElement(required = true, nillable = true)
    protected String createdBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDateTime;
    protected int currentVersion;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal documentID;
    @XmlElement(required = true, nillable = true)
    protected String eventName;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal filePlanViewId;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal fmsID;
    protected boolean hidden;
    @XmlElement(required = true, nillable = true)
    protected String iconName;
    @XmlElement(required = true, nillable = true)
    protected String imagingOptions;
    protected int isTemplate;
    protected boolean locked;
    @XmlElement(required = true, nillable = true)
    protected String lockedBy;
    protected int maxVersions;
    @XmlElement(required = true, nillable = true)
    protected String modifiedBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modifiedDateTime;
    protected boolean newStyleDocument;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer nextVersion;
    protected boolean oldStyleDocument;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer options;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    @XmlElement(required = true, nillable = true)
    protected String pathPrefix;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer poolId;
    @XmlElement(required = true, nillable = true)
    protected String repositoryDocId;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar retention;
    @XmlElement(required = true, nillable = true)
    protected String retentionExpression;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal templateId;
    @XmlElement(required = true, nillable = true)
    protected String templateName;
    @XmlElement(required = true, nillable = true)
    protected String title;

    /**
     * Gets the value of the uuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUUID() {
        return uuid;
    }

    /**
     * Sets the value of the uuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUUID(String value) {
        this.uuid = value;
    }

    /**
     * Gets the value of the acl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcl() {
        return acl;
    }

    /**
     * Sets the value of the acl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcl(String value) {
        this.acl = value;
    }

    /**
     * Gets the value of the applicationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Sets the value of the applicationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationName(String value) {
        this.applicationName = value;
    }

    /**
     * Gets the value of the calendarExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalendarExpression() {
        return calendarExpression;
    }

    /**
     * Sets the value of the calendarExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalendarExpression(String value) {
        this.calendarExpression = value;
    }

    /**
     * Gets the value of the capabilities property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapabilities() {
        return capabilities;
    }

    /**
     * Sets the value of the capabilities property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapabilities(String value) {
        this.capabilities = value;
    }

    /**
     * Gets the value of the componentDefId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentDefId() {
        return componentDefId;
    }

    /**
     * Sets the value of the componentDefId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentDefId(BigDecimal value) {
        this.componentDefId = value;
    }

    /**
     * Gets the value of the componentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getComponentId() {
        return componentId;
    }

    /**
     * Sets the value of the componentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setComponentId(BigDecimal value) {
        this.componentId = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the createdDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * Sets the value of the createdDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDateTime(XMLGregorianCalendar value) {
        this.createdDateTime = value;
    }

    /**
     * Gets the value of the currentVersion property.
     * 
     */
    public int getCurrentVersion() {
        return currentVersion;
    }

    /**
     * Sets the value of the currentVersion property.
     * 
     */
    public void setCurrentVersion(int value) {
        this.currentVersion = value;
    }

    /**
     * Gets the value of the documentID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocumentID() {
        return documentID;
    }

    /**
     * Sets the value of the documentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocumentID(BigDecimal value) {
        this.documentID = value;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventName(String value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the filePlanViewId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFilePlanViewId() {
        return filePlanViewId;
    }

    /**
     * Sets the value of the filePlanViewId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFilePlanViewId(BigDecimal value) {
        this.filePlanViewId = value;
    }

    /**
     * Gets the value of the fmsID property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFmsID() {
        return fmsID;
    }

    /**
     * Sets the value of the fmsID property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFmsID(BigDecimal value) {
        this.fmsID = value;
    }

    /**
     * Gets the value of the hidden property.
     * 
     */
    public boolean isHidden() {
        return hidden;
    }

    /**
     * Sets the value of the hidden property.
     * 
     */
    public void setHidden(boolean value) {
        this.hidden = value;
    }

    /**
     * Gets the value of the iconName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIconName() {
        return iconName;
    }

    /**
     * Sets the value of the iconName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIconName(String value) {
        this.iconName = value;
    }

    /**
     * Gets the value of the imagingOptions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImagingOptions() {
        return imagingOptions;
    }

    /**
     * Sets the value of the imagingOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImagingOptions(String value) {
        this.imagingOptions = value;
    }

    /**
     * Gets the value of the isTemplate property.
     * 
     */
    public int getIsTemplate() {
        return isTemplate;
    }

    /**
     * Sets the value of the isTemplate property.
     * 
     */
    public void setIsTemplate(int value) {
        this.isTemplate = value;
    }

    /**
     * Gets the value of the locked property.
     * 
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Sets the value of the locked property.
     * 
     */
    public void setLocked(boolean value) {
        this.locked = value;
    }

    /**
     * Gets the value of the lockedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLockedBy() {
        return lockedBy;
    }

    /**
     * Sets the value of the lockedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLockedBy(String value) {
        this.lockedBy = value;
    }

    /**
     * Gets the value of the maxVersions property.
     * 
     */
    public int getMaxVersions() {
        return maxVersions;
    }

    /**
     * Sets the value of the maxVersions property.
     * 
     */
    public void setMaxVersions(int value) {
        this.maxVersions = value;
    }

    /**
     * Gets the value of the modifiedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModifiedBy() {
        return modifiedBy;
    }

    /**
     * Sets the value of the modifiedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModifiedBy(String value) {
        this.modifiedBy = value;
    }

    /**
     * Gets the value of the modifiedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModifiedDateTime() {
        return modifiedDateTime;
    }

    /**
     * Sets the value of the modifiedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModifiedDateTime(XMLGregorianCalendar value) {
        this.modifiedDateTime = value;
    }

    /**
     * Gets the value of the newStyleDocument property.
     * 
     */
    public boolean isNewStyleDocument() {
        return newStyleDocument;
    }

    /**
     * Sets the value of the newStyleDocument property.
     * 
     */
    public void setNewStyleDocument(boolean value) {
        this.newStyleDocument = value;
    }

    /**
     * Gets the value of the nextVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNextVersion() {
        return nextVersion;
    }

    /**
     * Sets the value of the nextVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNextVersion(Integer value) {
        this.nextVersion = value;
    }

    /**
     * Gets the value of the oldStyleDocument property.
     * 
     */
    public boolean isOldStyleDocument() {
        return oldStyleDocument;
    }

    /**
     * Sets the value of the oldStyleDocument property.
     * 
     */
    public void setOldStyleDocument(boolean value) {
        this.oldStyleDocument = value;
    }

    /**
     * Gets the value of the options property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getOptions() {
        return options;
    }

    /**
     * Sets the value of the options property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setOptions(Integer value) {
        this.options = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the pathPrefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPathPrefix() {
        return pathPrefix;
    }

    /**
     * Sets the value of the pathPrefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPathPrefix(String value) {
        this.pathPrefix = value;
    }

    /**
     * Gets the value of the poolId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPoolId() {
        return poolId;
    }

    /**
     * Sets the value of the poolId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPoolId(Integer value) {
        this.poolId = value;
    }

    /**
     * Gets the value of the repositoryDocId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepositoryDocId() {
        return repositoryDocId;
    }

    /**
     * Sets the value of the repositoryDocId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepositoryDocId(String value) {
        this.repositoryDocId = value;
    }

    /**
     * Gets the value of the retention property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRetention() {
        return retention;
    }

    /**
     * Sets the value of the retention property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRetention(XMLGregorianCalendar value) {
        this.retention = value;
    }

    /**
     * Gets the value of the retentionExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetentionExpression() {
        return retentionExpression;
    }

    /**
     * Sets the value of the retentionExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetentionExpression(String value) {
        this.retentionExpression = value;
    }

    /**
     * Gets the value of the templateId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTemplateId() {
        return templateId;
    }

    /**
     * Sets the value of the templateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTemplateId(BigDecimal value) {
        this.templateId = value;
    }

    /**
     * Gets the value of the templateName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateName() {
        return templateName;
    }

    /**
     * Sets the value of the templateName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateName(String value) {
        this.templateName = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

}
