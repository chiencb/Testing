
package com.aia.aiaedownload.generated.case360;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FileStoreConflictTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FileStoreConflictTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="conflict" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="newFileStoreElement" type="{http://filestore.sonora.eistream.com/}FileStoreTO"/&gt;
 *         &lt;element name="originalFileStoreElement" type="{http://filestore.sonora.eistream.com/}FileStoreTO"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FileStoreConflictTO", namespace = "http://filestore.sonora.eistream.com/", propOrder = {
    "conflict",
    "newFileStoreElement",
    "originalFileStoreElement"
})
public class FileStoreConflictTO {

    protected boolean conflict;
    @XmlElement(required = true, nillable = true)
    protected FileStoreTO newFileStoreElement;
    @XmlElement(required = true, nillable = true)
    protected FileStoreTO originalFileStoreElement;

    /**
     * Gets the value of the conflict property.
     * 
     */
    public boolean isConflict() {
        return conflict;
    }

    /**
     * Sets the value of the conflict property.
     * 
     */
    public void setConflict(boolean value) {
        this.conflict = value;
    }

    /**
     * Gets the value of the newFileStoreElement property.
     * 
     * @return
     *     possible object is
     *     {@link FileStoreTO }
     *     
     */
    public FileStoreTO getNewFileStoreElement() {
        return newFileStoreElement;
    }

    /**
     * Sets the value of the newFileStoreElement property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileStoreTO }
     *     
     */
    public void setNewFileStoreElement(FileStoreTO value) {
        this.newFileStoreElement = value;
    }

    /**
     * Gets the value of the originalFileStoreElement property.
     * 
     * @return
     *     possible object is
     *     {@link FileStoreTO }
     *     
     */
    public FileStoreTO getOriginalFileStoreElement() {
        return originalFileStoreElement;
    }

    /**
     * Sets the value of the originalFileStoreElement property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileStoreTO }
     *     
     */
    public void setOriginalFileStoreElement(FileStoreTO value) {
        this.originalFileStoreElement = value;
    }

}
