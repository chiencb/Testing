
package com.aia.aiaedownload.generated.case360;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rpDoActionPostData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rpDoActionPostData"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="String_1" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="String_2" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="arrayOfFieldPropertiesTO_3" type="{http://fields.sonora.eistream.com/}FieldPropertiesTO" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="arrayOfbyte_4" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rpDoActionPostData", propOrder = {
    "string1",
    "string2",
    "arrayOfFieldPropertiesTO3",
    "arrayOfbyte4"
})
public class RpDoActionPostData {

    @XmlElement(name = "String_1", required = true, nillable = true)
    protected String string1;
    @XmlElement(name = "String_2", required = true, nillable = true)
    protected String string2;
    @XmlElement(name = "arrayOfFieldPropertiesTO_3", nillable = true)
    protected List<FieldPropertiesTO> arrayOfFieldPropertiesTO3;
    @XmlElement(name = "arrayOfbyte_4", required = true, nillable = true)
    protected byte[] arrayOfbyte4;

    /**
     * Gets the value of the string1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString1() {
        return string1;
    }

    /**
     * Sets the value of the string1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString1(String value) {
        this.string1 = value;
    }

    /**
     * Gets the value of the string2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getString2() {
        return string2;
    }

    /**
     * Sets the value of the string2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setString2(String value) {
        this.string2 = value;
    }

    /**
     * Gets the value of the arrayOfFieldPropertiesTO3 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the arrayOfFieldPropertiesTO3 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getArrayOfFieldPropertiesTO3().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FieldPropertiesTO }
     * 
     * 
     */
    public List<FieldPropertiesTO> getArrayOfFieldPropertiesTO3() {
        if (arrayOfFieldPropertiesTO3 == null) {
            arrayOfFieldPropertiesTO3 = new ArrayList<FieldPropertiesTO>();
        }
        return this.arrayOfFieldPropertiesTO3;
    }

    /**
     * Gets the value of the arrayOfbyte4 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getArrayOfbyte4() {
        return arrayOfbyte4;
    }

    /**
     * Sets the value of the arrayOfbyte4 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setArrayOfbyte4(byte[] value) {
        this.arrayOfbyte4 = value;
    }

}
