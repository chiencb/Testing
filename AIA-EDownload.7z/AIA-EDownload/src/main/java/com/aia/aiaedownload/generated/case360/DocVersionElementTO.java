
package com.aia.aiaedownload.generated.case360;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DocVersionElementTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocVersionElementTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="checkInComment" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="checkInDueDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="checkedInBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="checkedInDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="checkedOutBy" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="checkoutComment" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="checkoutDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="childVersionNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="flags" type="{http://www.w3.org/2001/XMLSchema}short"/&gt;
 *         &lt;element name="inProgress" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="locked" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="partitionName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="published" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="record" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="versionLabel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="versionNumber" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocVersionElementTO", namespace = "http://filestore.sonora.eistream.com/", propOrder = {
    "checkInComment",
    "checkInDueDate",
    "checkedInBy",
    "checkedInDate",
    "checkedOutBy",
    "checkoutComment",
    "checkoutDate",
    "childVersionNumber",
    "documentId",
    "flags",
    "inProgress",
    "locked",
    "partitionName",
    "published",
    "record",
    "versionLabel",
    "versionNumber"
})
public class DocVersionElementTO {

    @XmlElement(required = true, nillable = true)
    protected String checkInComment;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar checkInDueDate;
    @XmlElement(required = true, nillable = true)
    protected String checkedInBy;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar checkedInDate;
    @XmlElement(required = true, nillable = true)
    protected String checkedOutBy;
    @XmlElement(required = true, nillable = true)
    protected String checkoutComment;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar checkoutDate;
    @XmlElement(required = true, type = Integer.class, nillable = true)
    protected Integer childVersionNumber;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal documentId;
    protected short flags;
    protected boolean inProgress;
    protected boolean locked;
    @XmlElement(required = true, nillable = true)
    protected String partitionName;
    protected boolean published;
    protected boolean record;
    @XmlElement(required = true, nillable = true)
    protected String versionLabel;
    protected int versionNumber;

    /**
     * Gets the value of the checkInComment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckInComment() {
        return checkInComment;
    }

    /**
     * Sets the value of the checkInComment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckInComment(String value) {
        this.checkInComment = value;
    }

    /**
     * Gets the value of the checkInDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCheckInDueDate() {
        return checkInDueDate;
    }

    /**
     * Sets the value of the checkInDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCheckInDueDate(XMLGregorianCalendar value) {
        this.checkInDueDate = value;
    }

    /**
     * Gets the value of the checkedInBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckedInBy() {
        return checkedInBy;
    }

    /**
     * Sets the value of the checkedInBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckedInBy(String value) {
        this.checkedInBy = value;
    }

    /**
     * Gets the value of the checkedInDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCheckedInDate() {
        return checkedInDate;
    }

    /**
     * Sets the value of the checkedInDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCheckedInDate(XMLGregorianCalendar value) {
        this.checkedInDate = value;
    }

    /**
     * Gets the value of the checkedOutBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckedOutBy() {
        return checkedOutBy;
    }

    /**
     * Sets the value of the checkedOutBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckedOutBy(String value) {
        this.checkedOutBy = value;
    }

    /**
     * Gets the value of the checkoutComment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckoutComment() {
        return checkoutComment;
    }

    /**
     * Sets the value of the checkoutComment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckoutComment(String value) {
        this.checkoutComment = value;
    }

    /**
     * Gets the value of the checkoutDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCheckoutDate() {
        return checkoutDate;
    }

    /**
     * Sets the value of the checkoutDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCheckoutDate(XMLGregorianCalendar value) {
        this.checkoutDate = value;
    }

    /**
     * Gets the value of the childVersionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getChildVersionNumber() {
        return childVersionNumber;
    }

    /**
     * Sets the value of the childVersionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setChildVersionNumber(Integer value) {
        this.childVersionNumber = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocumentId(BigDecimal value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the flags property.
     * 
     */
    public short getFlags() {
        return flags;
    }

    /**
     * Sets the value of the flags property.
     * 
     */
    public void setFlags(short value) {
        this.flags = value;
    }

    /**
     * Gets the value of the inProgress property.
     * 
     */
    public boolean isInProgress() {
        return inProgress;
    }

    /**
     * Sets the value of the inProgress property.
     * 
     */
    public void setInProgress(boolean value) {
        this.inProgress = value;
    }

    /**
     * Gets the value of the locked property.
     * 
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Sets the value of the locked property.
     * 
     */
    public void setLocked(boolean value) {
        this.locked = value;
    }

    /**
     * Gets the value of the partitionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartitionName() {
        return partitionName;
    }

    /**
     * Sets the value of the partitionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartitionName(String value) {
        this.partitionName = value;
    }

    /**
     * Gets the value of the published property.
     * 
     */
    public boolean isPublished() {
        return published;
    }

    /**
     * Sets the value of the published property.
     * 
     */
    public void setPublished(boolean value) {
        this.published = value;
    }

    /**
     * Gets the value of the record property.
     * 
     */
    public boolean isRecord() {
        return record;
    }

    /**
     * Sets the value of the record property.
     * 
     */
    public void setRecord(boolean value) {
        this.record = value;
    }

    /**
     * Gets the value of the versionLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionLabel() {
        return versionLabel;
    }

    /**
     * Sets the value of the versionLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionLabel(String value) {
        this.versionLabel = value;
    }

    /**
     * Gets the value of the versionNumber property.
     * 
     */
    public int getVersionNumber() {
        return versionNumber;
    }

    /**
     * Sets the value of the versionNumber property.
     * 
     */
    public void setVersionNumber(int value) {
        this.versionNumber = value;
    }

}
