package com.aia.aiaedownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiaEDownloadApplicationTests {

    @Test
    void contextLoads() {
    }

}
